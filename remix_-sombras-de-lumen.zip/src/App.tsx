/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { GameState, Player, Region, DialogueNode } from './types';
import { TitleScreen } from './components/TitleScreen';
import { PlayerProfile } from './components/PlayerProfile';
import { LevelSelect } from './components/LevelSelect';
import { TrophiesCabinet } from './components/TrophiesCabinet';
import { StoryModal } from './components/StoryModal';
import { EndingScreen } from './components/EndingScreen';
import { HUD } from './components/HUD';
import { GameCanvas } from './components/GameCanvas';
import { SettingsScreen } from './components/SettingsScreen';
import { GameManual } from './components/GameManual';
import { audio } from './audio';
import { X, Play, RefreshCw, LogOut, LockKeyhole, HelpCircle, Swords, Check, VolumeX, Volume2, Settings } from 'lucide-react';

const REGIONS: Region[] = [
  { id: 0, name: 'Terra Queimada', icon: '🔥', bg1: '#3a1a1a', bg2: '#0f0505', range: [0, 20] },
  { id: 1, name: 'Rio de Cinzas', icon: '💧', bg1: '#11222e', bg2: '#050a0f', range: [20, 40] },
  { id: 2, name: 'Selva Ferida', icon: '🌲', bg1: '#112211', bg2: '#040b04', range: [40, 60] },
  { id: 3, name: 'Rede Sombria', icon: '🕸️', bg1: '#1e112d', bg2: '#08040d', range: [60, 80] },
  { id: 4, name: 'Coração de Lumen', icon: '💚', bg1: '#072e1e', bg2: '#000803', range: [80, 100] }
];

const DIFFICULTY_SETTINGS: Record<string, { label: string; color: string }> = {
  easy: { label: 'Voluntário', color: '#10b981' }, // emerald
  normal: { label: 'Agente', color: '#0ea5e9' }, // sky
  hard: { label: 'Fiscal Líder', color: '#f59e0b' }, // amber
  impossible: { label: 'Sobrenatural', color: '#f43f5e' } // rose
};

// Procedural Level Names matching the environmental rescue plan
const PREFIXES = [
  'Setor', 'Trilha', 'Clareira', 'Refúgio', 'Resgate', 'Recuperação', 'Vigilância', 'Patrulha',
  'Encruzilhada', 'Fronteira', 'Rastro', 'Preservação', 'Monitoramento', 'Estação', 'Desfiladeiro',
  'Divisa', 'Nascente', 'Foz', 'Aparador', 'Guarita', 'Posto', 'Reserva', 'Várzea', 'Cume', 'Borda'
];

const SUFFIXES: string[][] = [
  ['da Terra Queimada', 'da Queima Clandestina', 'dos Troncos Carbonizados', 'da Cinza Quente', 'da Clareira Aberta', 'das Frentes de Fogo', 'da Devastação Inicial', 'da Motosserra Retida'],
  ['do Rio de Cinzas', 'da Margem Poluída', 'dos Rejeitos de Metal', 'das Balsas Mercúrio', 'do Riacho Sombrio', 'da Escavação Profunda', 'da Correnteza Turva', 'da Foz do Garimpo'],
  ['da Selva Ferida', 'das Armadilhas Ocultas', 'das Gaiolas de Contrabando', 'da Copa Desprovida', 'dos Trás-as-Árvores', 'da Flora Silenciada', 'das Clareiras de Eucalipto', 'do Antigo Refúgio'],
  ['da Rede Sombria', 'do Acampamento Hostil', 'dos Drones de Espionagem', 'das Trilhas de Traficantes', 'das Gaiolas Secretas', 'da Base Secreta', 'dos Galpões do Crime', 'da Inteligência Furtiva'],
  ['do Coração de Lumen', 'do Santuário Preservado', 'do Domínio da Vida', 'de Lumen Revivido', 'do Equilíbrio Verde', 'da Floresta Milenar', 'do Reflorestamento Final', 'do Legado Conservacionista']
];

function generateLevelNames(): string[] {
  const names: string[] = [];
  for (let r = 0; r < 5; r++) {
    for (let l = 0; l < 20; l++) {
      const p = PREFIXES[l % PREFIXES.length];
      const s = SUFFIXES[r][l % SUFFIXES[r].length];
      names.push(`${p} ${s}`);
    }
  }
  return names;
}

const LEVEL_NAMES = generateLevelNames();

export default function App() {
  const [gameState, setGameState] = useState<GameState>('title');
  const [prevGameState, setPrevGameState] = useState<GameState>('title');
  const [showIntro, setShowIntro] = useState<boolean>(true);
  const [introPhase, setIntroPhase] = useState<'showing' | 'iris-closing'>('showing');

  useEffect(() => {
    // Keep showing logo for 2.2 seconds, then begin iris-close darkening animation
    const timer1 = setTimeout(() => {
      setIntroPhase('iris-closing');
    }, 2200);

    // Total 3.4 seconds transition finished, disable intro state
    const timer2 = setTimeout(() => {
      setShowIntro(false);
    }, 3400);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, []);

  const [currentLevelIdx, setCurrentLevelIdx] = useState<number>(0);
  const [difficulty, setDifficulty] = useState<'easy' | 'normal' | 'hard' | 'impossible'>('normal');

  // Dynamic Full-screen Autoscaling state
  const [scale, setScale] = useState<number>(1);
  const [isPortrait, setIsPortrait] = useState<boolean>(false);
  const [isEditingHud, setIsEditingHud] = useState<boolean>(false);

  useEffect(() => {
    const handleResize = () => {
      const isMobile = window.innerWidth < 1024;
      const portrait = window.innerHeight > window.innerWidth && isMobile;
      setIsPortrait(portrait);

      const margin = isMobile ? 8 : 24;
      const parentW = portrait ? Math.max(280, window.innerHeight - margin) : Math.max(280, window.innerWidth - margin);
      const parentH = portrait ? Math.max(180, window.innerWidth - margin) : Math.max(180, window.innerHeight - margin);
      
      const targetW = 960;
      const targetH = 640;
      const scaleX = parentW / targetW;
      const scaleY = parentH / targetH;
      setScale(Math.min(scaleX, scaleY));
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Persistence unlocked states
  const [unlockedLevels, setUnlockedLevels] = useState<boolean[]>(() => {
    const list = new Array(100).fill(false);
    list[0] = true; // Level 1 is unlocked initially
    return list;
  });
  const [completedLevels, setCompletedLevels] = useState<boolean[]>(new Array(100).fill(false));
  const [trophies, setTrophies] = useState<Record<string, boolean>>({});

  // Character Progression Engine State
  const [playerProgression, setPlayerProgression] = useState({
    level: 0,
    xp: 0,
    maxXp: 100,
    statPoints: 0,
    vitalidade: 0,
    destreza: 0,
    forca: 0,
    resistencia: 0,
    manaStat: 0,
  });

  // Floating Player HUD synchronizers
  const [playerHUD, setPlayerHUD] = useState<Player>({
    x: 100, y: 520, w: 40, h: 56, vx: 0, vy: 0, spd: 4.5, jF: -13,
    hp: 100, mxHp: 100, mana: 100, mxMana: 100, og: false, fac: 1,
    atk: false, atkT: 0, combo: 0, comboT: 0, curAtk: 'normal', mType: 'fireball',
    specReady: true, specCD: 0, jumps: 2, maxJumps: 2, dashCD: 0, ascPhase: 0,
    animFrame: 0, animTimer: 0, swordKillsCharge: 0,
    stamina: 40,
    mxStamina: 40,
    level: 0,
    xp: 0,
    maxXp: 100,
    statPoints: 0,
    vitalidade: 0,
    destreza: 0,
    forca: 0,
    resistencia: 0,
    manaStat: 0
  });
  const [lightPercent, setLightPercent] = useState<number>(0);
  const [shadowPercent, setShadowPercent] = useState<number>(0);
  const [crystalsGathered, setCrystalsGathered] = useState<number>(0);
  const [crystalsNeeded, setCrystalsNeeded] = useState<number>(3);
  const [aggressionPercent, setAggressionPercent] = useState<number>(0);

  // Stories narration modals
  const [storyTitle, setStoryTitle] = useState<string>('');
  const [storyContent, setStoryContent] = useState<string>('');
  const [storyCallback, setStoryCallback] = useState<() => void>(() => {});

  // Dialog nodes stack
  const [dialogueNodes, setDialogueNodes] = useState<DialogueNode[]>([]);
  const [dialogueIndex, setDialogueIndex] = useState<number>(0);

  // Save State alerts
  const [saveStatus, setSaveStatus] = useState<string>('');

  // Endings selection states
  const [endingType, setEndingType] = useState<'light' | 'dark' | 'transcend'>('light');
  const [isGameCompleted, setIsGameCompleted] = useState<boolean>(false);

  const [isAudioMuted, setIsAudioMuted] = useState<boolean>(false);
  const [isStatsOpen, setIsStatsOpen] = useState<boolean>(false);
  const [showManual, setShowManual] = useState<boolean>(() => {
    return localStorage.getItem('lumen_hide_manual_v1') !== 'true';
  });

  // Load cloud save values on load
  useEffect(() => {
    try {
      const raw = localStorage.getItem('lumen_save_v32');
      if (raw) {
        const parsed = JSON.parse(raw);
        let loadedCompleted = new Array(100).fill(false);
        if (parsed.completedLevels) {
          loadedCompleted = parsed.completedLevels;
          setCompletedLevels(loadedCompleted);
          if (parsed.completedLevels[99]) {
            setIsGameCompleted(true);
          }
        }
        const derivedUnlocked = new Array(100).fill(false);
        derivedUnlocked[0] = true;
        for (let i = 0; i < 100; i++) {
          if (loadedCompleted[i] && i + 1 < 100) {
            derivedUnlocked[i + 1] = true;
          }
        }
        setUnlockedLevels(derivedUnlocked);
        if (parsed.isGameCompleted) {
          setIsGameCompleted(true);
        }
        if (parsed.trophies) setTrophies(parsed.trophies);
        if (parsed.difficulty) setDifficulty(parsed.difficulty);
        if (typeof parsed.currentLevelIdx === 'number') setCurrentLevelIdx(parsed.currentLevelIdx);
        if (parsed.playerProgression) {
          setPlayerProgression(parsed.playerProgression);
        }
        setSaveStatus('💾 Save progress loaded successfully!');
        setTimeout(() => setSaveStatus(''), 4000);
      }
    } catch (e) {
      console.error("Save system failure:", e);
    }
  }, []);

  const handleSave = () => {
    try {
      const data = {
        unlockedLevels,
        completedLevels,
        trophies,
        difficulty,
        currentLevelIdx,
        playerProgression,
        isGameCompleted,
        timestamp: new Date().toISOString(),
        version: '3.2'
      };
      localStorage.setItem('lumen_save_v32', JSON.stringify(data));
      setSaveStatus('💾 Progresso Gravado!');
      audio.playSFX('win');
      setTimeout(() => setSaveStatus(''), 3000);
    } catch (e) {
      setSaveStatus('❌ Falha ao Salvar!');
      setTimeout(() => setSaveStatus(''), 3000);
    }
  };

  const handleLoad = (): boolean => {
    try {
      const raw = localStorage.getItem('lumen_save_v32');
      if (raw) {
        const parsed = JSON.parse(raw);
        let loadedCompleted = new Array(100).fill(false);
        if (parsed.completedLevels) {
          loadedCompleted = parsed.completedLevels;
          setCompletedLevels(loadedCompleted);
          if (parsed.completedLevels[99]) {
            setIsGameCompleted(true);
          }
        }
        const derivedUnlocked = new Array(100).fill(false);
        derivedUnlocked[0] = true;
        for (let i = 0; i < 100; i++) {
          if (loadedCompleted[i] && i + 1 < 100) {
            derivedUnlocked[i + 1] = true;
          }
        }
        setUnlockedLevels(derivedUnlocked);
        if (parsed.isGameCompleted) {
          setIsGameCompleted(true);
        }
        if (parsed.trophies) setTrophies(parsed.trophies);
        if (parsed.difficulty) setDifficulty(parsed.difficulty);
        if (typeof parsed.currentLevelIdx === 'number') setCurrentLevelIdx(parsed.currentLevelIdx);
        if (parsed.playerProgression) {
          setPlayerProgression(parsed.playerProgression);
        }
        setSaveStatus('📂 Progresso Carregado!');
        audio.playSFX('heal');
        setTimeout(() => setSaveStatus(''), 3000);
        return true;
      }
      setSaveStatus('❓ Nenhum Save Encontrado!');
      setTimeout(() => setSaveStatus(''), 3000);
      return false;
    } catch (e) {
      setSaveStatus('❌ Falha ao Carregar!');
      setTimeout(() => setSaveStatus(''), 3000);
      return false;
    }
  };

  const handleDeleteSave = () => {
    if (window.confirm('Tem certeza absoluta que deseja resetar e apagar seu save permanente?')) {
      try {
        localStorage.removeItem('lumen_save_v32');
        setIsGameCompleted(false);
        setUnlockedLevels(() => {
          const list = new Array(100).fill(false);
          list[0] = true;
          return list;
        });
        setCompletedLevels(new Array(100).fill(false));
        setTrophies({});
        setDifficulty('normal');
        setCurrentLevelIdx(0);
        setPlayerProgression({
          level: 0,
          xp: 0,
          maxXp: 100,
          statPoints: 0,
          vitalidade: 0,
          destreza: 0,
          forca: 0,
          resistencia: 0,
          manaStat: 0,
        });
        setSaveStatus('🗑️ Save deletado!');
        setTimeout(() => setSaveStatus(''), 3000);
      } catch (e) {
        setSaveStatus('❌ Falha ao Deletar!');
      }
    }
  };

  const unlockTrophy = (id: string) => {
    if (!trophies[id]) {
      const nextTrophies = { ...trophies, [id]: true };
      setTrophies(nextTrophies);
      
      // Auto save on unlocked trohpies
      try {
        const data = {
          unlockedLevels,
          completedLevels,
          trophies: nextTrophies,
          difficulty,
          currentLevelIdx,
          version: '3.2'
        };
        localStorage.setItem('lumen_save_v32', JSON.stringify(data));
      } catch (e) {}
    }
  };

  const handleAllocateStat = (stat: 'vitalidade' | 'destreza' | 'forca' | 'resistencia' | 'manaStat') => {
    if (playerProgression.statPoints <= 0) return;
    setPlayerProgression(prev => {
      const nextPoints = prev.statPoints - 1;
      const nextStatValue = prev[stat] + 1;
      const updated = {
        ...prev,
        statPoints: nextPoints,
        [stat]: nextStatValue,
      };
      audio.playSFX('heal');
      return updated;
    });
  };

  const handleResetStats = () => {
    setPlayerProgression(prev => {
      const sumSpent = prev.vitalidade + prev.destreza + prev.forca + prev.resistencia + prev.manaStat;
      if (sumSpent === 0) return prev;
      audio.playSFX('hit');
      return {
        ...prev,
        statPoints: prev.statPoints + sumSpent,
        vitalidade: 0,
        destreza: 0,
        forca: 0,
        resistencia: 0,
        manaStat: 0
      };
    });
  };

  const handleGainFreePoints = (count: number) => {
    setPlayerProgression(prev => {
      audio.playSFX('heal');
      return {
        ...prev,
        statPoints: prev.statPoints + count
      };
    });
  };

  const handleUpdateHUD = (
    player: Player,
    lightPct: number,
    shadowPct: number,
    gatheredCrys: number,
    totalCrys: number,
    aggroPct: number
  ) => {
    setPlayerHUD(player);
    setLightPercent(lightPct);
    setShadowPercent(shadowPct);
    setCrystalsGathered(gatheredCrys);
    setCrystalsNeeded(totalCrys);
    setAggressionPercent(aggroPct);

    // Sync React playerProgression state safely if differences exist (avoiding loop)
    if (
      player.level !== playerProgression.level ||
      player.xp !== playerProgression.xp ||
      player.maxXp !== playerProgression.maxXp ||
      player.statPoints !== playerProgression.statPoints ||
      player.vitalidade !== playerProgression.vitalidade ||
      player.destreza !== playerProgression.destreza ||
      player.forca !== playerProgression.forca ||
      player.resistencia !== playerProgression.resistencia ||
      player.manaStat !== playerProgression.manaStat
    ) {
      setPlayerProgression({
        level: player.level,
        xp: player.xp,
        maxXp: player.maxXp,
        statPoints: player.statPoints,
        vitalidade: player.vitalidade,
        destreza: player.destreza,
        forca: player.forca,
        resistencia: player.resistencia,
        manaStat: player.manaStat,
      });
    }

    // Dynamic music filters sweep (Web Audio procedural synthesizer cutoff shifts)
    audio.updateMusicParameters(lightPct);
  };

  const triggerStoryChapterNarrative = (levelIdx: number, callback: () => void) => {
    setGameState('story');
    setStoryCallback(() => callback);
    const regionName = REGIONS[Math.floor(levelIdx / 30)].name;

    if (levelIdx === 0) {
      setStoryTitle('CAPÍTULO I: TERRA QUEIMADA');
      setStoryContent(
        'O jovem agente ambiental acorda sob as cinzas da Terra Queimada. Equipado com sua lanterna tática e rádio de suporte, ele se levanta para enfrentar os crimes de queimadas e exploração florestal do Capitão Machado.\n\nSua missão é combater os focos e capturar os infratores para reestabelecer o ecossistema vegetal!'
      );
    } else if (levelIdx === 30) {
      setStoryTitle('CAPÍTULO II: O RIO DE CINZAS');
      setStoryContent(
        'Avançando para as margens do Rio de Cinzas, o agente depara-se com águas cinzentas e poluídas pelo mercúrio do garimpo ilegal administrado pelo Barão do Mercúrio.\n\nUse seus sinalizadores e dardos tranquilizantes de forma furtiva para conter os garimpeiros e recuperar os leitos fluviais.'
      );
    } else if (levelIdx === 60) {
      setStoryTitle('CAPÍTULO III: A SELVA FERIDA');
      setStoryContent(
        'As motosserras industriais de grande porte ecoam na Selva Ferida, derrubando árvores centenárias. A fauna local está em perigo extremo, presa em gaiolas suspensas.\n\nUse o bastão tático descendente para neutralizar os madeireiros ilegais e libertar os animais silvestres.'
      );
    } else if (levelIdx === 90) {
      setStoryTitle('CAPÍTULO IV: A REDE SOMBRIA');
      setStoryContent(
        'O covil central dos contrabandistas de animais e desmatadores conspiradores. Liderados pela astuta Dra. Silvestre, as patrulhas usam óculos de visão noturna e cães de guarda.\n\nMantenha total furtividade, use desvios dinâmicos e desarme armadilhas para desmantelar esta facção criminosa.'
      );
    } else if (levelIdx === 120) {
      setStoryTitle('CAPÍTULO V: O CORAÇÃO DE LUMEN');
      setStoryContent(
        'Você alcançou o santuário intocado de Lumen. No entanto, o Comandante Brasa, o megainvestidor corrupto por trás da destruição florestal, aguarda com maquinário pesado para converter o parque em pasto desolado.\n\nO futuro de toda a biodiversidade depende da sua última fiscalização tática!'
      );
    } else {
      // Small randomized progress dialog
      setStoryTitle(`Vigilância de ${regionName}`);
      const phrases = [
        'A ousadia das facções criminosas aumenta... Os invasores estão mais agressivos conforme você resgata os animais!',
        'Novas pegadas e pistas foram identificadas nas redondezas. Melhore os circuitos do rádio tático.',
        'Vagas de reflorestamento estão prontas para sementes nativas. Mantenha os sensores fotovoltaicos limpos.',
        'Sua resiliência como agente florestal melhora a cada bosque limpo e animal reintegrado.'
      ];
      setStoryContent(phrases[levelIdx % phrases.length]);
    }
  };

  const handleLaunchLevel = (lvlIdx: number) => {
    setCurrentLevelIdx(lvlIdx);
    triggerStoryChapterNarrative(lvlIdx, () => {
      setGameState('playing');
    });
  };

  const handleNextStory = () => {
    setGameState('playing');
    if (storyCallback) storyCallback();
  };

  const handleCompleteLevel = () => {
    const nextIdx = currentLevelIdx + 1;
    
    // Mark as completed
    const nextCompleted = [...completedLevels];
    nextCompleted[currentLevelIdx] = true;
    setCompletedLevels(nextCompleted);

    let reachedEnd = false;
    if (nextIdx >= 100 || nextCompleted[99]) {
      setIsGameCompleted(true);
      reachedEnd = true;
    }

    // Unlock next level
    if (nextIdx < 100) {
      const nextUnlocked = [...unlockedLevels];
      nextUnlocked[nextIdx] = true;
      setUnlockedLevels(nextUnlocked);
    }

    setGameState('levelComplete');
    unlockTrophy('crystal_hunter');
    
    if (difficulty === 'impossible') {
      unlockTrophy('impossible_clear');
    }

    // Region complete assessment
    const rIdx = Math.floor(currentLevelIdx / 20);
    const region = REGIONS[rIdx];
    let allCleared = true;
    for (let i = region.range[0]; i < region.range[1]; i++) {
      if (!nextCompleted[i]) {
        allCleared = false;
        break;
      }
    }
    if (allCleared) {
      unlockTrophy('all_clear');
    }

    // Auto save game on completion
    try {
      const nextUnlockedList = [...unlockedLevels];
      if (nextIdx < 100) {
        nextUnlockedList[nextIdx] = true;
      }
      localStorage.setItem('lumen_save_v32', JSON.stringify({
        unlockedLevels: nextUnlockedList,
        completedLevels: nextCompleted,
        trophies,
        difficulty,
        currentLevelIdx: nextIdx < 100 ? nextIdx : currentLevelIdx,
        playerProgression,
        isGameCompleted: reachedEnd || isGameCompleted || nextCompleted[99],
        version: '3.2'
      }));
    } catch (e) {}
  };

  const handleNextLevel = () => {
    const nextIdx = currentLevelIdx + 1;
    if (nextIdx < 100) {
      handleLaunchLevel(nextIdx);
    } else {
      // 100 levels finished! End choices
      setGameState('choice');
    }
  };

  const handleShowDialogue = (nodes: DialogueNode[]) => {
    setGameState('dialogue');
    setDialogueNodes(nodes);
    setDialogueIndex(0);
  };

  const handleAdvanceDialogue = () => {
    if (dialogueIndex + 1 < dialogueNodes.length) {
      setDialogueIndex(prev => prev + 1);
    } else {
      setGameState('playing');
    }
  };

  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if (gameState === 'dialogue' && e.code === 'Space') {
        e.preventDefault();
        handleAdvanceDialogue();
      }
    };
    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => {
      window.removeEventListener('keydown', handleGlobalKeyDown);
    };
  }, [gameState, dialogueIndex, dialogueNodes]);

   const handleOpenSettings = () => {
    setPrevGameState(gameState);
    setGameState('settings');
    audio.playSFX('crystal');
  };

  const handleCloseSettings = () => {
    setGameState(prevGameState);
    audio.playSFX('win');
  };

  const handleTouchResume = (e: React.TouchEvent) => {
    if (e.cancelable) e.preventDefault();
    e.stopPropagation();
    setGameState('playing');
  };

  const handleTouchSave = (e: React.TouchEvent) => {
    if (e.cancelable) e.preventDefault();
    e.stopPropagation();
    handleSave();
  };

  const handleTouchMudarSetor = (e: React.TouchEvent) => {
    if (e.cancelable) e.preventDefault();
    e.stopPropagation();
    setGameState('story');
    setStoryTitle('');
  };

  const handleTouchBackToMenu = (e: React.TouchEvent) => {
    if (e.cancelable) e.preventDefault();
    e.stopPropagation();
    setGameState('title');
    audio.playSFX('win');
  };

  const handleTouchNextLevel = (e: React.TouchEvent) => {
    if (e.cancelable) e.preventDefault();
    e.stopPropagation();
    handleNextLevel();
  };

  const handleTouchRetry = (e: React.TouchEvent) => {
    if (e.cancelable) e.preventDefault();
    e.stopPropagation();
    setGameState('playing');
  };

  const activeRegion = REGIONS[Math.floor(currentLevelIdx / 30)] || REGIONS[0];
  const diffBadgeColor = DIFFICULTY_SETTINGS[difficulty]?.color || '#fff';
  const diffBadgeLabel = DIFFICULTY_SETTINGS[difficulty]?.label || 'Dificuldade';

  return (
    <div className="w-full h-full min-h-screen overflow-hidden flex items-center justify-center bg-[#020617] relative p-1 sm:p-2 select-none">
      {/* Dynamic layout bounding block matching scaled dimensions to prevent scrollbar overflow */}
      <div
        style={{
          width: `${(isPortrait ? 640 : 960) * scale}px`,
          height: `${(isPortrait ? 960 : 640) * scale}px`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0
        }}
        className="relative overflow-visible"
      >
        <div 
          className="absolute w-[960px] h-[640px] bg-slate-950 border border-slate-900 rounded-2xl overflow-hidden shadow-2xl flex flex-col font-sans" 
          id="gc"
          style={{
            transform: isPortrait ? `rotate(90deg) scale(${scale})` : `scale(${scale})`,
            transformOrigin: 'center center',
          }}
        >
      
      {/* Background Starfield Canvas for ambient */}
      <div className="absolute inset-0 pointer-events-none opacity-30 bg-radial-gradient(circle at center, rgba(16,21,42,0.6) 0%, rgba(5,5,10,1) 100%)" />

      {/* Introduction Screen Overlay */}
      {showIntro && (
        <div 
          className={`absolute inset-0 bg-white flex flex-col justify-center items-center z-[100] select-none ${
            introPhase === 'iris-closing' ? 'animate-iris-gate bg-transparent' : ''
          }`}
          id="introScreen"
        >
          {/* Cover off-white background block */}
          <div className="absolute inset-0 bg-[#f8fafc] flex flex-col items-center justify-center p-8 text-center" id="introContent">
            <div className="flex flex-col items-center gap-6 max-w-sm animate-logo-intro" id="introAnimBox">
              <img 
                src="/src/assets/images/logo_eeti_1781651770971.jpg" 
                alt="EETI José Augusto" 
                className="w-56 h-56 object-contain rounded-2xl" 
                referrerPolicy="no-referrer"
                id="logoEeti"
              />
              <div className="space-y-1 bg-white/75 backdrop-blur-sm px-4 py-2 rounded-xl border border-slate-100" id="introLabels">
                <h1 className="text-[20px] font-black text-slate-800 tracking-wider font-sans leading-tight">
                  EETI JOSÉ AUGUSTO
                </h1>
                <p className="text-[11px] uppercase font-bold text-slate-500 tracking-widest font-sans leading-snug">
                  Ensino Médio em Tempo Integral
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main menu selector */}
      {gameState === 'title' && (
        <TitleScreen
          difficulty={difficulty}
          onSetDifficulty={setDifficulty}
          onStartGame={() => handleLaunchLevel(currentLevelIdx)}
          onOpenLevels={() => setGameState('story')} // Route temporarily or through direct selection
          onOpenTrophies={() => setGameState('trophy')}
          onOpenControls={() => setGameState('story')} // Show static controls briefing inside story modal
          onOpenProfile={() => setGameState('profile')}
          onSave={handleSave}
          onLoad={handleLoad}
          onDeleteSave={handleDeleteSave}
          saveStatus={saveStatus}
          isGameCompleted={isGameCompleted}
          onOpenManual={() => setShowManual(true)}
        />
      )}

      {/* Custom Helpers Route mapping */}
      {gameState === 'title' && (
        <div className="hidden">
          {/* Keep tags compatible for external script hooks */}
          <button id="btnLevels" onClick={() => setGameState('story')} />
          <button id="btnTrophy" onClick={() => setGameState('trophy')} />
          <button id="btnProfile" onClick={() => setGameState('profile')} />
        </div>
      )}

      {/* Level Chooser */}
      {gameState === 'story' && storyTitle === '' && (
        <LevelSelect
          unlockedLevels={unlockedLevels}
          completedLevels={completedLevels}
          onSelectLevel={handleLaunchLevel}
          onBack={() => setGameState('title')}
          regions={REGIONS}
          levelNames={LEVEL_NAMES}
        />
      )}

      {/* Trophies Cabinet */}
      {gameState === 'trophy' && (
        <TrophiesCabinet
          trophies={trophies}
          onClose={() => setGameState('title')}
        />
      )}

      {/* Player Character Profile Screen */}
      {gameState === 'profile' && (
        <PlayerProfile
          playerProgression={playerProgression}
          unlockedLevelsCount={unlockedLevels.filter(Boolean).length}
          completedLevelsCount={completedLevels.filter(Boolean).length}
          trophiesCount={Object.keys(trophies).length}
          difficultyLabel={diffBadgeLabel}
          difficultyColor={diffBadgeColor}
          onAllocateStatPoint={handleAllocateStat}
          onResetStats={handleResetStats}
          onBack={() => setGameState('title')}
        />
      )}

      {/* Chapter Story Modal */}
      {gameState === 'story' && storyTitle !== '' && (
        <StoryModal
          title={storyTitle}
          content={storyContent}
          onNext={() => {
            setStoryTitle('');
            handleNextStory();
          }}
        />
      )}

      {/* Settings Screen */}
      {gameState === 'settings' && (
        <SettingsScreen
          onClose={handleCloseSettings}
          onSave={handleSave}
          onDeleteSave={handleDeleteSave}
          saveStatus={saveStatus}
          prevGameState={prevGameState}
          onEditHud={() => {
            setGameState('paused'); // Mounts the GameCanvas in paused state
            setIsEditingHud(true);
          }}
        />
      )}

      {/* Dynamic Dialogue Banner Overlay */}
      {gameState === 'dialogue' && dialogueNodes.length > 0 && (
        <div 
          onClick={(e) => {
            if (e.cancelable) e.preventDefault();
            e.stopPropagation();
            handleAdvanceDialogue();
          }}
          onTouchEnd={(e) => {
            if (e.cancelable) e.preventDefault();
            e.stopPropagation();
            handleAdvanceDialogue();
          }}
          className="absolute inset-0 z-40 cursor-pointer pointer-events-auto flex flex-col justify-end pb-8 select-none" 
          id="dbOverlay"
        >
          <div className="mx-auto w-[85%] bg-slate-950/92 backdrop-blur-md border border-slate-805 rounded-2xl p-5 flex flex-col gap-2 shadow-2xl" id="db">
            <div className="text-emerald-400 font-mono text-[9px] tracking-widest font-extrabold uppercase flex items-center gap-1.5 leading-none">
              <Swords className="w-3.5 h-3.5 text-emerald-400" />
              FREQUÊNCIA DE RÁDIO: {dialogueNodes[dialogueIndex].title}
            </div>
            <p className="text-slate-200 text-sm leading-relaxed sc text-justify pr-2 max-h-24 overflow-y-auto mt-1" id="dt font-sans">
              {dialogueNodes[dialogueIndex].text}
            </p>
            <div className="text-[9px] text-slate-500 text-right animate-pulse mt-2 flex items-center justify-end gap-1 font-mono tracking-wider" id="dh">
              <span>(APERTE EM QUALQUER LUGAR PARA CONTINUAR)</span>
              <Play className="w-2.5 h-2.5 fill-slate-500 stroke-none" />
            </div>
          </div>
        </div>
      )}

      {/* Pause Menu screen overlay */}
      {gameState === 'paused' && !isEditingHud && (
        <div className="absolute inset-0 z-40 flex flex-col justify-center items-center bg-slate-950/85 backdrop-blur-md pointer-events-auto" id="pauseMenu">
          <div className="bg-slate-900/40 border border-slate-800 p-8 rounded-2xl flex flex-col items-center gap-4 w-80 text-center shadow-2xl">
            <h2 className="text-2xl font-black text-emerald-400 tracking-widest uppercase">
              PATRULHA PAUSADA
            </h2>
            <p className="text-xs text-slate-400 font-mono">
              Fase {currentLevelIdx + 1}: {LEVEL_NAMES[currentLevelIdx]}
            </p>

            <button
              onClick={() => setGameState('playing')}
              onTouchEnd={handleTouchResume}
              className="w-full py-3 bg-emerald-500 text-slate-950 font-extrabold text-sm tracking-widest rounded-xl hover:scale-103 duration-150 cursor-pointer shadow-md shadow-emerald-500/10"
              id="btnResume"
            >
              RETOMAR PATRULHA
            </button>

            <button
              onClick={handleSave}
              onTouchEnd={handleTouchSave}
              className="w-full py-2.5 bg-emerald-950/20 border border-emerald-500/40 text-emerald-400 font-bold text-xs tracking-wider rounded-xl hover:bg-emerald-950/40 transition cursor-pointer"
              id="btnSavePause"
            >
              GRAVAR PROGRESSO (SAVE)
            </button>

            <button
              onClick={() => {
                setGameState('story');
                setStoryTitle(''); // Triggers LevelSelect
              }}
              onTouchEnd={handleTouchMudarSetor}
              className="w-full py-2.5 bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white font-bold text-xs rounded-xl transition cursor-pointer"
            >
              MUDAR SETOR DO PARQUE
            </button>

            <button
              onClick={() => {
                setGameState('title');
                audio.playSFX('win');
              }}
              onTouchEnd={handleTouchBackToMenu}
              className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-slate-600 text-slate-100 hover:text-white font-bold text-xs rounded-xl transition cursor-pointer shadow-md"
              id="btnBack5"
            >
              VOLTAR AO MENU PRINCIPAL
            </button>
          </div>
        </div>
      )}

      {/* Dead Player Overlay */}
      {gameState === 'dead' && (
        <div className="absolute inset-0 z-40 flex flex-col justify-center items-center bg-rose-950/70 backdrop-blur-sm p-6 pointer-events-auto" id="deathScreen">
          <div className="bg-slate-950/90 border border-rose-500/30 p-8 rounded-2xl flex flex-col items-center gap-4 w-96 text-center shadow-2xl">
            <h2 className="text-3xl font-black text-rose-500 tracking-wider">
              FISCAL EXAUSTO
            </h2>
            <p className="text-sm text-slate-400">
              O agente florestal foi encurralado pelas armadilhas ou patrulhas dos infratores...
            </p>
            <div className="flex gap-2 w-full mt-2">
              <button
                onClick={() => {
                  setGameState('playing');
                }}
                onTouchEnd={handleTouchRetry}
                className="flex-1 flex items-center justify-center gap-2 py-3 bg-rose-600 text-white font-black text-xs tracking-widest rounded-xl hover:scale-103 duration-150 cursor-pointer shadow-lg shadow-rose-600/15"
                id="btnRetry"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                RETORNAR AO SETOR
              </button>
              <button
                onClick={() => setGameState('title')}
                onTouchEnd={handleTouchBackToMenu}
                className="flex-1 py-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white font-bold text-xs tracking-wider rounded-xl transition cursor-pointer"
                id="btnBack3"
              >
                VOLTAR AO MENU
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Level completed Screen Overlay */}
      {gameState === 'levelComplete' && (
        <div className="absolute inset-0 z-40 flex flex-col justify-center items-center bg-slate-950/90 backdrop-blur-md p-6 pointer-events-auto" id="lcScreen">
          <div className="bg-slate-900/30 border border-slate-800 p-8 rounded-2xl flex flex-col items-center gap-4 w-96 text-center shadow-2xl">
            <h2 className="text-3xl font-black text-emerald-400 tracking-wider uppercase" id="completeTitle">
              SETOR REGENERADO!
            </h2>
            <p className="text-sm text-slate-350" id="completeText">
              Fase {currentLevelIdx + 1}: {LEVEL_NAMES[currentLevelIdx]} limpa e segura!
            </p>
            <div className="bg-slate-950 px-4 py-2 border border-slate-900 rounded-xl text-left w-full text-xs font-mono space-y-1 my-2">
              <div className="flex justify-between">
                <span className="text-slate-500">Mudas Plantadas:</span>
                <span className="text-emerald-400 font-bold">{Math.floor(lightPercent)}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Animais Resgatados:</span>
                <span className="text-sky-450 font-bold">{Math.floor(shadowPercent)}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Dificuldade da Fiscalização:</span>
                <span style={{ color: diffBadgeColor }} className="font-bold">{diffBadgeLabel}</span>
              </div>
            </div>

            <div className="flex gap-2 w-full">
              <button
                onClick={handleNextLevel}
                onTouchEnd={handleTouchNextLevel}
                className="flex-1 py-3 bg-emerald-500 text-slate-950 font-black text-xs tracking-widest rounded-xl hover:scale-103 duration-150 cursor-pointer shadow-lg shadow-emerald-500/15"
                id="btnNextLvl"
              >
                PATRULHAR SEGUINTE
              </button>
              <button
                onClick={() => setGameState('title')}
                onTouchEnd={handleTouchBackToMenu}
                className="flex-1 py-3 bg-slate-950 hover:bg-slate-900 border border-slate-850 hover:border-slate-800 text-slate-400 hover:text-white font-bold text-xs tracking-wider rounded-xl transition cursor-pointer"
                id="btnBack4"
              >
                SAIR AO MENU
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Narrative moral choice at level 100 */}
      {gameState === 'choice' && (
        <div className="absolute inset-0 z-40 flex flex-col justify-center items-center bg-slate-950/95 backdrop-blur-lg p-6" id="choiceScreen">
          <div className="bg-slate-900/35 border border-slate-805 p-8 rounded-3xl flex flex-col items-center max-w-xl text-center shadow-2xl">
            <span className="text-5xl mb-4 animate-bounce">🌳</span>
            <h2 className="text-3xl font-black text-emerald-400 tracking-wider uppercase mb-2">
              O DESTINO DO PARQUE LUMEN
            </h2>
            <p className="text-sm text-slate-350 leading-relaxed mb-6">
              Você patrulhou os 100 setores e deteve todas as principais infrações ecológicas. Chegou a hora de decidir a diretriz final de preservação para o Parque Nacional de Lumen.
            </p>

            <div className="grid grid-cols-1 gap-3 w-full">
              <button
                onClick={() => {
                  setEndingType('light');
                  setGameState('ending');
                  setIsGameCompleted(true);
                }}
                className="w-full py-3 bg-gradient-to-r from-emerald-600 to-green-400 hover:from-emerald-555 hover:to-green-300 text-slate-950 hover:text-white cursor-pointer font-extrabold text-xs tracking-widest rounded-xl transition shadow-md shadow-emerald-500/10"
                id="btnEnd1"
              >
                ESTABELECER PRESERVAÇÃO INTEGRAL (Reflorestamento e Proteção)
              </button>

              <button
                onClick={() => {
                  setEndingType('dark');
                  setGameState('ending');
                  setIsGameCompleted(true);
                }}
                className="w-full py-3 bg-gradient-to-r from-teal-850 to-emerald-700 hover:from-teal-700 hover:to-emerald-600 text-slate-100 hover:text-white cursor-pointer font-extrabold text-xs tracking-widest rounded-xl transition shadow-md shadow-teal-500/15"
                id="btnEnd2"
              >
                DECRETAR CONCESSÃO E USO CONSERVACIONISTA SUSTENTÁVEL
              </button>

              <button
                onClick={() => {
                  setEndingType('transcend');
                  setGameState('ending');
                  setIsGameCompleted(true);
                }}
                className="w-full py-3 bg-gradient-to-r from-sky-800 to-teal-600 hover:from-sky-700 hover:to-teal-500 text-slate-100 hover:text-white cursor-pointer font-extrabold text-xs tracking-widest rounded-xl transition shadow-md shadow-sky-500/10"
                id="btnEnd3"
              >
                HARMONIZAÇÃO SIMBIÓTICA INTEGRADA (Cooperação Científica)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cinematic Endings Epilogues */}
      {gameState === 'ending' && (
        <EndingScreen
          endingType={endingType}
          onBackToMenu={() => setGameState('title')}
        />
      )}

      {/* Live Play HUD bar values */}
      {(gameState === 'playing' || gameState === 'dialogue' || gameState === 'paused') && (
        <HUD
          player={playerHUD}
          lightPercent={lightPercent}
          shadowPercent={shadowPercent}
          unlockedCrystals={crystalsGathered}
          totalCrystals={crystalsNeeded}
          currentLevelIdx={currentLevelIdx}
          activeRegion={activeRegion}
          levelName={LEVEL_NAMES[currentLevelIdx]}
          onPause={() => setGameState('paused')}
          onResume={() => setGameState('playing')}
          isStatsOpen={isStatsOpen}
          onStatsOpenChange={setIsStatsOpen}
          aggressionPercent={aggressionPercent}
          difficultyLabel={diffBadgeLabel}
          difficultyColor={diffBadgeColor}
          onAllocateStatPoint={handleAllocateStat}
        />
      )}



      {/* Core interactive Engine Canvas mapping */}
      {(gameState === 'playing' || gameState === 'dialogue' || gameState === 'paused') && (
        <GameCanvas
          currentLevelIdx={currentLevelIdx}
          difficulty={difficulty}
          onDeath={() => setGameState('dead')}
          onCompleteLevel={handleCompleteLevel}
          onTrophyUnlocked={unlockTrophy}
          onUpdateHUD={handleUpdateHUD}
          regions={REGIONS}
          isPaused={gameState !== 'playing' || isStatsOpen || isEditingHud}
          onShowDialogue={handleShowDialogue}
          activeRegion={activeRegion}
          playerProgression={playerProgression}
          isEditingHud={isEditingHud}
          isPortrait={isPortrait}
          onExitEditHud={() => {
            setIsEditingHud(false);
            setGameState('settings');
          }}
        />
      )}

      {/* Floating Global Settings Gear in top-right */}
      {gameState !== 'settings' && gameState !== 'choice' && gameState !== 'ending' && !isEditingHud && (
        <button
          onClick={handleOpenSettings}
          className="absolute top-4 right-4 z-50 p-2.5 bg-slate-950/90 hover:bg-slate-900 border border-slate-800 hover:border-sky-500/40 text-slate-400 hover:text-sky-400 rounded-xl transition duration-200 cursor-pointer hover:rotate-90 shadow-lg flex items-center justify-center pointer-events-auto"
          id="btnGlobalSettings"
          title="Configurações da Jornada"
        >
          <Settings className="w-5 h-5 pointer-events-none" />
        </button>
      )}

      {/* Mandatory Game Manual modal on initial launch / start */}
      {showManual && (
        <GameManual onClose={() => setShowManual(false)} />
      )}
        </div>
      </div>
    </div>
  );
}
