/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type GameState = 'title' | 'story' | 'playing' | 'dialogue' | 'paused' | 'dead' | 'levelComplete' | 'choice' | 'ending' | 'trophy' | 'profile' | 'settings';

export type DifficultyInfo = {
  name: string;
  hpMult: number;
  dmgMult: number;
  spdMult: number;
  label: string;
  color: string;
  playerHp: number;
  playerMana: number;
};

export type Region = {
  id: number;
  name: string;
  icon: string;
  bg1: string;
  bg2: string;
  range: [number, number];
};

export interface Player {
  x: number;
  y: number;
  w: number;
  h: number;
  vx: number;
  vy: number;
  spd: number;
  jF: number;
  hp: number;
  mxHp: number;
  mana: number;
  mxMana: number;
  og: boolean;
  fac: number; // 1 or -1
  atk: boolean;
  atkT: number;
  combo: number;
  comboT: number;
  curAtk: 'normal' | 'slash' | 'dbl_slash' | 'trp_slash' | 'down_slash' | 'flash' | 'special' | 'orbital' | 'thrust' | 'heavy_slash';
  mType: 'fireball' | 'explosion' | 'barrier';
  specReady: boolean;
  specCD: number;
  jumps: number;
  maxJumps: number;
  dashCD: number;
  ascPhase: number;
  animFrame: number;
  animTimer: number;
  swordKillsCharge?: number;
  level: number;
  xp: number;
  maxXp: number;
  statPoints: number;
  vitalidade: number;
  destreza: number;
  forca: number;
  resistencia: number;
  manaStat: number;
  stamina?: number;
  mxStamina?: number;
  tempShieldT?: number;
  tempShieldCD?: number;
}

export interface Platform {
  x: number;
  y: number;
  w: number;
  h: number;
  type: 'ground' | 'platform' | 'moving_platform' | 'ice' | 'bounce_pad' | 'vanish_platform' | 'crumble_platform' | 'mirror' | 'shadow_zone' | 'light_trap' | 'gravity_zone' | 'teleporter';
  active: boolean;
  mx?: number;
  my?: number;
  sx?: number;
  sy?: number;
  mt?: number;
  ms?: number;
  vt?: number;
  van?: boolean;
  ct?: number;
  cr?: boolean;
}

export interface Enemy {
  x: number;
  y: number;
  w: number;
  h: number;
  vx: number;
  hp: number;
  mxHp: number;
  tn: string;
  col: string;
  eCol: string;
  alive: boolean;
  dir: number; // 1 or -1
  rng2: number;
  sx: number;
  at: number;
  aCd: number;
  atk: 'melee' | 'projectile' | 'area' | 'teleport' | 'charge' | 'combo' | 'aura' | 'dive';
  ad: number;
  ar: number;
  beh: 'patrol' | 'ranged' | 'ambush' | 'charge' | 'aggressive' | 'aura' | 'fly_teleport' | 'fly_dive';
  pc: string;
  charging?: boolean;
  cT?: number;
  tT?: number;
  flying: boolean;
  fy?: number;
  flyAmp?: number;
  flyFreq?: number;
  flyBase?: number;
  flyT?: number;
  diving?: boolean;
  diveT?: number;
  diveTarget?: number;
  stun: number;
  spriteType: string;
  animFrame: number;
  animTimer: number;
}

export interface Boss {
  x: number;
  y: number;
  w: number;
  h: number;
  hp: number;
  mxHp: number;
  pIdx: number;
  at2: number;
  mt2: number;
  dir: number;
  spd: number;
  alive: boolean;
  ft: number;
  name: string;
  atks: string[];
  col: string;
  ct2: number;
  isMajor: boolean;
  flying: boolean;
  region: number;
  phaseHP: number;
  fy: number;
  flyT: number;
  animFrame: number;
  animTimer: number;
}

export interface Projectile {
  x: number;
  y: number;
  vx: number;
  vy: number;
  w: number;
  h: number;
  life: number;
  type: 'fireball' | 'explosion' | 'barrier' | 'e_proj' | 'poison' | 'void_orb' | 'meteor' | 'laser' | 'b_beam' | 'orbital_blade';
  dmg: number;
  col?: string;
}

export interface Hazard {
  x: number;
  y: number;
  w: number;
  h: number;
  type: 'spike' | 'saw' | 'root';
  active: boolean;
  rot?: number;
  life?: number;
  baseY?: number;
  phase?: number;
  state?: 'retracted' | 'rising' | 'extended' | 'sinking';
  timer?: number;
}

export interface Crystal {
  x: number;
  y: number;
  col: boolean;
}

export interface LightOrb {
  x: number;
  y: number;
  active: boolean;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  mxL: number;
  col: string;
  sz: number;
}

export interface TrophyDef {
  id: string;
  icon: string;
  name: string;
  desc: string;
}

export interface DialogueNode {
  title: string;
  text: string;
}

export interface HUDButtonConfig {
  x: number;
  y: number;
  scale: number;
}

export interface HUDConfig {
  moveLeft: HUDButtonConfig;
  moveRight: HUDButtonConfig;
  attackNormal: HUDButtonConfig;
  estocada: HUDButtonConfig;
  attackHeavy: HUDButtonConfig;
  jump: HUDButtonConfig;
}

export const DEFAULT_HUD_CONFIG: HUDConfig = {
  moveLeft: { x: 40, y: 525, scale: 1.0 },
  moveRight: { x: 130, y: 525, scale: 1.0 },
  attackNormal: { x: 740, y: 515, scale: 1.0 },
  jump: { x: 860, y: 515, scale: 1.0 },
  estocada: { x: 795, y: 415, scale: 1.0 },
  attackHeavy: { x: 875, y: 315, scale: 1.1 },
};


