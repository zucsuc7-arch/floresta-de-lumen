/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

class DynamicAudioManager {
  private ctx: AudioContext | null = null;
  private musicInterval: any = null;
  private beat = 0;
  private filters: BiquadFilterNode[] = [];
  private mainGain: GainNode | null = null;
  private isMuted: boolean = false;
  private notes = [60, 62, 63, 65, 67, 68, 70, 72]; // Pentatonic minor
  private isMusicRunning = false;
  private volume: number = 0.5; // default volume is 50%

  constructor() {
    try {
      const savedVol = localStorage.getItem('lumen_volume');
      if (savedVol !== null) {
        this.volume = Math.max(0, Math.min(1, parseFloat(savedVol)));
      }
    } catch (e) {}
  }

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.mainGain = this.ctx.createGain();
        this.mainGain.gain.setValueAtTime(this.isMuted ? 0 : this.volume * 0.16, this.ctx.currentTime);

        const filter = this.ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(400, this.ctx.currentTime);
        filter.Q.setValueAtTime(1, this.ctx.currentTime);

        this.mainGain.connect(filter);
        filter.connect(this.ctx.destination);
        this.filters.push(filter);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public getVolume(): number {
    return this.volume;
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    try {
      localStorage.setItem('lumen_volume', this.volume.toString());
    } catch (e) {}
    if (this.mainGain && this.ctx) {
      this.mainGain.gain.setValueAtTime(this.isMuted ? 0 : this.volume * 0.16, this.ctx.currentTime);
    }
  }

  public setMute(muted: boolean) {
    this.isMuted = muted;
    if (this.mainGain && this.ctx) {
      this.mainGain.gain.setValueAtTime(muted ? 0 : this.volume * 0.16, this.ctx.currentTime);
    }
  }

  public toggleMute(): boolean {
    this.setMute(!this.isMuted);
    return this.isMuted;
  }

  public getMuted() {
    return this.isMuted;
  }

  public playSFX(type: 'jump' | 'hit' | 'dash' | 'crystal' | 'blast' | 'beam' | 'heal' | 'death' | 'win') {
    this.initCtx();
    if (!this.ctx || this.isMuted) return;

    const time = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const volumeGain = this.ctx.createGain();

    // at 50% (0.5), it plays at 1.0 scale.
    volumeGain.gain.setValueAtTime(this.volume * 2.0, time);

    osc.connect(gain);
    gain.connect(volumeGain);
    volumeGain.connect(this.ctx.destination);

    switch (type) {
      case 'jump':
        osc.type = 'sine';
        osc.frequency.setValueAtTime(150, time);
        osc.frequency.exponentialRampToValueAtTime(400, time + 0.15);
        gain.gain.setValueAtTime(0.3, time);
        gain.gain.exponentialRampToValueAtTime(0.01, time + 0.15);
        osc.start(time);
        osc.stop(time + 0.15);
        break;

      case 'dash':
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(300, time);
        osc.frequency.exponentialRampToValueAtTime(100, time + 0.1);
        gain.gain.setValueAtTime(0.4, time);
        gain.gain.exponentialRampToValueAtTime(0.01, time + 0.12);
        osc.start(time);
        osc.stop(time + 0.12);
        break;

      case 'hit':
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(180, time);
        osc.frequency.setValueAtTime(90, time + 0.05);
        gain.gain.setValueAtTime(0.5, time);
        gain.gain.exponentialRampToValueAtTime(0.01, time + 0.08);
        osc.start(time);
        osc.stop(time + 0.08);
        break;

      case 'crystal':
        osc.type = 'sine';
        osc.frequency.setValueAtTime(600, time);
        osc.frequency.setValueAtTime(900, time + 0.05);
        osc.frequency.exponentialRampToValueAtTime(1500, time + 0.2);
        gain.gain.setValueAtTime(0.3, time);
        gain.gain.exponentialRampToValueAtTime(0.01, time + 0.25);
        osc.start(time);
        osc.stop(time + 0.25);
        break;

      case 'blast':
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(220, time);
        osc.frequency.exponentialRampToValueAtTime(10, time + 0.3);
        gain.gain.setValueAtTime(0.5, time);
        gain.gain.exponentialRampToValueAtTime(0.01, time + 0.3);
        osc.start(time);
        osc.stop(time + 0.3);
        break;

      case 'beam':
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(350, time);
        osc.frequency.exponentialRampToValueAtTime(700, time + 0.25);
        gain.gain.setValueAtTime(0.2, time);
        gain.gain.exponentialRampToValueAtTime(0.01, time + 0.25);
        osc.start(time);
        osc.stop(time + 0.25);
        break;

      case 'heal':
        osc.type = 'sine';
        osc.frequency.setValueAtTime(300, time);
        osc.frequency.exponentialRampToValueAtTime(600, time + 0.1);
        osc.frequency.exponentialRampToValueAtTime(1200, time + 0.2);
        gain.gain.setValueAtTime(0.25, time);
        gain.gain.exponentialRampToValueAtTime(0.01, time + 0.3);
        osc.start(time);
        osc.stop(time + 0.3);
        break;

      case 'death':
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(200, time);
        osc.frequency.linearRampToValueAtTime(45, time + 0.6);
        gain.gain.setValueAtTime(0.6, time);
        gain.gain.exponentialRampToValueAtTime(0.01, time + 0.6);
        osc.start(time);
        osc.stop(time + 0.6);
        break;

      case 'win':
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(260, time);
        osc.frequency.setValueAtTime(390, time + 0.1);
        osc.frequency.setValueAtTime(520, time + 0.2);
        osc.frequency.setValueAtTime(780, time + 0.3);
        gain.gain.setValueAtTime(0.4, time);
        gain.gain.exponentialRampToValueAtTime(0.01, time + 0.5);
        osc.start(time);
        osc.stop(time + 0.5);
        break;
    }
  }

  public playMusic() {
    this.initCtx();
    if (this.isMusicRunning || !this.ctx || this.isMuted) return;

    this.isMusicRunning = true;
    this.beat = 0;

    this.musicInterval = setInterval(() => {
      if (this.isMuted || !this.ctx) return;
      const time = this.ctx.currentTime;
      this.playSynthNote(time);
      this.beat++;
    }, 150); // 100bpm sixteenths
  }

  private mToF(m: number): number {
    return Math.pow(2, (m - 69) / 12) * 440;
  }

  private playSynthNote(time: number) {
    if (!this.ctx || !this.mainGain) return;

    // Bass Synth - every quarter note
    if (this.beat % 4 === 0) {
      const bIdx = Math.floor(this.beat / 4) % 4;
      const baseBass = [48, 45, 41, 43][bIdx]; // C, A, F, G minor roots
      
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(this.mToF(baseBass), time);
      
      gain.gain.setValueAtTime(0.18, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + 0.35);
      
      osc.connect(gain);
      gain.connect(this.mainGain);
      osc.start(time);
      osc.stop(time + 0.4);
    }

    // High Arpeggios - 16th patterns
    if (this.beat % 2 === 0) {
      const chordIdx = Math.floor(this.beat / 8) % 4;
      const roots = [60, 57, 53, 55]; // chords
      const root = roots[chordIdx];
      
      // select pentatonic relative notes
      const notesInChord = [0, 3, 7, 10]; // minor 7th pattern
      const offset = notesInChord[Math.floor(this.beat / 2) % notesInChord.length];
      const freq = this.mToF(root + offset);

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, time);

      gain.gain.setValueAtTime(0.04, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + 0.18);

      osc.connect(gain);
      gain.connect(this.mainGain);
      osc.start(time);
      osc.stop(time + 0.20);
    }
  }

  public updateMusicParameters(lightPercent: number) {
    this.initCtx();
    if (!this.ctx) return;

    const time = this.ctx.currentTime;
    
    // Scale low-pass filter cutoff based on light percent (darker is abafado, purer light opens high peaks)
    // 0% Light -> 350Hz (muffled shadow synthesizer)
    // 100% Light -> 2800Hz with custom resonant frequency (shimmering crystals!)
    const cutoffBase = 350 + (lightPercent / 100) * 2450;
    
    this.filters.forEach(f => {
      // smooth interpolation of frequencies
      f.frequency.setTargetAtTime(cutoffBase, time, 0.4);
      f.Q.setTargetAtTime(1 + (lightPercent / 100) * 4, time, 0.3); // higher resonance in light
    });
  }

  public stopMusic() {
    if (this.musicInterval) {
      clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
    this.isMusicRunning = false;
  }
}

export const audio = new DynamicAudioManager();
