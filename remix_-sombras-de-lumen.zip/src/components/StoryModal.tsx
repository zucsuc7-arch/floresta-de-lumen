/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Scroll, Compass, Star, Skull, HelpCircle, FastForward } from 'lucide-react';

interface StoryModalProps {
  title: string;
  content: string;
  onNext: () => void;
}

export const StoryModal: React.FC<StoryModalProps> = ({ title, content, onNext }) => {
  // Select matching icon based on titles or levels
  const getStoryIcon = () => {
    const lTitle = title.toLowerCase();
    if (lTitle.includes('queimada') || lTitle.includes('fase 1:')) {
      return <Scroll className="w-12 h-12 text-amber-500 animate-pulse" />;
    } else if (lTitle.includes('cinzas') || lTitle.includes('rio')) {
      return <Compass className="w-12 h-12 text-cyan-400" />;
    } else if (lTitle.includes('selva') || lTitle.includes('ferida')) {
      return <Star className="w-12 h-12 text-emerald-400" />;
    } else if (lTitle.includes('rede') || lTitle.includes('sombria')) {
      return <Skull className="w-12 h-12 text-purple-400 animate-bounce" />;
    } else if (lTitle.includes('coração') || lTitle.includes('lumen')) {
      return <Star className="w-12 h-12 text-rose-400 animate-pulse" />;
    }
    return <HelpCircle className="w-12 h-12 text-sky-400" />;
  };

  return (
    <div className="absolute inset-0 z-50 flex flex-col justify-center items-center bg-slate-950/95 backdrop-blur-lg p-8" id="storyScreen">
      {/* Background radial atmosphere */}
      <div className="absolute w-96 h-96 rounded-full bg-sky-500/5 blur-3xl pointer-events-none" />

      <div className="relative w-full max-w-xl bg-slate-900/60 border border-slate-800/80 p-8 rounded-2xl shadow-2xl flex flex-col items-center text-center">
        {/* Cinematic Symbol */}
        <div className="mb-6 p-4 bg-slate-950 rounded-2xl border border-slate-800 shadow-inner">
          {getStoryIcon()}
        </div>

        {/* Narrative Title */}
        <h2 className="text-2xl font-extrabold tracking-widest text-slate-100 font-sans mb-4 uppercase" id="storyTitle">
          {title}
        </h2>

        {/* Story Text Box with scroll */}
        <div className="max-h-60 overflow-y-auto mb-8 pr-2">
          <p className="text-slate-300 font-sans leading-relaxed text-sm whitespace-pre-line sc" id="storyContent">
            {content}
          </p>
        </div>

        {/* Forward Trigger Button */}
        <button
          onClick={onNext}
          className="flex items-center gap-2 px-8 py-3 bg-sky-500 hover:bg-sky-450 border border-sky-400/20 text-slate-950 font-bold rounded-xl shadow-lg shadow-sky-500/10 cursor-pointer hover:scale-103 active:scale-98 transition duration-200"
          id="btnNext"
        >
          <span>Avançar Crônica</span>
          <FastForward className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
