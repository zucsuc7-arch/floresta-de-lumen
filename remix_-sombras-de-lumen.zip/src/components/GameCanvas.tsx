/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { Player, Platform, Enemy, Boss, Projectile, Hazard, Crystal, LightOrb, Particle, Region, DialogueNode } from '../types';
import { audio } from '../audio';
import { ENEMY_SPRITE_TEMPLATES, drawPixelSprite } from '../sprites';
import { ChevronLeft, ChevronRight, ChevronUp, Sword, Zap, Hammer, Sliders, RotateCcw, X, Flame, Save, Grid } from 'lucide-react';

export interface HudButtonConfig {
  id: string;
  label: string;
  key: string;
  icon: string;
  x: number;
  y: number;
  scale: number;
  opacity?: number;
}

export const DEFAULT_HUD_BUTTONS: HudButtonConfig[] = [
  { id: 'left', label: 'Esq.', key: 'KeyA', icon: 'left', x: 8, y: 76, scale: 1.0, opacity: 1.0 },
  { id: 'right', label: 'Dir.', key: 'KeyD', icon: 'right', x: 22, y: 76, scale: 1.0, opacity: 1.0 },
  { id: 'thrust', label: 'Estocada', key: 'KeyC', icon: 'zap', x: 74, y: 58, scale: 1.0, opacity: 1.0 },
  { id: 'heavy', label: 'Atq. Pesado', key: 'KeyV', icon: 'hammer', x: 88, y: 58, scale: 1.0, opacity: 1.0 },
  { id: 'net', label: 'Rede', key: 'KeyX', icon: 'net', x: 60, y: 76, scale: 1.0, opacity: 1.0 },
  { id: 'normal', label: 'Atq. Normal', key: 'KeyZ', icon: 'sword', x: 74, y: 80, scale: 1.0, opacity: 1.0 },
  { id: 'jump', label: 'Pulo', key: 'KeyW', icon: 'up', x: 88, y: 80, scale: 1.0, opacity: 1.0 },
  { id: 'swordBar', label: 'Carga Espada', key: '', icon: 'bar', x: 50, y: 92, scale: 1.0, opacity: 1.0 }
];

interface GameCanvasProps {
  currentLevelIdx: number;
  difficulty: 'easy' | 'normal' | 'hard' | 'impossible';
  onDeath: () => void;
  onCompleteLevel: () => void;
  onTrophyUnlocked: (id: string) => void;
  onUpdateHUD: (player: Player, lightPct: number, shadowPct: number, gatheredCrys: number, totalCrys: number, aggroPct: number) => void;
  regions: Region[];
  isPaused: boolean;
  onShowDialogue: (nodes: DialogueNode[]) => void;
  activeRegion: Region;
  playerProgression: {
    level: number;
    xp: number;
    maxXp: number;
    statPoints: number;
    vitalidade: number;
    destreza: number;
    forca: number;
    resistencia: number;
    manaStat: number;
  };
  isEditingHud?: boolean;
  onExitEditHud?: () => void;
  isPortrait?: boolean;
}

const GRAVITY = 0.6;
const GROUND_Y = 520;
const CANVAS_WIDTH = 960;
const CANVAS_HEIGHT = 640;

const REGION_LORE_TEMPLATES: Record<number, Array<{ title: string; text: string }>> = {
  0: [
    { title: 'Diário de Patrulha - Início', text: 'Iniciando a patrulha nos confins do Parque Nacional de Lumen. Sinto o cheiro de fumaça e destruição cobrindo a mata outrora viva. Eu preciso me levantar e brandir meu cacetete tático.' },
    { title: 'Códice dos Protetores', text: 'Os criminosos ambientais vigiam esta reserva florestal. O Comandante Brasa enviou capatazes para queimar e desmatar tudo. Mas a nossa dedicação à natureza resiste no fundo do peito.' },
    { title: 'Instruções do Compartimento', text: 'Mensagem da Central: "A força pura não basta, Agente de Lumen. Reúna os pacotes de sementes e suprimentos nas clareiras para restaurar sua vitalidade e Força da Rede máxima antes de avançar!"' }
  ],
  1: [
    { title: 'Monitor de Cidade Prisma', text: 'Os criminosos transformaram esta antiga metrópole verde em um centro de extração e poluição industrial. Seus vigilantes patrulham as ruas em busca de infratores do ecossistema. Fique atento às barreiras de laser!' },
    { title: 'Relatório de Absorção', text: 'Análise de campo: "Os geradores eletromagnéticos dos desmatadores criam barreiras de alta energia. Use a Barreira Tática [F] para absorver temporariamente as descargas e proteger sua retaguarda."' },
    { title: 'Fundações Ecológicas de Risco', text: 'Um aviso piscando na tela: "Cuidado: As plataformas de fusão e andaimes estão colapsando ao toque devido à corrosão ácida das indústrias. Salte rapidamente antes de despencar no abismo!"' }
  ],
  2: [
    { title: 'Códice dos Antigos Pinhais', text: 'As canopas de bambu sussurram a história da antiga aliança entre a humanidade e a mata. O musgo bioluminescente brilha intensamente quando você empunha o cacetete tático carregado de sintonias ecológicas.' },
    { title: 'Alerta da Floresta Nébula', text: 'Transmissão tática interceptada: "A Árvore Ancestral está sofrendo com brotos de fungos parasitas criados em laboratório pelos poluidores. Use o Dispersor Sônico com seu cacetete para restaurar o fluxo vital!"' },
    { title: 'Código de Conduta Verde', text: 'Este santuário esconde abrigos de guarda-florestais esquecidos, onde antigos protetores faziam suas rondas e meditavam em silêncio eterno, zelando pela fauna e flora nativas contra caçadores.' }
  ],
  3: [
    { title: 'Alerta de Anomalia de Gravidade', text: 'O megainversor magnético das indústrias clandestinas está distorcendo a gravidade local na Área Eclipse. As zonas de impulsão alterada afetam seu salto. Drones hostis buscam drenar sua Força da Rede.' },
    { title: 'Registro de Operações Clandestinas', text: 'A guarda tática militar do Comandante Brasa aguarda o Agente nas muralhas de ferro. Eles utilizam escudos eletromagnéticos reforçados. Para neutralizá-los, espere pelas aberturas em suas defesas!' },
    { title: 'Provérbio da Conservação', text: '"Quem fecha os olhos para a destruição de uma única folha nunca compreenderá a vastidão viva da biosfera." Mantenha o foco, a calma tática e a dedicação à defesa da vida selvagem!' }
  ],
  4: [
    { title: 'Central do Núcleo de Lumen', text: 'Você finalmente alcançou a central de comando da megacorporação poluidora. O Comandante Brasa se fundiu com o reator industrial para incinerar o Coração de Lumen. A batalha final decidirá o futuro da preservação...' },
    { title: 'Fichário de Reclamação Ambiental', text: 'O Altar do Trono e o núcleo de refrigeração exigem o acionamento de segurança dos terminais de contenção ecológica. Se a energia limpa purificar o núcleo, a floresta viverá. Se as caldeiras explodirem, as cinzas reinarão.' },
    { title: 'Profecia de Lumen', text: 'No fim da jornada ecológico-tecnológica, o Agente de Lumen e a própria floresta se harmonizam. Toda a sua dedicação, força e energia de rede serão devolvidos à terra, iniciando uma nova era de preservação eterna.' }
  ]
};

const ENEMY_DEFS = [
  { name: 'Madeireiro com Machado', hp: 32, spd: 1.3, w: 51, h: 58, col: '#bd2424', eCol: '#bfcbde', atk: 'melee', aDmg: 8, aRng: 40, aCD: 65, beh: 'patrol', flying: false, spriteType: 'woodcutter' },
  { name: 'Urubu-da-Queimada', hp: 16, spd: 1.6, w: 54, h: 45, col: '#14171a', eCol: '#bd2424', atk: 'dive', aDmg: 5, aRng: 160, aCD: 85, beh: 'fly_dive', flying: true, flyAmp: 25, flyFreq: 0.012, pCol: '#bd2424', spriteType: 'vulture_bird' },
  { name: 'Atirador Clandestino', hp: 42, spd: 0.9, w: 51, h: 58, col: '#48704b', eCol: '#ffcc00', atk: 'projectile', aDmg: 12, aRng: 260, aCD: 95, beh: 'ranged', flying: false, pCol: '#ffcc00', spriteType: 'poacher_gun' },
  { name: 'Poluidor Químico', hp: 48, spd: 0.9, w: 51, h: 58, col: '#2a6930', eCol: '#14171a', atk: 'area', aDmg: 10, aRng: 85, aCD: 110, beh: 'ambush', flying: false, pCol: '#14171a', spriteType: 'waste_pourer' },
  { name: 'Drone de Vigilância', hp: 28, spd: 2.1, w: 48, h: 42, col: '#bfcbde', eCol: '#bd2424', atk: 'teleport', aDmg: 11, aRng: 170, aCD: 75, beh: 'fly_teleport', flying: true, flyAmp: 50, flyFreq: 0.02, pCol: '#bd2424', spriteType: 'tracking_drone' },
  { name: 'Operador de Trator', hp: 85, spd: 1.5, w: 74, h: 67, col: '#14171a', eCol: '#bd2424', atk: 'charge', aDmg: 18, aRng: 220, aCD: 120, beh: 'charge', flying: false, pCol: '#bd2424', spriteType: 'bulldozer_man' },
  { name: 'Caçador de Redes', hp: 55, spd: 1.8, w: 51, h: 58, col: '#7c4e2d', eCol: '#ece7e1', atk: 'combo', aDmg: 9, aRng: 50, aCD: 45, beh: 'aggressive', flying: false, spriteType: 'animal_trapper' },
  { name: 'Carregador de Troncos', hp: 38, spd: 1.4, w: 51, h: 58, col: '#7c4e2d', eCol: '#cf913c', atk: 'projectile', aDmg: 14, aRng: 200, aCD: 100, beh: 'ranged', flying: false, pCol: '#cf913c', spriteType: 'lumber_carrier' },
  { name: 'Incinerador Clandestino', hp: 45, spd: 1.2, w: 51, h: 58, col: '#bd2424', eCol: '#ff5100', atk: 'area', aDmg: 12, aRng: 100, aCD: 80, beh: 'patrol', flying: false, pCol: '#ff5100', spriteType: 'incinerator' },
  { name: 'Vigilante do Capitão', hp: 35, spd: 1.5, w: 51, h: 58, col: '#7c4e2d', eCol: '#ece7e1', atk: 'projectile', aDmg: 8, aRng: 180, aCD: 75, beh: 'patrol', flying: false, pCol: '#ece7e1', spriteType: 'patrol_lookout' }
];

const BOSS_DEFS: Record<number, { name: string; hp: number; w: number; h: number; col: string; phases: { hp: number; atk: string[]; spd: number }[] }> = {
  20: {
    name: 'Capitão Machado (Motosserra)',
    hp: 300, w: 120, h: 120, col: '#bd2424',
    phases: [
      { hp: 300, atk: ['light_dash', 'light_beam'], spd: 2.0 },
      { hp: 200, atk: ['light_dash', 'light_beam', 'summon'], spd: 2.5 },
      { hp: 100, atk: ['light_dash', 'light_beam', 'summon', 'explosion'], spd: 3.0 }
    ]
  },
  40: {
    name: 'Barão do Mercúrio (Poluição)',
    hp: 400, w: 128, h: 128, col: '#14171a',
    phases: [
      { hp: 400, atk: ['clone', 'prism_shot'], spd: 1.5 },
      { hp: 260, atk: ['clone', 'prism_shot', 'mirror'], spd: 2.0 },
      { hp: 130, atk: ['clone', 'prism_shot', 'mirror', 'rush'], spd: 2.5 }
    ]
  },
  60: {
    name: 'Senhor das Armadilhas (Tráfico)',
    hp: 500, w: 150, h: 150, col: '#7c4e2d',
    phases: [
      { hp: 500, atk: ['root', 'poison'], spd: 0.5 },
      { hp: 333, atk: ['root', 'poison', 'entangle'], spd: 0.8 },
      { hp: 166, atk: ['root', 'poison', 'entangle', 'sweep'], spd: 1.2 }
    ]
  },
  80: {
    name: 'Doutor Biopirata (Contrabando)',
    hp: 600, w: 135, h: 135, col: '#2a6930',
    phases: [
      { hp: 600, atk: ['dark_beam', 'shadow_tp'], spd: 2.0 },
      { hp: 400, atk: ['dark_beam', 'shadow_tp', 'void_orbs'], spd: 2.5 },
      { hp: 200, atk: ['dark_beam', 'shadow_tp', 'void_orbs', 'dark_pulse'], spd: 3.0 }
    ]
  },
  100: {
    name: 'Comandante Brasa (Megainvestidor Corrupto)',
    hp: 800, w: 165, h: 165, col: '#ff5100',
    phases: [
      { hp: 800, atk: ['annihilation', 'shadow_lasers', 'phase_shift'], spd: 2.0 },
      { hp: 533, atk: ['annihilation', 'shadow_lasers', 'phase_shift', 'meteor'], spd: 2.5 },
      { hp: 266, atk: ['annihilation', 'shadow_lasers', 'phase_shift', 'meteor', 'void_exp', 'clone_army'], spd: 3.0 }
    ]
  }
};

const MINIBOSS_TEMPLATES = [
  { name: 'Feitor Clandestino de Desmatamento', hp: 150, w: 93, h: 93, col: '#bd2424', phaseHP: 50, atk: 'charge' },
  { name: 'Guarda Linha de Vigilância', hp: 180, w: 85, h: 78, col: '#7c4e2d', phaseHP: 60, atk: 'projectile' },
  { name: 'Traficante Corporativo Superior', hp: 200, w: 101, h: 101, col: '#48704b', phaseHP: 67, atk: 'aura' }
];

export const GameCanvas: React.FC<GameCanvasProps> = ({
  currentLevelIdx,
  difficulty,
  onDeath,
  onCompleteLevel,
  onTrophyUnlocked,
  onUpdateHUD,
  regions,
  isPaused,
  onShowDialogue,
  activeRegion,
  playerProgression,
  isEditingHud = false,
  onExitEditHud,
  isPortrait = false
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Keyboard controls mapper
  const keysRef = useRef<Record<string, boolean>>({});

  // HUD layout settings state and handlers
  const [hudButtons, setHudButtons] = useState<HudButtonConfig[]>(() => {
    try {
      const saved = localStorage.getItem('mobile_hud_layout_v3');
      if (saved) {
        const parsed = JSON.parse(saved) as HudButtonConfig[];
        // Auto-migrate to guarantee presence of net button in case of older saved layouts
        if (!parsed.some(b => b.id === 'net')) {
          const defaultNet = DEFAULT_HUD_BUTTONS.find(b => b.id === 'net');
          if (defaultNet) {
            parsed.push(defaultNet);
          }
        }
        return parsed;
      }
    } catch (e) {}
    return DEFAULT_HUD_BUTTONS;
  });

  const [activeDragId, setActiveDragId] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const handlePointerDown = (id: string, e: React.PointerEvent) => {
    e.preventDefault();
    setActiveDragId(id);
    try {
      (e.target as HTMLElement).setPointerCapture(e.pointerId);
    } catch (err) {}
  };

  const handlePointerMove = (id: string, e: React.PointerEvent) => {
    if (activeDragId !== id) return;
    if (!containerRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const styledW = isPortrait ? 640 : 960;
    const styledH = isPortrait ? 960 : 640;

    // Use the physical screen center of the bounding rect as the transform origin
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    // Viewport-relative offset from center in physical pixels
    const dx = e.clientX - centerX;
    const dy = e.clientY - centerY;

    // Outer screen scaling ratio
    const scaleVal = rect.width / 960;
    if (scaleVal <= 0) return;

    // Restore offset back to unscaled canvas pixels
    const dx_unscaled = dx / scaleVal;
    const dy_unscaled = dy / scaleVal;

    // Rotate offset back into local canvas space (undoing 'rotate(90deg)' when in portrait)
    let localDx = dx_unscaled;
    let localDy = dy_unscaled;
    if (isPortrait) {
      localDx = dy_unscaled;
      localDy = -dx_unscaled;
    }

    // Translate back to local top-left coordinates
    const localX = (styledW / 2) + localDx;
    const localY = (styledH / 2) + localDy;

    // Convert back to percentages of styled layout dimensions
    const relativeX = (localX / styledW) * 100;
    const relativeY = (localY / styledH) * 100;

    const clampedX = Math.max(2, Math.min(98, relativeX));
    const clampedY = Math.max(5, Math.min(95, relativeY));

    setHudButtons((prev) =>
      prev.map((btn) => (btn.id === id ? { ...btn, x: Number(clampedX.toFixed(2)), y: Number(clampedY.toFixed(2)) } : btn))
    );
  };

  const handlePointerUp = (id: string, e: React.PointerEvent) => {
    if (activeDragId === id) {
      setActiveDragId(null);
      try {
        (e.target as HTMLElement).releasePointerCapture(e.pointerId);
      } catch (err) {}
    }
  };

  const adjustScale = (id: string, amt: number) => {
    setHudButtons((prev) =>
      prev.map((btn) => {
        if (btn.id === id) {
          const newScale = Math.max(0.5, Math.min(2.0, btn.scale + amt));
          return { ...btn, scale: Number(newScale.toFixed(2)) };
        }
        return btn;
      })
    );
  };

  const adjustOpacity = (id: string, amt: number) => {
    setHudButtons((prev) =>
      prev.map((btn) => {
        if (btn.id === id) {
          const currentOpacity = btn.opacity !== undefined ? btn.opacity : 1.0;
          const newOpacity = Math.max(0.1, Math.min(1.0, currentOpacity + amt));
          return { ...btn, opacity: Number(newOpacity.toFixed(2)) };
        }
        return btn;
      })
    );
  };

  const handleSaveHud = () => {
    try {
      localStorage.setItem('mobile_hud_layout_v3', JSON.stringify(hudButtons));
      window.dispatchEvent(new Event('hud_layout_updated'));
    } catch (e) {}
    audio.playSFX('crystal');
    if (onExitEditHud) onExitEditHud();
  };

  const handleCancelHud = () => {
    try {
      const saved = localStorage.getItem('mobile_hud_layout_v3');
      if (saved) {
        const parsed = JSON.parse(saved) as HudButtonConfig[];
        if (!parsed.some(b => b.id === 'net')) {
          const defaultNet = DEFAULT_HUD_BUTTONS.find(b => b.id === 'net');
          if (defaultNet) parsed.push(defaultNet);
        }
        setHudButtons(parsed);
      } else {
        setHudButtons(DEFAULT_HUD_BUTTONS);
      }
    } catch (e) {}
    audio.playSFX('jump');
    if (onExitEditHud) onExitEditHud();
  };

  const handleRestoreHud = () => {
    try {
      const saved = localStorage.getItem('mobile_hud_layout_v3');
      if (saved) {
        const parsed = JSON.parse(saved) as HudButtonConfig[];
        if (!parsed.some(b => b.id === 'net')) {
          const defaultNet = DEFAULT_HUD_BUTTONS.find(b => b.id === 'net');
          if (defaultNet) parsed.push(defaultNet);
        }
        setHudButtons(parsed);
      } else {
        setHudButtons(DEFAULT_HUD_BUTTONS);
      }
    } catch (e) {
      setHudButtons(DEFAULT_HUD_BUTTONS);
    }
    audio.playSFX('win');
  };

  // Engine loop states
  const [lightPower, setLightPower] = useState<number>(0);
  const [shadowPower, setShadowPower] = useState<number>(0);

  // Game Engine dynamic objects refs
  const globalTimerRef = useRef<number>(0);
  const screenShakeRef = useRef<number>(0);
  const cameraXRef = useRef<number>(0);
  const levelWidthRef = useRef<number>(3000);
  
  const playerRef = useRef<Player>({
    x: 100, y: GROUND_Y - 56, w: 40, h: 56, vx: 0, vy: 0,
    spd: 3.0, jF: -13, hp: 100, mxHp: 100, mana: 100, mxMana: 100,
    og: false, fac: 1, atk: false, atkT: 0, combo: 0, comboT: 0,
    curAtk: 'normal', mType: 'fireball', specReady: true, specCD: 0,
    jumps: 2, maxJumps: 2, dashCD: 0, ascPhase: 0, animFrame: 0, animTimer: 0,
    swordKillsCharge: 0,
    stamina: 40,
    mxStamina: 40,
    level: 0,
    xp: 0,
    maxXp: 100,
    statPoints: 0,
    vitalidade: 0,
    destreza: 0,
    forca: 0,
    resistencia: 0,
    manaStat: 0,
    tempShieldT: 0,
    tempShieldCD: 0
  });

  const platformsRef = useRef<Platform[]>([]);
  const enemiesRef = useRef<Enemy[]>([]);
  const projectilesRef = useRef<Projectile[]>([]);
  const hazardsRef = useRef<Hazard[]>([]);
  const crystalsRef = useRef<Crystal[]>([]);
  const lightOrbsRef = useRef<LightOrb[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const bossRef = useRef<Boss | null>(null);
  const storyScrollsRef = useRef<Array<{ x: number; y: number; col: boolean; title: string; text: string }>>([]);

  const levelCompletedTriggered = useRef<boolean>(false);
  const levelCrystalsTotal = useRef<number>(3);
  const levelsCooldowns = useRef({ attack: 0, magic: 0, thrust: 0, heavy: 0 });

  const isPausedRef = useRef(isPaused);
  useEffect(() => {
    isPausedRef.current = isPaused;
  }, [isPaused]);

  useEffect(() => {
    try {
      const saved = localStorage.getItem('mobile_hud_layout_v3');
      if (saved) {
        const parsed = JSON.parse(saved) as HudButtonConfig[];
        if (!parsed.some(b => b.id === 'net')) {
          const defaultNet = DEFAULT_HUD_BUTTONS.find(b => b.id === 'net');
          if (defaultNet) parsed.push(defaultNet);
        }
        setHudButtons(parsed);
      } else {
        setHudButtons(DEFAULT_HUD_BUTTONS);
      }
    } catch (e) {}
  }, [isEditingHud]);

  // Initializing loop
  useEffect(() => {
    // Generate the Level Map
    generateLevelMap(currentLevelIdx);
    
    const handleKeyDown = (e: KeyboardEvent) => {
      keysRef.current[e.code] = true;
      if (['ArrowUp', 'ArrowDown', 'Space', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
        e.preventDefault();
      }
    };
    
    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.code] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    // Audio theme looping standard launch
    audio.playMusic();

    let animId: number;
    const loop = () => {
      if (!isPausedRef.current) {
        updateGamePhysics();
      }
      renderCanvas();
      animId = requestAnimationFrame(loop);
    };
    animId = requestAnimationFrame(loop);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      cancelAnimationFrame(animId);
      audio.stopMusic();
    };
  }, [currentLevelIdx, difficulty]);

  // Synchronize progression changes from parent React state
  useEffect(() => {
    const player = playerRef.current;
    player.level = playerProgression.level;
    player.xp = playerProgression.xp;
    player.maxXp = playerProgression.maxXp;
    player.statPoints = playerProgression.statPoints;
    player.vitalidade = playerProgression.vitalidade;
    player.destreza = playerProgression.destreza;
    player.forca = playerProgression.forca;
    player.resistencia = playerProgression.resistencia;
    player.manaStat = playerProgression.manaStat;

    let defaultHp = 100;
    if (difficulty === 'easy') defaultHp = 130;
    else if (difficulty === 'hard') defaultHp = 80;
    else if (difficulty === 'impossible') defaultHp = 60;

    const prevMaxHp = player.mxHp;
    player.mxHp = defaultHp + player.vitalidade * 15;
    if (player.mxHp > prevMaxHp) {
      player.hp += (player.mxHp - prevMaxHp);
    }

    const prevMaxMana = player.mxMana;
    player.mxMana = defaultHp + player.manaStat * 15;
    if (player.mxMana > prevMaxMana) {
      player.mana += (player.mxMana - prevMaxMana);
    }

    const prevMaxStamina = player.mxStamina || 40;
    player.mxStamina = 40 + player.destreza * 15;
    if (player.mxStamina > prevMaxStamina) {
      player.stamina = (player.stamina || 40) + (player.mxStamina - prevMaxStamina);
    }
    // Also clamp stamina in case destreza was reset
    player.stamina = Math.min(player.mxStamina, player.stamina || 40);

    player.spd = 3.0 + player.destreza * 0.35;

    broadcastState();
  }, [playerProgression, difficulty]);

  // Seed generator mechanics (deterministic random based on level index)
  const getSeededRandom = (seed: number) => {
    let s = seed;
    return () => {
      s = (s * 16807) % 2147483647;
      return (s - 1) / 2147483646;
    };
  };

  const getDifficultyMultipliers = () => {
    // Return static multipliers per difficulty to avoid exponential/double-scale factors with level.
    switch (difficulty) {
      case 'easy':
        return { hpMult: 0.65, dmgMult: 0.5, spdMult: 0.8, enemyCount: 0.7, hazCount: 0.6, bossHp: 0.65 };
      case 'impossible':
        return { hpMult: 1.8, dmgMult: 1.6, spdMult: 1.3, enemyCount: 1.35, hazCount: 1.3, bossHp: 1.5 };
      case 'hard':
        return { hpMult: 1.3, dmgMult: 1.25, spdMult: 1.15, enemyCount: 1.15, hazCount: 1.15, bossHp: 1.2 };
      case 'normal':
      default:
        return { hpMult: 1.0, dmgMult: 1.0, spdMult: 1.0, enemyCount: 1.0, hazCount: 1.0, bossHp: 1.0 };
    }
  };

  const generateLevelMap = (lvlIdx: number) => {
    const regionIdx = Math.floor(lvlIdx / 20);
    const inRegionLvl = lvlIdx % 20;
    const seed = lvlIdx * 3421 + 2500;
    const rng = getSeededRandom(seed);
    const dm = getDifficultyMultipliers();
    
    // Balanced linear progression coefficients per level index
    const lvlHpScale = 1 + lvlIdx * 0.008;
    const lvlDmgScale = 1 + lvlIdx * 0.004;
    
    // Calculated level boundaries - MUCH LARGER LEVEL SIZES FOR MAJESTIC ADVENTURES
    const lWidth = 9800 + inRegionLvl * 600 + lvlIdx * 200;
    levelWidthRef.current = lWidth;
    levelCompletedTriggered.current = false;
    
    // Dynamic lists flush
    platformsRef.current = [];
    enemiesRef.current = [];
    projectilesRef.current = [];
    hazardsRef.current = [];
    crystalsRef.current = [];
    lightOrbsRef.current = [];
    particlesRef.current = [];
    storyScrollsRef.current = [];
    bossRef.current = null;
    cameraXRef.current = 0;
    
    // Stable ground platform
    // We generate a beautiful, rugged segmented landscape with reliefs, hills, and subterranean tunnels!
    const tunnelZones: { start: number; end: number }[] = [];
    
    // Define 2 or 3 subterranean tunnel zones based on the total level width 'lWidth'
    const numTunnels = lWidth > 12000 ? 3 : 2;
    for (let t = 0; t < numTunnels; t++) {
      const startPerc = 0.22 + t * 0.28 + rng() * 0.05;
      const tStartX = Math.floor(lWidth * startPerc);
      const tEndX = tStartX + 850 + Math.floor(rng() * 250);
      tunnelZones.push({ start: tStartX, end: tEndX });
    }

    let currentX = 0;
    while (currentX < lWidth) {
      // Ensure starting area (x < 450) and final area (x > lWidth - 850) are flat standard ground
      if (currentX < 450 || currentX > lWidth - 850) {
        const segW = currentX < 450 ? (450 - currentX) : (lWidth - currentX);
        platformsRef.current.push({
          x: currentX,
          y: GROUND_Y,
          w: segW,
          h: 640 - GROUND_Y,
          type: 'ground',
          active: true
        });
        currentX += segW;
        continue;
      }

      // Check if currentX lies inside any procedurally selected tunnel zone
      const activeTunnel = tunnelZones.find(tz => currentX >= tz.start && currentX < tz.end);
      
      if (activeTunnel) {
        const tStart = activeTunnel.start;
        const tEnd = activeTunnel.end;
        const tLength = tEnd - tStart;
        
        // 1. Create upper solid ground floor (which acts as the tunnel's outer ceiling) at y = 440
        platformsRef.current.push({
          x: tStart + 90,
          y: 440,
          w: tLength - 180,
          h: 24,
          type: 'ground',
          active: true
        });

        // 2. Create the deep lower tunnel floor corridor at y = 575
        platformsRef.current.push({
          x: tStart + 70,
          y: 575,
          w: tLength - 140,
          h: 120,
          type: 'ground',
          active: true
        });

        // 3. Left Entrance side structures (Solid y=520, and steps)
        platformsRef.current.push({
          x: tStart - 20,
          y: 520,
          w: 100,
          h: 120,
          type: 'ground',
          active: true
        });
        
        // 4. Right Entrance side structures (Solid y=520)
        platformsRef.current.push({
          x: tEnd - 80,
          y: 520,
          w: 100,
          h: 120,
          type: 'ground',
          active: true
        });

        // 6. Spawn guaranteed tunnel-guarding enemies inside this shortcut!
        const numTunnelEnemies = 2 + Math.floor(rng() * 2);
        for (let te = 0; te < numTunnelEnemies; te++) {
          const ex = tStart + 160 + te * 220 + rng() * 80;
          const eTypeIdx = Math.min(regionIdx + (te % 2), ENEMY_DEFS.length - 1);
          const edVal = ENEMY_DEFS[eTypeIdx];
          
          enemiesRef.current.push({
            x: ex,
            y: 575 - edVal.h,
            w: edVal.w,
            h: edVal.h,
            vx: edVal.spd * (0.6 + rng() * 0.4) * dm.spdMult,
            hp: Math.floor(edVal.hp * lvlHpScale * dm.hpMult),
            mxHp: Math.floor(edVal.hp * lvlHpScale * dm.hpMult),
            tn: edVal.name,
            col: edVal.col,
            eCol: edVal.eCol,
            alive: true,
            dir: rng() > 0.5 ? 1 : -1,
            rng2: 90 + rng() * 160,
            sx: ex,
            at: Math.floor(rng() * edVal.aCD),
            aCd: edVal.aCD,
            atk: edVal.atk as any,
            ad: Math.floor(edVal.aDmg * lvlDmgScale * dm.dmgMult),
            ar: edVal.aRng,
            beh: edVal.beh as any,
            pc: edVal.pCol || '#ff4444',
            flying: false,
            fy: 0,
            flyAmp: edVal.flyAmp,
            flyFreq: edVal.flyFreq,
            flyBase: 0,
            flyT: 0,
            stun: 0,
            spriteType: edVal.spriteType,
            animFrame: 0,
            animTimer: 0
          });
        }

        // 7. Spark extra Crystals and Light Orbs rewards in this shortcut!
        crystalsRef.current.push({
          x: tStart + Math.floor(tLength * 0.35),
          y: 545,
          col: false
        });
        crystalsRef.current.push({
          x: tStart + Math.floor(tLength * 0.65),
          y: 545,
          col: false
        });

        lightOrbsRef.current.push({
          x: tStart + Math.floor(tLength * 0.5),
          y: 512,
          active: true
        });

        currentX = tEnd;
      } else {
        // --- Regular Ground with Reliefs, ridges, and mounds ---
        const segW = 200 + Math.floor(rng() * 200);
        const randVal = rng();
        let segY = GROUND_Y; // default 520
        
        if (randVal < 0.24) {
          segY = 480; // moderate bump / ridge
        } else if (randVal < 0.42) {
          segY = 440; // high plateau / ruins hill elevation
        }

        platformsRef.current.push({
          x: currentX,
          y: segY,
          w: Math.min(segW, lWidth - currentX),
          h: 640 - segY,
          type: 'ground',
          active: true
        });

        // No stepped transitions to keep floor completely flat and clean

        currentX += segW;
      }
    }


    
    // Layout platforms - SPAWN MORE FOR COHESIVE PLATFORMING ACROSS MUCH LARGER LEVELS
    const numPlatforms = 42 + Math.floor(rng() * 32) + inRegionLvl * 4;
    const potentialPlatTypes: Array<Platform['type']> = [
      'platform', 'moving_platform', 'ice', 'bounce_pad', 'vanish_platform', 'crumble_platform', 'mirror', 'shadow_zone', 'light_trap'
    ];
    // Shrink index options for earlier regions to smooth learning curve
    const maxPlatTypeRange = Math.min(6 + regionIdx * 2, 9);
    
    for (let i = 0; i < numPlatforms; i++) {
      const px = 180 + rng() * (lWidth - 400);
      const gy = getGroundYAt(px);
      // Ensure floating platforms hover high and cleanly in the air well above whichever relief level is beneath them
      const py = Math.max(80, gy - 180 - rng() * 160);
      const pw = 70 + rng() * 110;
      const typeSel = potentialPlatTypes[Math.floor(rng() * maxPlatTypeRange)];
      
      platformsRef.current.push({
        x: px, y: py, w: pw, h: 16,
        type: typeSel,
        active: true,
        mx: typeSel === 'moving_platform' ? rng() * 120 : 0,
        my: typeSel === 'moving_platform' ? rng() * 80 : 0,
        sx: px, sy: py,
        mt: rng() * 1000,
        ms: 0.6 + rng() * 1.5,
        vt: 0, van: false, ct: 0, cr: false
      });
    }

    // Spawn 3 Floating Lore Books/Scrolls per level for story integration across longer paths!
    const loreList = REGION_LORE_TEMPLATES[regionIdx % 5] || REGION_LORE_TEMPLATES[0];
    const numScrollsToSpawn = 3;
    for (let sIdx = 0; sIdx < numScrollsToSpawn; sIdx++) {
      const scrollPosPerc = sIdx === 0 ? 0.25 : sIdx === 1 ? 0.55 : 0.85;
      const scrollX = Math.floor(lWidth * scrollPosPerc);
      const gy = getGroundYAt(scrollX);
      
      // Look for a nearby ground/platform to place it on the floor
      let scrollY = gy - 12; // Sits on the ground
      const nearestPlatform = platformsRef.current.find(pf => pf.type !== 'ground' && Math.abs(pf.x + pf.w/2 - scrollX) < 150);
      if (nearestPlatform) {
        scrollY = nearestPlatform.y - 12; // Sits on the platform floor
      }

      const loreItem = loreList[sIdx % loreList.length];
      storyScrollsRef.current.push({
        x: scrollX,
        y: scrollY,
        col: false,
        title: loreItem.title,
        text: loreItem.text
      });
    }

    // Boss spawning checklist
    const bossLevel = lvlIdx + 1;
    const isBossMilestone = bossLevel % 10 === 0;
    if (isBossMilestone) {
      const isMajor = bossLevel % 20 === 0;
      const bDef = isMajor 
        ? BOSS_DEFS[bossLevel] 
        : bDefsFromTemplate(bossLevel);

      const bossHpScale = 1 + lvlIdx * 0.012;
      const bossHpCalculated = Math.floor(bDef.hp * bossHpScale * dm.bossHp);
      
      const speedVal = isMajor
        ? (bDef as any).phases[0].spd
        : (bDef as any).spd;

      const attacksVal = isMajor
        ? (bDef as any).phases[0].atk
        : (bDef as any).atks;

      const bossX = lWidth - 280;
      const bossGy = getGroundYAt(bossX);

      bossRef.current = {
        x: bossX,
        y: bossGy - bDef.h,
        w: bDef.w,
        h: bDef.h,
        hp: bossHpCalculated,
        mxHp: bossHpCalculated,
        pIdx: 0,
        at2: 0,
        mt2: 0,
        dir: -1,
        spd: speedVal * dm.spdMult,
        alive: true,
        ft: 0,
        name: bDef.name,
        atks: attacksVal,
        col: bDef.col,
        ct2: 0,
        isMajor,
        flying: false,
        region: regionIdx,
        phaseHP: Math.floor(bDef.hp * (isMajor ? 0.33 : 0.5) * dm.bossHp),
        fy: bossGy - bDef.h,
        flyT: 0,
        animFrame: 0,
        animTimer: 0
      };
    } else {
      // Spawn regular minions - scaled appropriately for much larger levels
      const calculatedMaxEnemies = Math.floor((8 + currentLevelIdx * 0.35 + rng() * 8) * dm.enemyCount);
      for (let i = 0; i < calculatedMaxEnemies; i++) {
        const ex = 320 + rng() * (lWidth - 550);
        const eTypeIdx = Math.min(regionIdx + Math.floor(rng() * 3), ENEMY_DEFS.length - 1);
        const edVal = ENEMY_DEFS[eTypeIdx];
        const gy = getGroundYAt(ex);
        
        enemiesRef.current.push({
          x: ex,
          y: edVal.flying ? 160 + rng() * 180 : gy - edVal.h,
          w: edVal.w,
          h: edVal.h,
          vx: edVal.spd * (0.6 + rng() * 0.5) * dm.spdMult,
          hp: Math.floor(edVal.hp * lvlHpScale * dm.hpMult),
          mxHp: Math.floor(edVal.hp * lvlHpScale * dm.hpMult),
          tn: edVal.name,
          col: edVal.col,
          eCol: edVal.eCol,
          alive: true,
          dir: rng() > 0.5 ? 1 : -1,
          rng2: 90 + rng() * 160,
          sx: ex,
          at: Math.floor(rng() * edVal.aCD),
          aCd: edVal.aCD,
          atk: edVal.atk as any,
          ad: Math.floor(edVal.aDmg * lvlDmgScale * dm.dmgMult),
          ar: edVal.aRng,
          beh: edVal.beh as any,
          pc: edVal.pCol || '#ff4444',
          flying: edVal.flying,
          fy: edVal.flying ? 160 + rng() * 180 : 0,
          flyAmp: edVal.flyAmp,
          flyFreq: edVal.flyFreq,
          flyBase: edVal.flying ? 160 + rng() * 180 : 0,
          flyT: rng() * 100,
          stun: 0,
          spriteType: edVal.spriteType,
          animFrame: 0,
          animTimer: 0
        });
      }
    }

    // Crystals placement (collectible fragments) - scaled for larger levels
    const crystalCount = 5;
    levelCrystalsTotal.current = crystalCount;
    for (let i = 0; i < crystalCount; i++) {
      const matchingPlatIdx = i % platformsRef.current.length;
      const matchingPlat = platformsRef.current[matchingPlatIdx];
      const cx = matchingPlat ? matchingPlat.x + matchingPlat.w / 2 : 400 + i * 350;
      const gy = getGroundYAt(cx);
      crystalsRef.current.push({
        x: cx,
        y: matchingPlat && matchingPlat.type !== 'ground' ? matchingPlat.y - 30 : gy - 30,
        col: false
      });
    }

    // Hazards spawning - Only spawning larger, dynamic moving spikes - strategically spaced to never overlap
    const hazardCount = Math.floor((8 + currentLevelIdx * 0.35 + rng() * 8) * dm.hazCount);
    const placedSpikeXs: number[] = [];

    for (let i = 0; i < hazardCount; i++) {
      let hx = 0;
      let valid = false;
      let attempts = 0;

      while (!valid && attempts < 100) {
        attempts++;
        // Generate a candidate position: keep 420px away from starting line and 450px away from the end boss/portal areas
        const candidateX = 420 + rng() * (lWidth - 870);

        // Ensure it doesn't overlap existing placed spikes by at least 220 pixels
        let tooClose = false;
        for (const px of placedSpikeXs) {
          if (Math.abs(candidateX - px) < 220) {
            tooClose = true;
            break;
          }
        }

        if (!tooClose) {
          hx = candidateX;
          valid = true;
        }
      }

      // Fallback if we cannot fit perfectly within trials
      if (!valid) {
        hx = 420 + (i * ((lWidth - 870) / Math.max(1, hazardCount))) + rng() * 30;
      }

      placedSpikeXs.push(hx);

      const spikeW = 40; // larger size width
      const spikeH = 46; // larger size height (max protrusion)
      const gy = getGroundYAt(hx);
      hazardsRef.current.push({
        x: hx,
        y: gy, // Starts fully retracted
        w: spikeW,
        h: spikeH,
        type: 'spike',
        active: true,
        baseY: gy,
        state: 'retracted',
        timer: Math.floor(rng() * 160), // staggered starting countdown offset
        life: 0
      });
    }

    // Light spheres (heal, energy) - scaled up for larger levels to cover wider distances
    const lightSphereCount = 7 + Math.floor(regionIdx * 1.5);
    for (let i = 0; i < lightSphereCount; i++) {
      const lx = 350 + rng() * (lWidth - 600);
      const gy = getGroundYAt(lx);
      lightOrbsRef.current.push({
        x: lx,
        y: Math.max(100, gy - 120 - rng() * 120),
        active: true
      });
    }

    // Reset player states
    const playerStatus = playerRef.current;
    
    // Sync shared progression props
    playerStatus.level = playerProgression.level;
    playerStatus.xp = playerProgression.xp;
    playerStatus.maxXp = playerProgression.maxXp;
    playerStatus.statPoints = playerProgression.statPoints;
    playerStatus.vitalidade = playerProgression.vitalidade;
    playerStatus.destreza = playerProgression.destreza;
    playerStatus.forca = playerProgression.forca;
    playerStatus.resistencia = playerProgression.resistencia;
    playerStatus.manaStat = playerProgression.manaStat;

    // Set health according to difficulty settings
    let defaultHp = 100;
    if (difficulty === 'easy') defaultHp = 130;
    else if (difficulty === 'hard') defaultHp = 80;
    else if (difficulty === 'impossible') defaultHp = 60;

    // Apply stats
    playerStatus.mxHp = defaultHp + playerStatus.vitalidade * 15;
    playerStatus.hp = playerStatus.mxHp;
    playerStatus.mxMana = defaultHp + playerStatus.manaStat * 15;
    playerStatus.mana = playerStatus.mxMana;
    playerStatus.mxStamina = 40 + playerStatus.destreza * 15;
    playerStatus.stamina = playerStatus.mxStamina;
    playerStatus.spd = 3.0 + playerStatus.destreza * 0.35;

    playerStatus.x = 100;
    playerStatus.y = GROUND_Y - playerStatus.h;
    playerStatus.vx = 0;
    playerStatus.vy = 0;
    playerStatus.combo = 0;
    playerStatus.comboT = 0;
    playerStatus.jumps = playerStatus.maxJumps;
    playerStatus.atk = false;
    playerStatus.atkT = 0;
    playerStatus.specReady = true;
    playerStatus.specCD = 0;
    playerStatus.ascPhase = Math.floor(lightPower / 20);

    // Initial broadcast
    broadcastState();
  };

  const bDefsFromTemplate = (lvl: number) => {
    const rIdx = Math.floor((lvl - 1) / 20);
    const template = MINIBOSS_TEMPLATES[rIdx % MINIBOSS_TEMPLATES.length];
    return {
      name: `${template.name} #${lvl}`,
      hp: template.hp,
      w: template.w,
      h: template.h,
      col: template.col,
      atks: [template.atk],
      spd: 1.8
    };
  };

  const rAngleGen = (rng: () => number) => {
    return rng() * Math.PI * 2;
  };

  const emitBloodParticles = (x: number, y: number, color: string, count: number, speed: number) => {
    for (let i = 0; i < count; i++) {
      particlesRef.current.push({
        x, y,
        vx: (Math.random() - 0.5) * speed,
        vy: (Math.random() - 0.5) * speed - 2.0,
        life: 30 + Math.random() * 30,
        mxL: 60,
        col: color,
        sz: 2 + Math.random() * 3
      });
    }
  };

  const awardKill = (player: Player) => {
    // Increment sword charge
    player.swordKillsCharge = Math.min(5, (player.swordKillsCharge || 0) + 1);
    
    // Award 10 XP as requested by the user
    player.xp += 10;
    if (player.xp >= player.maxXp) {
      player.xp -= player.maxXp;
      player.level += 1;
      player.statPoints += 1;
      
      // Level Up visual FX and chime
      audio.playSFX('win');
      
      // High-quality gold & cyan celebratory level up ring particles
      for (let i = 0; i < 28; i++) {
        particlesRef.current.push({
          x: player.x + player.w / 2,
          y: player.y + player.h / 2,
          vx: (Math.random() - 0.5) * 6,
          vy: -2 - Math.random() * 5,
          life: 45 + Math.random() * 25,
          mxL: 75,
          col: i % 2 === 0 ? '#38bdf8' : '#fbbf24', // cyan and gold
          sz: 3 + Math.random() * 4
        });
      }
    }
    broadcastState();
  };

  const triggerAggroSprout = () => {
    // Calculates aggro level based on pure light progression
    // Mariposa e Chama system: 100% light results in ultra aggro Vision metrics
    return 1.0 + (lightPower / 100.0) * 1.5;
  };

  const triggerPlayerDamage = (damage: number) => {
    const player = playerRef.current;
    if ((player as any).tempShieldT && (player as any).tempShieldT > 0) return; // Immune to all attacks while Shield of Immunity is active!
    if (player.atk && player.curAtk === 'special') return; // invulnerability frames
    if ((player as any).hurtT && (player as any).hurtT > 10) return; // brief invincibility frames when hit!

    const resistanceVal = player.resistencia || 0;
    const finalDamage = Math.max(1, Math.round(damage - resistanceVal * 2));

    player.hp -= finalDamage;
    (player as any).hurtT = 30; // set hurt state timeline (ticks down in physics loop)
    
    screenShakeRef.current = 8;
    audio.playSFX('hit');
    emitBloodParticles(player.x + player.w / 2, player.y + player.h / 3, '#ff3333', 10, 4);
    
    if (player.hp <= 0) {
      player.hp = 0;
      audio.playSFX('death');
      emitBloodParticles(player.x + player.w / 2, player.y + player.h / 3, '#cc0000', 30, 8);
      onDeath();
    }
    broadcastState();
  };

  const checkCircleRectCollision = (cx: number, cy: number, radius: number, rx: number, ry: number, rw: number, rh: number) => {
    const closestX = Math.max(rx, Math.min(cx, rx + rw));
    const closestY = Math.max(ry, Math.min(cy, ry + rh));
    const dx = cx - closestX;
    const dy = cy - closestY;
    const distanceSquared = dx * dx + dy * dy;
    return distanceSquared < radius * radius;
  };

  const checkAABBRectCollision = (r1: { x: number; y: number; w: number; h: number }, r2: { x: number; y: number; w: number; h: number }) => {
    return r1.x < r2.x + r2.w && r1.x + r1.w > r2.x && r1.y < r2.y + r2.h && r1.y + r1.h > r2.y;
  };

  const getGroundYAt = (x: number): number => {
    const grounds = platformsRef.current.filter(
      pl => pl.type === 'ground' && x >= pl.x && x <= pl.x + pl.w
    );
    if (grounds.length === 0) return GROUND_Y;
    grounds.sort((a, b) => a.y - b.y);
    return grounds[0].y;
  };

  const updateGamePhysics = () => {
    globalTimerRef.current++;
    const player = playerRef.current;
    const keys = keysRef.current;

    // Horiz movement
    if (player.curAtk === 'thrust' && player.atk) {
      player.vx = player.fac * 14.5;
    } else if (keys['ArrowLeft'] || keys['KeyA']) {
      player.vx = -player.spd;
      player.fac = -1;
    } else if (keys['ArrowRight'] || keys['KeyD']) {
      player.vx = player.spd;
      player.fac = 1;
    } else {
      player.vx *= 0.75;
      if (Math.abs(player.vx) < 0.1) player.vx = 0;
    }

    // Vert movement
    if ((keys['ArrowUp'] || keys['KeyW']) && player.jumps > 0 && !(player as any)._jumpHeld && (player.stamina || 0) >= 5) {
      player.vy = player.jF * (player.jumps === player.maxJumps ? 1.0 : 0.88);
      player.jumps--;
      player.og = false;
      player.stamina = Math.max(0, (player.stamina || 0) - 5);
      (player as any)._jumpHeld = true;
      audio.playSFX('jump');
      emitBloodParticles(player.x + player.w / 2, player.y + player.h, player.jumps === 1 ? '#44aaff' : '#ff88ff', 8, 4);
    } else if (!(keys['ArrowUp'] || keys['KeyW'])) {
      (player as any)._jumpHeld = false;
    }

    if (player.og) {
      player.jumps = player.maxJumps;
    }

    // Gravity falls
    player.vy += GRAVITY;
    player.x += player.vx;
    player.y += player.vy;
    player.og = false;

    // Platform collisions
    for (let i = 0; i < platformsRef.current.length; i++) {
      const pl = platformsRef.current[i];
      if (!pl.active) continue;

      // Platform movement calculations
      if (pl.mx || pl.my) {
        pl.mt = (pl.mt || 0) + 0.015;
        const speedMultiplier = pl.ms || 1.0;
        pl.x = (pl.sx || 0) + Math.sin(pl.mt * speedMultiplier) * (pl.mx || 0);
        pl.y = (pl.sy || 0) + Math.cos(pl.mt * speedMultiplier) * (pl.my || 0);
      }

      // Crumble/vanish timings - disabled to keep them solid and prevent flashing/vanishing
      if (pl.type === 'vanish_platform' && pl.van) {
        pl.van = false;
      }

      if (pl.type === 'crumble_platform' && pl.cr) {
        pl.cr = false;
      }

      // Landing checks
      if (
        player.vy >= 0 &&
        player.y + player.h >= pl.y &&
        player.y + player.h <= pl.y + pl.h + 10 &&
        player.x + player.w > pl.x &&
        player.x < pl.x + pl.w
      ) {
        // Crumbling and vanishing triggers have been removed to prevent them from blinking/vanishing

        player.y = pl.y - player.h;
        player.vy = 0;
        player.og = true;
        player.jumps = player.maxJumps;

        // Ice slip physics
        if (pl.type === 'ice') {
          player.vx *= 1.06;
        }

        // Trampoline bounce
        if (pl.type === 'bounce_pad') {
          player.vy = player.jF * 1.5;
          audio.playSFX('jump');
          emitBloodParticles(player.x + player.w / 2, player.y, '#44ff44', 10, 4);
        }
      }
    }

    // Filter crumbled out
    platformsRef.current = platformsRef.current.filter(p => p.active || p.type !== 'crumble_platform');

    // Bounds lock
    if (player.x < 0) player.x = 0;
    if (player.x > levelWidthRef.current - player.w) player.x = levelWidthRef.current - player.w;
    
    // Pit dead trigger
    if (player.y > CANVAS_HEIGHT + 40) {
      triggerPlayerDamage(player.mxHp);
    }

    // Cooldown reductions based on Dexterity
    const destrezaVal = player.destreza || 0;
    const cooldownTick = 1 + destrezaVal * 0.15; // attacks and spells cool down up to 2.5x faster

    if ((player as any).hurtT && (player as any).hurtT > 0) (player as any).hurtT--;
    if ((player as any).tempShieldT && (player as any).tempShieldT > 0) {
      (player as any).tempShieldT--;
    }
    if ((player as any).tempShieldCD && (player as any).tempShieldCD > 0) {
      (player as any).tempShieldCD--;
    }
    if (levelsCooldowns.current.attack > 0) {
      levelsCooldowns.current.attack = Math.max(0, levelsCooldowns.current.attack - cooldownTick);
    }
    if (levelsCooldowns.current.magic > 0) {
      levelsCooldowns.current.magic = Math.max(0, levelsCooldowns.current.magic - cooldownTick);
    }
    if (levelsCooldowns.current.thrust > 0) {
      levelsCooldowns.current.thrust = Math.max(0, levelsCooldowns.current.thrust - cooldownTick);
    }
    if (levelsCooldowns.current.heavy > 0) {
      levelsCooldowns.current.heavy = Math.max(0, levelsCooldowns.current.heavy - cooldownTick);
    }
    if (player.specCD > 0) {
      player.specCD = Math.max(0, player.specCD - cooldownTick);
      if (player.specCD === 0) player.specReady = true;
    }
    if (player.atkT > 0) {
      // Slashes finish faster so player can act quicker
      player.atkT = Math.max(0, player.atkT - cooldownTick);
      if (player.atkT === 0) player.atk = false;
    }

    // Passive mana recharge every half a second
    if (globalTimerRef.current % 30 === 0 && player.mana < player.mxMana) {
      player.mana = Math.min(player.mxMana, player.mana + 1.5);
    }

    // Passive stamina recharge (slower to promote tactical usage, enhanced by dexterity)
    const destrezaValStam = player.destreza || 0;
    const staminaRecharge = 0.08 + destrezaValStam * 0.015;
    player.stamina = Math.min(player.mxStamina || 40, (player.stamina || 0) + staminaRecharge);

    // Combo timers
    if (player.comboT > 0 && globalTimerRef.current - player.comboT > 32) {
      player.combo = 0;
    }

    // Animation bobbing calculations
    player.animTimer++;
    if (player.animTimer > 8) {
      player.animTimer = 0;
      player.animFrame = (player.animFrame + 1) % 4;
    }

    // Handle Attacks
    handlePlayerCombatMoves();

    // Projectiles loops updates
    updateProjectilesPath();

    // Hazards update
    updateHazardsMovement();

    // Collectibles logic
    handleCollectiblesPickup();

    // Reactive Aggressive AI loops for enemies
    updateAdversariesAI();

    // particles tracking
    particlesRef.current = particlesRef.current.filter(p => {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.05;
      p.life--;
      return p.life > 0;
    });

    // Camera follow offset calculations
    const targetCamX = player.x - CANVAS_WIDTH / 3;
    cameraXRef.current += (targetCamX - cameraXRef.current) * 0.1;
    if (cameraXRef.current < 0) cameraXRef.current = 0;
    if (cameraXRef.current > levelWidthRef.current - CANVAS_WIDTH) cameraXRef.current = levelWidthRef.current - CANVAS_WIDTH;

    // Clean story milestone triggers in the UI
    const isCleared = crystalsRef.current.every(c => c.col);
    if (isCleared && !levelCompletedTriggered.current && player.x > levelWidthRef.current - 140) {
      levelCompletedTriggered.current = true;
      audio.playSFX('win');
      onCompleteLevel();
    }

    broadcastState();
  };

  const handlePlayerCombatMoves = () => {
    const player = playerRef.current;
    const keys = keysRef.current;
    const now = globalTimerRef.current;

    // Normal Sword Attack (Z)
    if (keys['KeyZ'] && levelsCooldowns.current.attack <= 0 && !player.atk) {
      // Incremental combo setup
      if (player.comboT > 0 && now - player.comboT < 32) {
        player.combo = (player.combo % 3) + 1;
      } else {
        player.combo = 1;
      }
      player.comboT = now;

      // Type selection
      if (keys['ArrowUp'] || keys['KeyW']) {
        // Blinding flash (Ofuscamento!) - Stuns enemies, costs mana
        if (player.mana >= 10) {
          player.curAtk = 'flash';
          player.atkT = 15;
          levelsCooldowns.current.attack = 30;
          player.atk = true;
          player.mana -= 10;
          audio.playSFX('beam');
        } else {
          // Normal attack if no mana available
          player.curAtk = 'slash';
          player.atkT = 12;
          levelsCooldowns.current.attack = 20;
          player.atk = true;
          audio.playSFX('hit');
        }
      } else if (keys['ArrowDown'] || keys['KeyS']) {
        // Down strike from air
        player.curAtk = 'down_slash';
        player.atkT = 18;
        levelsCooldowns.current.attack = 22;
        player.atk = true;
        audio.playSFX('hit');
      } else {
        // Linear Standard Slashes
        if (player.combo === 1) {
          player.curAtk = 'slash';
          player.atkT = 12;
          levelsCooldowns.current.attack = 18;
          player.atk = true;
          audio.playSFX('hit');
        } else if (player.combo === 2) {
          player.curAtk = 'dbl_slash';
          player.atkT = 15;
          levelsCooldowns.current.attack = 15;
          player.atk = true;
          audio.playSFX('hit');
        } else {
          // Heavy third hit!
          player.curAtk = 'trp_slash';
          player.atkT = 20;
          levelsCooldowns.current.attack = 12;
          player.atk = true;
          player.combo = 0;
          onTrophyUnlocked('combo_master');
          audio.playSFX('blast');
        }
      }

      // Check hits against regular enemies
      const swordHitbox = hitboxes(player);
      const baseSwordDmg = player.curAtk === 'trp_slash' ? 30 : player.curAtk === 'down_slash' ? 28 : 18;
      const swordDmg = baseSwordDmg + (player.forca || 0) * 4;

      enemiesRef.current.forEach(en => {
        if (!en.alive) return;
        
        // Rect validation with generous buffers for easy hits against aerial/bat targets
        const rawY = en.flying ? (en.fy || 0) : en.y;
        const padX = en.spriteType === 'morcego' ? 18 : en.flying ? 12 : 5;
        const padY = en.spriteType === 'morcego' ? 22 : en.flying ? 16 : 5;
        const enBox = {
          x: en.x - padX,
          y: rawY - padY,
          w: en.w + padX * 2,
          h: en.h + padY * 2
        };
        if (checkAABBRectCollision(swordHitbox, enBox)) {
          en.hp -= swordDmg;
          en.stun = player.curAtk === 'flash' ? 64 : 10;
          emitBloodParticles(en.x + en.w / 2, rawY + en.h / 2, en.col, 8, 4);
          
          // Apply horizontal knockback pushing enemy away from player's center
          const pushDir = (en.x + en.w / 2) > (player.x + player.w / 2) ? 1 : -1;
          const kxbAmount = player.curAtk === 'trp_slash' ? 6.2 : player.curAtk === 'down_slash' ? 4.8 : 3.6;
          en.kx = pushDir * kxbAmount;

          if (en.hp <= 0) {
            en.alive = false;
            awardKill(player);
            setLightPower(prev => Math.min(100, prev + 2.5));
            emitBloodParticles(en.x + en.w / 2, enBox.y + en.h / 2, '#4444aa', 18, 6);
            onTrophyUnlocked('first_blood');
          }
        }
      });

      // Boss damage calculations
      const boss = bossRef.current;
      if (boss && boss.alive) {
        if (checkAABBRectCollision(swordHitbox, { x: boss.x, y: boss.y, w: boss.w, h: boss.h })) {
          boss.hp -= swordDmg;
          boss.ft = 10;
          emitBloodParticles(boss.x + boss.w / 2, boss.y + boss.h / 2, '#ffaa44', 12, 5);
          
          // Apply subtle knockback push on the boss
          const pushDir = (boss.x + boss.w / 2) > (player.x + player.w / 2) ? 1 : -1;
          const kxbAmount = player.curAtk === 'trp_slash' ? 1.0 : 0.6;
          boss.kx = (boss.kx || 0) + pushDir * kxbAmount;

          if (player.curAtk === 'flash') {
            boss.ft = 22; // longer blinding shine highlight frames on bosses
          }

          if (boss.hp <= 0) {
            boss.alive = false;
            setLightPower(100);
            emitBloodParticles(boss.x + boss.w / 2, boss.y + boss.h / 2, '#ffaa88', 30, 8);
            onTrophyUnlocked('boss_slayer');
            
            if (currentLevelIdx % 20 === 19) {
              onTrophyUnlocked('final_boss');
            }
          }
        }
      }
    }

    // Magic Ranged Attack (X)
    if (keys['KeyX'] && levelsCooldowns.current.magic <= 0) {
      if (keys['ArrowDown'] || keys['KeyS']) {
        // Fireblast Ground explosion - High cost, huge aoe
        if (player.mana >= 25) {
          player.mana -= 25;
          levelsCooldowns.current.magic = 50;
          player.mType = 'explosion';
          audio.playSFX('blast');
          
          projectilesRef.current.push({
            x: player.x + player.w / 2,
            y: player.y + player.h - 10,
            vx: 0, vy: 0,
            w: 120, h: 40,
            life: 25,
            type: 'explosion',
            dmg: 40 + (player.manaStat || 0) * 6
          });
          emitBloodParticles(player.x + player.w / 2, player.y + player.h, '#ff6622', 12, 5);
        }
      } else if (keys['ArrowUp'] || keys['KeyW']) {
        // Light shield protection barrier - protects against projectiles
        if (player.mana >= 20) {
          player.mana -= 20;
          levelsCooldowns.current.magic = 60;
          player.mType = 'barrier';
          audio.playSFX('heal');
          
          projectilesRef.current.push({
            x: player.x + player.w / 2,
            y: player.y + player.h / 2,
            vx: 0, vy: 0,
            w: 64, h: 64,
            life: 140, // long duration
            type: 'barrier', yOffset: player.y - (player.y + player.h / 2), // relative lock offset
            dmg: 10 + (player.manaStat || 0) * 2
          } as any);
        }
      } else {
        // Standard projectile spell (Fireball)
        if (player.mana >= 12) {
          player.mana -= 12;
          levelsCooldowns.current.magic = 35;
          player.mType = 'fireball';
          audio.playSFX('beam');
          
          const baseLife = 30;
          const bonusLife = Math.floor((player.manaStat || 0) / 10) * 15;
          
          projectilesRef.current.push({
            x: player.fac === 1 ? player.x + player.w : player.x - 16,
            y: player.y + 16,
            vx: player.fac * 7.5,
            vy: 0,
            w: 16, h: 16,
            life: baseLife + bonusLife,
            type: 'fireball',
            dmg: 22 + (player.manaStat || 0) * 4
          });
        }
      }
    }

    // Special Arena Evaporation AoE Attack (S)
    if (keys['KeyS'] && player.specReady && player.mana >= 45) {
      player.specReady = false;
      player.specCD = 180;
      player.mana -= 45;
      player.atk = true;
      player.atkT = 25;
      player.curAtk = 'special';
      audio.playSFX('win');
      screenShakeRef.current = 12;
      
      emitBloodParticles(player.x + player.w / 2, player.y + player.h / 2, '#ffffff', 25, 8);
      
      // Affect enemies inside the blast radius
      enemiesRef.current.forEach(en => {
        if (!en.alive) return;
        const enBoxY = en.flying ? (en.fy || 0) : en.y;
        const dx = en.x + en.w / 2 - (player.x + player.w / 2);
        const dy = enBoxY + en.h / 2 - (player.y + player.h / 2);
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < 185) {
          const sAoEDmg = 45 + (player.manaStat || 0) * 7;
          en.hp -= sAoEDmg;
          en.stun = 45;
          emitBloodParticles(en.x + en.w / 2, enBoxY + en.h / 2, '#ffffaa', 12, 6);
          
          // Apply horizontal shockwave knockback pushing enemy away from player's center
          const pushDir = (en.x + en.w / 2) > (player.x + player.w / 2) ? 1 : -1;
          en.kx = pushDir * 5.2;

          if (en.hp <= 0) {
            en.alive = false;
            awardKill(player);
            setLightPower(prev => Math.min(100, prev + 3));
            emitBloodParticles(en.x + en.w / 2, enBoxY + en.h / 2, '#4444aa', 18, 6);
          }
        }
      });

      // Boss damage
      const boss = bossRef.current;
      if (boss && boss.alive) {
        const dx = boss.x + boss.w / 2 - (player.x + player.w / 2);
        const dy = boss.y + boss.h / 2 - (player.y + player.h / 2);
        const dist = Math.sqrt(dx * dx + dy * dy);
        
        if (dist < 220) {
          const sAoEBossDmg = 35 + (player.manaStat || 0) * 5;
          boss.hp -= sAoEBossDmg;
          boss.ft = 20;
          emitBloodParticles(boss.x + boss.w / 2, boss.y + boss.h / 2, '#ffaa44', 16, 6);
          
          // Apply moderate horizontal knockback to boss
          const pushDir = (boss.x + boss.w / 2) > (player.x + player.w / 2) ? 1 : -1;
          boss.kx = (boss.kx || 0) + pushDir * 1.2;

          if (boss.hp <= 0) {
            boss.alive = false;
            setLightPower(100);
            emitBloodParticles(boss.x + boss.w / 2, boss.y + boss.h / 2, '#ffaa88', 30, 8);
            onTrophyUnlocked('boss_slayer');
          }
        }
      }
    }

    // Thrust / Estocada Attack (C)
    if (keys['KeyC'] && levelsCooldowns.current.thrust <= 0 && !player.atk && (player.stamina || 0) >= 10) {
      player.stamina = (player.stamina || 0) - 10;
      levelsCooldowns.current.thrust = 40; // Cooldown of 40 frames
      player.atk = true;
      player.curAtk = 'thrust';
      player.atkT = 16; // Dash combat timer
      audio.playSFX('dash');
      
      // Dash character forward rapidly
      player.vx = player.fac * 15;
      
      const swordHitbox = hitboxes(player);
      const swordDmg = 26 + (player.forca || 0) * 5;

      enemiesRef.current.forEach(en => {
        if (!en.alive) return;
        const rawY = en.flying ? (en.fy || 0) : en.y;
        const padX = en.spriteType === 'morcego' ? 18 : en.flying ? 12 : 5;
        const padY = en.spriteType === 'morcego' ? 22 : en.flying ? 16 : 5;
        const enBox = {
          x: en.x - padX,
          y: rawY - padY,
          w: en.w + padX * 2,
          h: en.h + padY * 2
        };
        if (checkAABBRectCollision(swordHitbox, enBox)) {
          en.hp -= swordDmg;
          en.stun = 20;
          emitBloodParticles(en.x + en.w / 2, rawY + en.h / 2, '#0ea5e9', 12, 4);
          
          // Thrust lunge knockback pushing away in lunge direction
          const pushDir = player.fac || ((en.x + en.w / 2) > (player.x + player.w / 2) ? 1 : -1);
          en.kx = pushDir * 6.8;

          if (en.hp <= 0) {
            en.alive = false;
            awardKill(player);
            setLightPower(prev => Math.min(100, prev + 2.5));
            emitBloodParticles(en.x + en.w / 2, rawY + en.h / 2, '#4444aa', 18, 6);
            onTrophyUnlocked('first_blood');
          }
        }
      });

      const boss = bossRef.current;
      if (boss && boss.alive) {
        if (checkAABBRectCollision(swordHitbox, { x: boss.x, y: boss.y, w: boss.w, h: boss.h })) {
          boss.hp -= swordDmg;
          boss.ft = 15;
          emitBloodParticles(boss.x + boss.w / 2, boss.y + boss.h / 2, '#0ea5e9', 15, 5);
          
          // Subtle knockback on boss from thrust lunge
          const pushDir = player.fac || ((boss.x + boss.w / 2) > (player.x + player.w / 2) ? 1 : -1);
          boss.kx = (boss.kx || 0) + pushDir * 1.5;

          if (boss.hp <= 0) {
            boss.alive = false;
            setLightPower(100);
            emitBloodParticles(boss.x + boss.w / 2, boss.y + boss.h / 2, '#ffaa88', 30, 8);
            onTrophyUnlocked('boss_slayer');
          }
        }
      }
      
      // Thrust dash particles
      for (let i = 0; i < 10; i++) {
        particlesRef.current.push({
          x: player.x + (player.fac === 1 ? player.w : 0),
          y: player.y + 12 + Math.random() * 24,
          vx: player.fac * (4 + Math.random() * 6),
          vy: (Math.random() - 0.5) * 2,
          life: 15,
          mxL: 15,
          col: '#38bdf8',
          sz: 2 + Math.random() * 2
        });
      }
    }

    // Heavy Attack / Ataque Pesado (V) - Loaded by defeating 5 enemies and requires 25 stamina
    if (keys['KeyV'] && levelsCooldowns.current.heavy <= 0 && !player.atk && (player.stamina || 0) >= 10) {
      const currentCharge = player.swordKillsCharge || 0;
      if (currentCharge >= 5) {
        player.stamina = (player.stamina || 0) - 10;
        player.swordKillsCharge = 0;
        levelsCooldowns.current.heavy = 60; // Cooldown frames
        player.atk = true;
        player.curAtk = 'heavy_slash';
        player.atkT = 30; // 30 frames massive swing motion
        audio.playSFX('blast');
        screenShakeRef.current = 16;
        
        const swordHitbox = hitboxes(player);
        const swordDmg = 65 + (player.forca || 0) * 10; // Massive heavy area slash damage with Strength upscale

        enemiesRef.current.forEach(en => {
          if (!en.alive) return;
          const rawY = en.flying ? (en.fy || 0) : en.y;
          const padX = en.spriteType === 'morcego' ? 18 : en.flying ? 12 : 5;
          const padY = en.spriteType === 'morcego' ? 22 : en.flying ? 16 : 5;
          const enBox = {
            x: en.x - padX,
            y: rawY - padY,
            w: en.w + padX * 2,
            h: en.h + padY * 2
          };
          if (checkAABBRectCollision(swordHitbox, enBox)) {
            en.hp -= swordDmg;
            en.stun = 40;
            emitBloodParticles(en.x + en.w / 2, rawY + en.h / 2, '#f59e0b', 18, 6);
            
            // Heavy ground impact sweep knockback pushing enemy away from player's center
            const pushDir = (en.x + en.w / 2) > (player.x + player.w / 2) ? 1 : -1;
            en.kx = pushDir * 8.5;

            if (en.hp <= 0) {
              en.alive = false;
              awardKill(player);
              setLightPower(prev => Math.min(100, prev + 2.5));
              emitBloodParticles(en.x + en.w / 2, rawY + en.h / 2, '#4444aa', 18, 6);
              onTrophyUnlocked('first_blood');
            }
          }
        });

        const boss = bossRef.current;
        if (boss && boss.alive) {
          if (checkAABBRectCollision(swordHitbox, { x: boss.x, y: boss.y, w: boss.w, h: boss.h })) {
            boss.hp -= swordDmg;
            boss.ft = 30;
            emitBloodParticles(boss.x + boss.w / 2, boss.y + boss.h / 2, '#f59e0b', 25, 8);
            
            // Boss heavy sweep knockback push
            const pushDir = (boss.x + boss.w / 2) > (player.x + player.w / 2) ? 1 : -1;
            boss.kx = (boss.kx || 0) + pushDir * 2.2;

            if (boss.hp <= 0) {
              boss.alive = false;
              setLightPower(100);
              emitBloodParticles(boss.x + boss.w / 2, boss.y + boss.h / 2, '#ffaa88', 35, 9);
              onTrophyUnlocked('boss_slayer');
            }
          }
        }
        
        // Giant circular grounding explosion particles and wave ripples!
        for (let i = 0; i < 22; i++) {
          const offset = (Math.random() - 0.5) * 220;
          particlesRef.current.push({
            x: player.x + player.w / 2 + offset,
            y: player.y + player.h - 10,
            vx: (Math.random() - 0.5) * 5,
            vy: -4 - Math.random() * 5,
            life: 25 + Math.random() * 25,
            mxL: 50,
            col: i % 2 === 0 ? '#fbbf24' : '#ef4444',
            sz: 4 + Math.random() * 6
          });
        }
      }
    }

    // F Key Skill: Absolute Shield of Immunity (Escudo Absoluto)
    // Cost: 30 stamina (destreza pool) and 15 mana. Lasts 5 seconds.
    if (keys['KeyF']) {
      const activeShield = (player as any).tempShieldT || 0;
      const cooldownShield = (player as any).tempShieldCD || 0;

      if (activeShield <= 0 && cooldownShield <= 0) {
        if (player.mana >= 15 && (player.stamina || 0) >= 30) {
          player.mana -= 15;
          player.stamina = Math.max(0, (player.stamina || 0) - 30);
          (player as any).tempShieldT = 300; // 5 seconds * 60 FPS = 300 frames
          (player as any).tempShieldCD = 480; // 8 seconds cooldown = 480 frames
          audio.playSFX('heal'); // Protective holy-heal SFX

          // Burst of beautiful cyan shield activation particles
          for (let i = 0; i < 15; i++) {
            particlesRef.current.push({
              x: player.x + player.w / 2 + (Math.random() - 0.5) * 30,
              y: player.y + player.h / 2 + (Math.random() - 0.5) * 30,
              vx: (Math.random() - 0.5) * 6,
              vy: (Math.random() - 0.5) * 6,
              life: 15 + Math.random() * 15,
              mxL: 30,
              col: '#6366f1', // Indigo glow
              sz: 3 + Math.random() * 4
            });
          }
        } else {
          // Play a slight hit notification if resources are insufficient
          if (globalTimerRef.current % 15 === 0) {
            audio.playSFX('dash');
          }
        }
      }
    }
  };

  const hitboxes = (player: Player) => {
    if (player.curAtk === 'down_slash') {
      return { x: player.x, y: player.y + player.h - 4, w: player.w, h: 42 };
    }
    if (player.curAtk === 'flash') {
      return { x: player.x - player.w * 1.5, y: player.y - player.h / 2, w: player.w * 4, h: player.h * 2 };
    }
    if (player.curAtk === 'thrust') {
      return {
        x: player.fac === 1 ? player.x + player.w : player.x - 70,
        y: player.y + 12,
        w: 70,
        h: 28
      };
    }
    if (player.curAtk === 'heavy_slash') {
      return {
        x: player.x - 110,
        y: player.y - 40,
        w: 220 + player.w,
        h: player.h + 60
      };
    }
    return {
      x: player.fac === 1 ? player.x + player.w : player.x - 45,
      y: player.y + 6,
      w: 45,
      h: 36
    };
  };

  const updateProjectilesPath = () => {
    const player = playerRef.current;

    projectilesRef.current = projectilesRef.current.filter(pp => {
      // Barrier lock on player coordinate offsets
      if (pp.type === 'barrier') {
        pp.x = player.x + player.w / 2;
        pp.y = player.y + player.h / 2;
      } else if (pp.type === 'orbital_blade') {
        const orbitIndex = (pp as any).orbitIndex !== undefined ? (pp as any).orbitIndex : 0;
        const orbitBaseAngle = (orbitIndex * Math.PI * 2) / 3;
        const currentAngle = orbitBaseAngle + (globalTimerRef.current * 0.1); 
        const orbitRadius = 60; // 60px distance from player center
        
        pp.x = player.x + player.w / 2 + Math.cos(currentAngle) * orbitRadius;
        pp.y = player.y + player.h / 2 + Math.sin(currentAngle) * orbitRadius;
      } else {
        pp.x += pp.vx;
        pp.y += pp.vy;
      }

      // Gravity drops
      if (['e_proj', 'poison', 'void_orb', 'laser', 'meteor'].includes(pp.type)) {
        pp.vy += 0.04;
      }

      pp.life--;

      // Sells/player triggers intersection checks
      if (pp.type === 'fireball' || pp.type === 'explosion' || pp.type === 'orbital_blade') {
        const isOrbital = pp.type === 'orbital_blade';
        // hits enemies
        enemiesRef.current.forEach(en => {
          if (!en.alive) return;
          if (isOrbital) {
            const lastHit = (en as any)._lastOrbitalHit || 0;
            if (globalTimerRef.current - lastHit < 15) return; // rate limit hits
          }

          const rawY = en.flying ? (en.fy || 0) : en.y;
          const padX = en.spriteType === 'morcego' ? 18 : en.flying ? 12 : 5;
          const padY = en.spriteType === 'morcego' ? 22 : en.flying ? 16 : 5;
          const enBox = {
            x: en.x - padX,
            y: rawY - padY,
            w: en.w + padX * 2,
            h: en.h + padY * 2
          };
          const projBox = { x: pp.x - pp.w / 2, y: pp.y - pp.h / 2, w: pp.w, h: pp.h };
          
          if (checkAABBRectCollision(projBox, enBox)) {
            en.hp -= pp.dmg;
            if (isOrbital) {
              (en as any)._lastOrbitalHit = globalTimerRef.current;
            } else {
              pp.life = 0;
            }
            emitBloodParticles(en.x + en.w / 2, rawY + en.h / 2, isOrbital ? '#a855f7' : '#ff5522', 8, 4);
            
            // Subtly push regular enemies from projectiles
            const pushDir = pp.vx > 0 ? 1 : pp.vx < 0 ? -1 : ((en.x + en.w / 2) > (player.x + player.w / 2) ? 1 : -1);
            en.kx = (en.kx || 0) + pushDir * (isOrbital ? 1.4 : 2.8);

            if (en.hp <= 0) {
              en.alive = false;
              awardKill(player);
              setLightPower(prev => Math.min(100, prev + 2.5));
              emitBloodParticles(en.x + en.w / 2, enBox.y + en.h / 2, '#4444aa', 18, 6);
              onTrophyUnlocked('first_blood');
            }
          }
        });

        // hits bosses
        const boss = bossRef.current;
        if (boss && boss.alive) {
          let canHitBoss = true;
          if (isOrbital) {
            const lastHit = (boss as any)._lastOrbitalHit || 0;
            if (globalTimerRef.current - lastHit < 15) {
              canHitBoss = false;
            }
          }

          if (canHitBoss) {
            const projBox = { x: pp.x - pp.w / 2, y: pp.y - pp.h / 2, w: pp.w, h: pp.h };
            if (checkAABBRectCollision(projBox, { x: boss.x, y: boss.y, w: boss.w, h: boss.h })) {
              boss.hp -= pp.dmg;
              boss.ft = 10;
              if (isOrbital) {
                (boss as any)._lastOrbitalHit = globalTimerRef.current;
              } else {
                pp.life = 0;
              }
              emitBloodParticles(boss.x + boss.w / 2, boss.y + boss.h / 2, isOrbital ? '#a855f7' : '#ff8844', 12, 5);
              
              // Subtle push on boss
              const pushDir = pp.vx > 0 ? 1 : pp.vx < 0 ? -1 : ((boss.x + boss.w / 2) > (player.x + player.w / 2) ? 1 : -1);
              boss.kx = (boss.kx || 0) + pushDir * (isOrbital ? 0.3 : 0.6);

              if (boss.hp <= 0) {
                boss.alive = false;
                setLightPower(100);
                emitBloodParticles(boss.x + boss.w / 2, boss.y + boss.h / 2, '#ffaa88', 30, 8);
                onTrophyUnlocked('boss_slayer');
              }
            }
          }
        }
      }

      // Barrier shield blocks enemy triggers
      if (pp.type === 'barrier') {
        projectilesRef.current.forEach(otherProj => {
          if (['e_proj', 'poison', 'void_orb', 'laser', 'meteor'].includes(otherProj.type)) {
            const blockD = Math.sqrt((otherProj.x - pp.x) ** 2 + (otherProj.y - pp.y) ** 2);
            if (blockD < pp.w / 2 + otherProj.w / 2) {
              otherProj.life = 0; // evaporates the projectile!
              audio.playSFX('hit');
              emitBloodParticles(otherProj.x, otherProj.y, '#5599ff', 6, 2);
            }
          }
        });
      }

      // Enemy projectiles hitting player
      if (['e_proj', 'poison', 'void_orb', 'laser', 'meteor', 'b_beam'].includes(pp.type)) {
        const projBox = { x: pp.x - pp.w / 2, y: pp.y - pp.h / 2, w: pp.w, h: pp.h };
        const playerBox = { x: player.x, y: player.y, w: player.w, h: player.h };
        
        if (checkAABBRectCollision(projBox, playerBox)) {
          triggerPlayerDamage(pp.dmg);
          pp.life = 0;
        }
      }

      return pp.life > 0 && pp.x > -100 && pp.x < levelWidthRef.current + 100;
    });
  };

  const updateHazardsMovement = () => {
    hazardsRef.current.forEach(h => {
      if (!h.active) return;
      
      // We run the trap state machine for 'spike' types
      if (h.type === 'spike') {
        if (h.baseY === undefined) h.baseY = GROUND_Y;
        if (h.state === undefined) h.state = 'retracted';
        if (h.timer === undefined) h.timer = Math.floor(Math.random() * 150);
        
        const speed = 2.4; // Speed of spikes rising/sinking
        const targetHeight = h.h || 46;
        
        if (h.state === 'retracted') {
          h.y = h.baseY;
          h.timer--;
          if (h.timer <= 0) {
            h.state = 'rising';
          }
        } else if (h.state === 'rising') {
          h.y -= speed;
          if (h.y <= h.baseY - targetHeight) {
            h.y = h.baseY - targetHeight;
            h.state = 'extended';
            h.timer = 70 + Math.floor(Math.random() * 50); // stay extended for some duration
          }
        } else if (h.state === 'extended') {
          h.y = h.baseY - targetHeight;
          h.timer--;
          if (h.timer <= 0) {
            h.state = 'sinking';
          }
        } else if (h.state === 'sinking') {
          h.y += speed;
          if (h.y >= h.baseY) {
            h.y = h.baseY;
            h.state = 'retracted';
            h.timer = 120 + Math.floor(Math.random() * 140); // stay retracted for a delay
          }
        }
      } else if (h.type === 'saw') {
        h.rot = (h.rot || 0) + 0.12;
      }

      // Compute physical bounding box depending on current protruding height
      let currentHeight = h.h;
      let collY = h.y;
      if (h.type === 'spike') {
        const bY = h.baseY || GROUND_Y;
        currentHeight = bY - h.y; // Protruding height from base to tip
        collY = h.y;
      }
      
      // Check collision with player if it's currently protruding (height > 10 pixels)
      if (h.type !== 'spike' || currentHeight > 10) {
        const hazardBox = { x: h.x, y: collY, w: h.w, h: currentHeight };
        const playerBox = { x: playerRef.current.x, y: playerRef.current.y, w: playerRef.current.w, h: playerRef.current.h };
        
        if (checkAABBRectCollision(hazardBox, playerBox)) {
          triggerPlayerDamage(18); // Spikes are bigger and extra dangerous!
        }
      }
    });
  };

  const handleCollectiblesPickup = () => {
    const player = playerRef.current;
    const pBox = { x: player.x, y: player.y, w: player.w, h: player.h };

    // Collect shards/crystals
    crystalsRef.current.forEach(cr => {
      if (cr.col) return;
      const cBox = { x: cr.x - 15, y: cr.y - 15, w: 30, h: 30 };
      
      if (checkAABBRectCollision(pBox, cBox)) {
        cr.col = true;
        setLightPower(prev => Math.min(100, prev + 15));
        setShadowPower(prev => Math.min(100, prev + 5));
        player.mxHp += 10;
        player.hp = player.mxHp;
        player.mxMana += 10;
        player.mana = player.mxMana;
        
        audio.playSFX('crystal');
        emitBloodParticles(cr.x, cr.y, '#ffdd44', 20, 6);
        screenShakeRef.current = 4;
      }
    });

    // Pick heal support orbs
    lightOrbsRef.current.forEach(orb => {
      if (!orb.active) return;
      const oBox = { x: orb.x - 12, y: orb.y - 12, w: 24, h: 24 };
      if (checkAABBRectCollision(pBox, oBox)) {
        orb.active = false;
        player.mana = Math.min(player.mxMana, player.mana + 25);
        player.hp = Math.min(player.mxHp, player.hp + 12);
        setLightPower(prev => Math.min(100, prev + 3));
        
        audio.playSFX('heal');
        emitBloodParticles(orb.x, orb.y, '#55ddff', 12, 4);
      }
    });

    // Collect Story Lore scrolls
    storyScrollsRef.current.forEach(scroll => {
      if (scroll.col) return;
      const sBox = { x: scroll.x - 20, y: scroll.y - 20, w: 40, h: 40 };
      if (checkAABBRectCollision(pBox, sBox)) {
        scroll.col = true;
        audio.playSFX('crystal');
        // Sparkle burst particles
        for (let i = 0; i < 15; i++) {
          particlesRef.current.push({
            x: scroll.x,
            y: scroll.y,
            vx: (Math.random() - 0.5) * 5,
            vy: (Math.random() - 0.5) * 5,
            life: 20 + Math.random() * 15,
            mxL: 35,
            col: '#4ae889', // Green spirit particles matching the image forest theme!
            sz: 2.5 + Math.random() * 3
          });
        }
        // Force key releases so player doesn't walk endlessly while reading
        keysRef.current = {};
        
        // Show dialogue modal!
        onShowDialogue([
          {
            title: scroll.title,
            text: scroll.text
          }
        ]);
      }
    });
  };

  const updateAdversariesAI = () => {
    const player = playerRef.current;
    const agg = triggerAggroSprout();
    const globalT = globalTimerRef.current;

    enemiesRef.current.forEach(en => {
      if (!en.alive) return;

      // Bob timer updates
      en.animTimer++;
      if (en.animTimer > 6) {
        en.animTimer = 0;
        en.animFrame = (en.animFrame + 1) % 4;
      }

      // Check stun locks
      const isStunned = en.stun > 0;
      if (isStunned) {
        en.stun--;
      }

      // Visage updates/AI for flying creatures
      const distH = player.x - en.x;
      const distV = (en.flying ? (en.fy || 0) : en.y) - player.y; // positive if player is higher
      const distTotal = Math.sqrt(distH * distH + distV * distV);
      const detected = distTotal < 380;

      if (en.flying) {
        en.flyT = (en.flyT || 0) + (en.flyFreq || 0.02);
        
        if (!isStunned) {
          if (en.beh === 'fly_teleport') {
            en.tT = (en.tT || 0) + 1;
            const cutoff = Math.max(30, 115 - lightPower);
            if (en.tT > cutoff) {
              en.tT = 0;
              en.x = player.x + (Math.random() > 0.5 ? 90 : -90);
              en.fy = player.y + (Math.random() - 0.5) * 60;
              emitBloodParticles(en.x, en.fy, en.col, 8, 2);
            }
          } else if (en.beh === 'fly_dive' && en.diving) {
            en.x += Math.sign((en.diveTarget || 0) - en.x) * en.vx * 2.2;
            en.fy = (en.fy || 0) + 3.2;
            
            if ((en.fy || 0) > GROUND_Y - en.h) {
              en.diving = false;
              en.fy = en.flyBase;
            }
          } else {
            if (detected) {
              // Intelligent flight tracking
              en.dir = distH > 0 ? 1 : -1;
              en.x += en.vx * en.dir * 1.35 * agg;
              
              const targetFlyBase = Math.max(100, player.y - 60);
              if (en.originalFlyBase === undefined) en.originalFlyBase = en.flyBase;
              en.flyBase = (en.flyBase || 150) + (targetFlyBase - (en.flyBase || 150)) * 0.05;
              en.fy = (en.flyBase || 150) + Math.sin(en.flyT) * (en.flyAmp || 20);
            } else {
              // Patrol/sinusoidal flight
              if (en.originalFlyBase !== undefined) {
                en.flyBase += (en.originalFlyBase - en.flyBase) * 0.02;
              }
              en.x += en.vx * en.dir * agg;
              en.fy = (en.flyBase || 0) + Math.sin(en.flyT) * (en.flyAmp || 50);
              if (Math.abs(en.x - en.sx) > en.rng2) {
                en.dir *= -1;
              }
            }
          }
        } else {
          // Stunned floating oscillation
          en.fy = (en.flyBase || 150) + Math.sin(en.flyT) * (en.flyAmp || 10);
        }
      } else {
        // Grounded physical behavior sets
        if (en.jumpCooldown === undefined) en.jumpCooldown = 0;
        if (en.jumpCooldown > 0) en.jumpCooldown--;

        if (!isStunned) {
          if (detected) {
            en.dir = distH > 0 ? 1 : -1;
            
            // Enhanced intelligence movement speed
            const chasingSpeedMult = en.beh === 'charge' && en.charging ? 2.8 : 1.35;
            en.x += en.vx * en.dir * chasingSpeedMult * agg;

            // Charge intelligence setup
            if (en.beh === 'charge' && !en.charging && Math.abs(distH) < en.ar) {
              en.charging = true;
              en.cT = 32;
            }
            if (en.beh === 'charge' && en.charging) {
              en.cT = (en.cT || 0) - 1;
              if ((en.cT || 0) <= 0) {
                en.charging = false;
              }
            }

            // SMART COOLDOWN JUMP TRIGGERING
            // Trigger a jump if the player is above the enemy, or if there's a platform/wall in front of them
            if (en.onGround && distV > 40) {
              if (en.jumpCooldown <= 0) {
                en.vy = -11; // Perfect physical jump impulse
                en.onGround = false;
                en.jumpCooldown = 60 + Math.random() * 40; // prevent double frame jumps
                emitBloodParticles(en.x + en.w / 2, en.y + en.h, '#94a3b8', 6, 2.5); // ground dust jump effect
              }
            }
          } else {
            // Standard/Passive behavior modes when player is out of sight
            switch (en.beh) {
              case 'patrol':
                en.x += en.vx * en.dir * agg;
                if (Math.abs(en.x - en.sx) > en.rng2) {
                  en.dir *= -1;
                }
                break;

              case 'ranged':
                const distToPlayerRange = player.x - en.x;
                if (Math.abs(distToPlayerRange) < en.ar && Math.abs(distToPlayerRange) > 90) {
                  en.dir = distToPlayerRange > 0 ? 1 : -1;
                  en.x += en.vx * en.dir * 0.5 * agg;
                } else {
                  en.x += en.vx * en.dir * agg;
                  if (Math.abs(en.x - en.sx) > en.rng2) {
                    en.dir *= -1;
                  }
                }
                break;

              case 'ambush':
                en.x += en.vx * en.dir * agg;
                if (Math.abs(en.x - en.sx) > en.rng2) {
                  en.dir *= -1;
                }
                break;

              case 'charge':
                if (en.charging) {
                  en.cT = (en.cT || 0) - 1;
                  en.x += en.dir * en.vx * 2.8 * agg;
                  if ((en.cT || 0) <= 0) {
                    en.charging = false;
                    en.at = Math.floor(en.aCd * 0.5);
                  }
                } else {
                  en.x += en.vx * en.dir * agg;
                  if (Math.abs(en.x - en.sx) > en.rng2) {
                    en.dir *= -1;
                    en.at = en.aCd;
                  }
                }
                break;

              case 'aggressive':
                en.dir = player.x > en.x ? 1 : -1;
                en.x += en.vx * en.dir * 1.45 * agg;
                break;

              case 'aura':
                const dPlayer = player.x - en.x;
                en.dir = dPlayer > 0 ? 1 : -1;
                if (Math.abs(dPlayer) < en.ar) {
                  en.x += en.vx * en.dir * 0.45 * agg;
                } else {
                  en.x += en.vx * en.dir * agg;
                  if (Math.abs(en.x - en.sx) > en.rng2) {
                    en.dir *= -1;
                  }
                }
                break;
            }
          }
        }

        // Parabolic physics falling logic for grounded enemies
        if (en.vy === undefined) en.vy = 0;
        if (en.onGround === undefined) en.onGround = true;

        if (!en.onGround) {
          en.vy += 0.55; // gravity acceleration
          en.y += en.vy;
        }

        // Check platform and ground collisions
        let landedPl: any = null;
        for (let i = 0; i < platformsRef.current.length; i++) {
          const pl = platformsRef.current[i];
          if (!pl.active) continue;

          const plH = pl.type === 'ground' ? 640 - pl.y : pl.h;
          if (
            en.vy >= 0 &&
            en.y + en.h >= pl.y &&
            en.y + en.h <= pl.y + plH + 12 &&
            en.x + en.w > pl.x &&
            en.x < pl.x + pl.w
          ) {
            landedPl = pl;
            break;
          }
        }

        if (landedPl) {
          en.y = landedPl.y - en.h;
          en.vy = 0;
          en.onGround = true;
        } else {
          // Fallback clamp to ensure they don't drop permanently through the map or past screen bottom
          const fallbackFloorY = getGroundYAt(en.x + en.w / 2);
          if (en.y >= fallbackFloorY - en.h) {
            en.y = fallbackFloorY - en.h;
            en.vy = 0;
            en.onGround = true;
          } else {
            en.onGround = false;
          }
        }
      }

      // Physics - Apply horizontal decelerating knockback always (active or stunned)
      if (en.kx) {
        en.x += en.kx;
        en.kx *= 0.82;
        if (Math.abs(en.kx) < 0.1) en.kx = 0;
      }

      // Keep enemy within horizontal map bounds
      if (en.x < 0) en.x = 0;
      if (en.x > levelWidthRef.current - en.w) en.x = levelWidthRef.current - en.w;

      // Attack cycles
      en.at--;
      if (en.at <= 0) {
        en.at = Math.floor(en.aCd / agg); // higher aggro reduces target CD
        
        const enBoxY = en.flying ? (en.fy || 0) : en.y;
        const dx = player.x - en.x;
        const dy = (player.y + player.h / 2) - (enBoxY + en.h / 2);
        const distance = Math.sqrt(dx * dx + dy * dy);

        if (en.atk === 'melee' && distance < en.ar + en.w) {
          triggerPlayerDamage(en.ad);
        } else if (en.atk === 'projectile' && distance < en.ar) {
          projectilesRef.current.push({
            x: en.x + en.w / 2,
            y: enBoxY + en.h / 2,
            vx: en.dir * 5.5,
            vy: dy > 0 ? 0.3 : -0.3,
            w: 12, h: 12,
            life: 95,
            type: 'e_proj',
            dmg: en.ad,
            col: en.pc
          });
        } else if (en.atk === 'area' && distance < en.ar) {
          emitBloodParticles(en.x + en.w / 2, enBoxY + en.h / 2, en.pc, 12, 6);
          triggerPlayerDamage(en.ad);
        } else if (en.atk === 'teleport' && distance < en.ar) {
          triggerPlayerDamage(en.ad);
          emitBloodParticles(player.x, player.y, en.col, 10, 4);
        } else if (en.atk === 'charge') {
          if (!en.charging && Math.abs(dx) < en.ar) {
            en.charging = true;
            en.cT = 32;
            en.dir = dx > 0 ? 1 : -1;
          }
          if (en.charging && checkAABBRectCollision(
            { x: en.x, y: enBoxY, w: en.w, h: en.h },
            { x: player.x, y: player.y, w: player.w, h: player.h }
          )) {
            triggerPlayerDamage(Math.floor(en.ad * 1.5));
          }
        } else if (en.atk === 'combo' && distance < en.ar + 15) {
          triggerPlayerDamage(en.ad);
          en.at = 25; // low slash cooldowns inside combos
        } else if (en.atk === 'aura' && distance < en.ar) {
          triggerPlayerDamage(Math.floor(en.ad * 0.3)); // continuous mild aura contact
          en.at = 12;
        } else if (en.atk === 'dive' && distance < en.ar) {
          en.diving = true;
          en.diveTarget = player.x;
          audio.playSFX('dash');
        }
      }

      // If currently diving, check full damage collision
      const enBoxYCurrent = en.flying ? (en.fy || 0) : en.y;
      if (en.atk === 'dive' && en.diving && checkAABBRectCollision(
        { x: en.x, y: enBoxYCurrent, w: en.w, h: en.h },
        { x: player.x, y: player.y, w: player.w, h: player.h }
      )) {
        triggerPlayerDamage(en.ad);
      }

      // Check collision direct contact
      const enBoxYLoc = en.flying ? (en.fy || 0) : en.y;
      if (checkAABBRectCollision(
        { x: en.x, y: enBoxYLoc, w: en.w, h: en.h },
        { x: player.x, y: player.y, w: player.w, h: player.h }
      )) {
        triggerPlayerDamage(Math.floor(en.ad * 0.45));
      }
    });

    // Update active boss triggers
    updateBossActionPhases();
  };

  const updateBossActionPhases = () => {
    const boss = bossRef.current;
    if (!boss || !boss.alive) return;
    const player = playerRef.current;
    const globalT = globalTimerRef.current;

    const dm = getDifficultyMultipliers();
    const lvlHpScale = 1 + currentLevelIdx * 0.008;
    const lvlDmgScale = 1 + currentLevelIdx * 0.004;
    const bossDmgMult = lvlDmgScale * dm.dmgMult;

    boss.at2++;
    boss.mt2++;
    boss.ct2++;
    if (boss.ft > 0) boss.ft--;

    // Bob timer for boss elements
    boss.animTimer++;
    if (boss.animTimer > 6) {
      boss.animTimer = 0;
      boss.animFrame = (boss.animFrame + 1) % 4;
    }

    const bdx = player.x - boss.x;
    boss.dir = bdx > 0 ? 1 : -1;

    // Phase transition checks, HP-based milestones
    const healthPercentIdx = boss.pIdx;
    const isMajor = boss.isMajor;
    
    // Check if we slide into a subsequent rage phase
    if (healthPercentIdx < 2 && boss.hp <= boss.mxHp * (healthPercentIdx + 1 === 1 ? 0.66 : 0.33)) {
      boss.pIdx++;
      boss.ft = 24;
      screenShakeRef.current = 15;
      audio.playSFX('blast');
      emitBloodParticles(boss.x + boss.w / 2, boss.y + boss.h / 2, '#ff0055', 30, 10);
      
      onShowDialogue([
        { title: `${boss.name} em Fúria!`, text: `"${boss.name} despertou sua força oculta na fase ${boss.pIdx + 1}! Seus canais de sombra expandem!"` }
      ]);
    }

    // Move closer
    boss.mt2++;
    if (boss.mt2 > 35) {
      boss.mt2 = 0;
      boss.x += boss.dir * boss.spd;
    }

    // Slide boss by knockback
    if (boss.kx) {
      boss.x += boss.kx;
      boss.kx *= 0.85;
      if (Math.abs(boss.kx) < 0.1) boss.kx = 0;
    }

    // Keep boss inside horizontal map bounds
    if (boss.x < 0) boss.x = 0;
    if (boss.x > levelWidthRef.current - boss.w) boss.x = levelWidthRef.current - boss.w;

    // Action patterns
    const cdLimit = Math.max(50, 110 - boss.pIdx * 20);
    if (boss.at2 > cdLimit) {
      boss.at2 = 0;
      const attackTypePool = isMajor
        ? (boss.region === 4 ? ['annihilation', 'shadow_lasers', 'meteor', 'clone_army'] : ['light_dash', 'light_beam', 'summon', 'explosion'])
        : ['clone', 'root', 'poison', 'dark_beam'];
        
      const attackSelected = attackTypePool[Math.floor(Math.random() * attackTypePool.length)];

      switch (attackSelected) {
        case 'light_dash':
          boss.x += boss.dir * 180;
          emitBloodParticles(boss.x + boss.w / 2, boss.y + boss.h / 2, boss.col, 15, 6);
          if (Math.abs(player.x - boss.x) < 85) {
            triggerPlayerDamage(Math.floor(22 * bossDmgMult));
          }
          break;

        case 'light_beam':
          projectilesRef.current.push({
            x: boss.x + boss.w / 2,
            y: boss.y + boss.h / 2,
            vx: boss.dir * 7.0,
            vy: 0,
            w: 40, h: 12,
            life: 80,
            type: 'b_beam',
            dmg: Math.floor(25 * bossDmgMult),
            col: boss.col
          });
          break;

        case 'summon':
          for (let s = 0; s < 2 + boss.pIdx; s++) {
            enemiesRef.current.push({
              x: boss.x + (Math.random() - 0.5) * 200,
              y: GROUND_Y - 40,
              w: 36, h: 40, vx: 1.5,
              hp: Math.floor(30 * lvlHpScale * dm.hpMult),
              mxHp: Math.floor(30 * lvlHpScale * dm.hpMult),
              tn: 'Invocação Rubra',
              col: '#aa1122', eCol: '#ffaacc',
              alive: true, dir: Math.random() > 0.5 ? 1 : -1,
              rng2: 120, sx: boss.x,
              at: 40, aCd: 60,
              atk: 'melee', ad: Math.floor(10 * bossDmgMult), ar: 40,
              beh: 'patrol', flying: false, spriteType: 'sombraErrante',
              animFrame: 0, animTimer: 0, stun: 0
            });
          }
          break;

        case 'clone':
          if (boss.ct2 > 150) {
            boss.ct2 = 0;
            // Spawn standard sub-shadow
            enemiesRef.current.push({
              x: boss.x - 120,
              y: boss.y,
              w: Math.floor(boss.w * 0.7),
              h: Math.floor(boss.h * 0.7),
              vx: boss.spd,
              hp: Math.floor(60 * lvlHpScale * dm.hpMult),
              mxHp: Math.floor(60 * lvlHpScale * dm.hpMult),
              tn: 'Espectro de Espelho',
              col: '#6050aa', eCol: '#ffffff',
              alive: true, dir: 1, rng2: 150, sx: boss.x,
              at: 30, aCd: 40, atk: 'melee', ad: Math.floor(12 * bossDmgMult), ar: 45,
              beh: 'aggressive', flying: false, spriteType: 'sombraElitista',
              animFrame: 0, animTimer: 0, stun: 0
            });
          }
          break;

        case 'root':
          for (let r = 0; r < 3 + boss.pIdx; r++) {
            hazardsRef.current.push({
              x: player.x + (Math.random() - 0.5) * 140,
              y: GROUND_Y - 20,
              w: 22, h: 22,
              type: 'root',
              active: true,
              life: 110
            });
          }
          break;

        case 'poison':
          for (let p = 0; p < 6 + boss.pIdx * 2; p++) {
            projectilesRef.current.push({
              x: boss.x + boss.w / 2 + (Math.random() - 0.5) * 80,
              y: boss.y - 10,
              vx: (Math.random() - 0.5) * 4,
              vy: 2.5 + Math.random() * 2,
              w: 12, h: 12,
              life: 100,
              type: 'poison',
              dmg: Math.floor(10 * bossDmgMult),
              col: '#55aa55'
            });
          }
          break;

        case 'dark_beam':
          projectilesRef.current.push({
            x: boss.x + boss.w / 2,
            y: boss.y + boss.h / 2,
            vx: boss.dir * 8,
            vy: 0,
            w: 44, h: 12,
            life: 90,
            type: 'b_beam',
            dmg: Math.floor(30 * bossDmgMult),
            col: '#9933cc'
          });
          break;

        case 'shadow_tp':
          boss.x = player.x + (Math.random() > 0.5 ? -100 : 100);
          emitBloodParticles(boss.x + boss.w / 2, boss.y + boss.h / 2, '#4400aa', 12, 4);
          break;

        case 'annihilation':
          projectilesRef.current.push({
            x: boss.x + boss.w / 2,
            y: boss.y + boss.h / 2,
            vx: boss.dir * 10,
            vy: 0,
            w: 64, h: 24,
            life: 60,
            type: 'b_beam',
            dmg: Math.floor(45 * bossDmgMult),
            col: '#ff0088'
          });
          break;

        case 'shadow_lasers':
          for (let laserIdx = 0; laserIdx < 3 + boss.pIdx; laserIdx++) {
            const angleOffset = laserIdx * 0.4 - 0.4;
            projectilesRef.current.push({
              x: boss.x + boss.w / 2,
              y: boss.y + boss.h / 2,
              vx: Math.cos(angleOffset) * 7.5,
              vy: Math.sin(angleOffset) * 7.5,
              w: 10, h: 10,
              life: 80,
              type: 'laser',
              dmg: Math.floor(12 * bossDmgMult),
              col: '#ff44bb'
            });
          }
          break;

        case 'meteor':
          projectilesRef.current.push({
            x: player.x,
            y: -15,
            vx: 0, vy: 5,
            w: 32, h: 32,
            life: 130,
            type: 'meteor',
            dmg: Math.floor(35 * bossDmgMult),
            col: '#ff3344'
          });
          break;
      }
    }

    // Contact physical damage from boss directly to player
    if (checkAABBRectCollision(
      { x: boss.x, y: boss.y, w: boss.w, h: boss.h },
      { x: player.x, y: player.y, w: player.w, h: player.h }
    )) {
      triggerPlayerDamage(Math.floor(18 * bossDmgMult));
    }
  };

  const broadcastState = () => {
    const collected = crystalsRef.current.filter(c => c.col).length;
    onUpdateHUD(
      { ...playerRef.current },
      lightPower,
      shadowPower,
      collected,
      levelCrystalsTotal.current,
      lightPower // Aggression Scale tracks Light power percentage matches directly
    );
  };

  // Canvas drawing loops
  const renderCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.save();
    
    // Shake transition
    if (screenShakeRef.current > 0) {
      const shakeAmt = screenShakeRef.current;
      ctx.translate((Math.random() - 0.5) * shakeAmt * 2, (Math.random() - 0.5) * shakeAmt * 2);
      screenShakeRef.current *= 0.9;
      if (screenShakeRef.current < 0.2) screenShakeRef.current = 0;
    }

    // Static clear
    ctx.fillStyle = '#050510';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    const activeRegIdx = Math.floor(currentLevelIdx / 20);
    const region = regions[activeRegIdx % regions.length];

    // Define the 5 stunning Forest Ruins Themes inspired by the user's reference photo
    const themes = [
      { // Verde Floresta (Region 0)
        skyTop: '#08120a',
        skyBottom: '#142517',
        mistColor: 'rgba(58, 83, 60, 0.45)',
        tree1: '#09150b',
        tree2: '#060f07',
        tree3: '#030704',
        leafColor: 'rgba(30, 55, 34, 0.45)',
        pillarColor: '#050a06',
        torchColor: 'rgba(255, 140, 0, 0.65)',
        groundGrass: '#25451e',
        platformTop: '#3c6432'
      },
      { // Cidade Prisma / Roxo Místico (Region 1)
        skyTop: '#05030c',
        skyBottom: '#150a26',
        mistColor: 'rgba(64, 45, 95, 0.42)',
        tree1: '#0d061c',
        tree2: '#080312',
        tree3: '#04010a',
        leafColor: 'rgba(54, 30, 80, 0.42)',
        pillarColor: '#070311',
        torchColor: 'rgba(255, 120, 0, 0.65)',
        groundGrass: '#3a1f54',
        platformTop: '#5a3d78'
      },
      { // Floresta Nébula / Bioluminescente (Region 2)
        skyTop: '#030b0e',
        skyBottom: '#0c2229',
        mistColor: 'rgba(30, 85, 90, 0.45)',
        tree1: '#07181f',
        tree2: '#040f14',
        tree3: '#010609',
        leafColor: 'rgba(18, 55, 62, 0.45)',
        pillarColor: '#030c10',
        torchColor: 'rgba(255, 160, 0, 0.65)',
        groundGrass: '#164850',
        platformTop: '#2b717b'
      },
      { // Abismo Eclipse / Escarlate Negativo (Region 3)
        skyTop: '#0c0202',
        skyBottom: '#1e0606',
        mistColor: 'rgba(92, 30, 30, 0.45)',
        tree1: '#140404',
        tree2: '#0b0202',
        tree3: '#050101',
        leafColor: 'rgba(65, 18, 18, 0.45)',
        pillarColor: '#090101',
        torchColor: 'rgba(255, 110, 0, 0.65)',
        groundGrass: '#441616',
        platformTop: '#682828'
      },
      { // Coração Estelar / Dourado Ancestral (Region 4)
        skyTop: '#0f0a03',
        skyBottom: '#261b0a',
        mistColor: 'rgba(100, 75, 35, 0.45)',
        tree1: '#1b1207',
        tree2: '#110a04',
        tree3: '#070401',
        leafColor: 'rgba(75, 52, 22, 0.45)',
        pillarColor: '#0f0904',
        torchColor: 'rgba(255, 140, 0, 0.65)',
        groundGrass: '#5c3e1a',
        platformTop: '#8c632f'
       }
    ];

    const theme = themes[activeRegIdx % themes.length];

    // Background gradients
    const bgGrad = ctx.createLinearGradient(0, 0, 0, CANVAS_HEIGHT);
    bgGrad.addColorStop(0, region.bg1);
    bgGrad.addColorStop(1, region.bg2);
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Weather, lightning & ambient storm parameters
    const globalT = globalTimerRef.current;
    const lCycle = 400; // lightning cycle duration in frames (approx. 6.6s)
    const lVal = globalT % lCycle;
    const isLightningActive = lVal >= 330 && lVal < 370;
    const strikeSeed = Math.floor(globalT / lCycle);
    
    // Deterministic horizontal position for each lightning strike
    const strikeX = (strikeSeed * 179 + 310) % (CANVAS_WIDTH - 320) + 160;

    // Dual-flash progression curves
    let flashIntensity = 0;
    if (isLightningActive) {
      if ((lVal >= 330 && lVal < 334) || (lVal >= 340 && lVal < 343)) {
        flashIntensity = 0.4; // rapid pre-flashing
      } else if (lVal >= 346 && lVal < 358) {
        flashIntensity = 0.95; // primary thunderous flash
      } else if (lVal >= 362 && lVal < 366) {
        flashIntensity = 0.55; // lingering echo flicker
      }
    }

    // Camera shake trigger at the exact impact frame of the primary lightning
    if (lVal === 346) {
      screenShakeRef.current = Math.max(screenShakeRef.current, 10);
      audio.playSFX('hit'); // invoke visceral punch for the thunder clap
    }

    // Helper functions for seeded procedural lightning generation
    const getLightningRand = (s: number) => {
      let seedValue = s;
      return () => {
        seedValue = (seedValue * 9301 + 49297) % 233280;
        return seedValue / 233280;
      };
    };

    const drawSeededLightning = (sX: number, sY: number, eX: number, eY: number, bSeed: number) => {
      const boltRng = getLightningRand(bSeed);
      
      const drawBranch = (startX: number, startY: number, endX: number, endY: number, size: number, depth: number) => {
        if (depth > 4) return;
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        
        let curX = startX;
        let curY = startY;
        const steps = 15;
        const dy = (endY - startY) / steps;
        const dx = (endX - startX) / steps;
        
        for (let s = 1; s <= steps; s++) {
          const targetY = startY + dy * s;
          const pct = s / steps;
          const deviationScale = Math.sin(pct * Math.PI); // wider deviation bounds toward middle
          const displacement = (boltRng() - 0.5) * 26 * deviationScale;
          const targetX = startX + dx * s + displacement;
          
          ctx.lineTo(targetX, targetY);
          
          // Spawn minor branching streams periodically
          if (boltRng() > 0.76 && depth < 3) {
            const bEndX = targetX + (boltRng() - 0.5) * 90;
            const bEndY = targetY + 30 + boltRng() * 50;
            ctx.save();
            ctx.lineWidth = size * 0.45;
            drawBranch(targetX, targetY, bEndX, bEndY, size * 0.45, depth + 1);
            ctx.restore();
          }
          
          curX = targetX;
          curY = targetY;
        }
        ctx.stroke();
      };
      
      ctx.save();
      // Outer neon corona/glow mapping
      ctx.strokeStyle = 'rgba(0, 196, 255, 0.75)';
      ctx.lineWidth = 7.5;
      ctx.shadowColor = 'rgba(0, 240, 255, 1)';
      ctx.shadowBlur = 18;
      drawBranch(sX, sY, eX, eY, 7.5, 1);
      
      // Intense white inner core
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 3.0;
      ctx.shadowBlur = 0;
      drawBranch(sX, sY, eX, eY, 3.0, 1);
      ctx.restore();
    };

    // Decorative assets based on region - UPGRADED TO MULTI-LAYER PARALLAX DEPTH HIERARCHY
    const camXVal = cameraXRef.current;
    
    if (activeRegIdx >= 0) {
      // OVERRIDE: Sky gradient with custom forest theme sky colors
      const forestBgGrad = ctx.createLinearGradient(0, 0, 0, CANVAS_HEIGHT);
      forestBgGrad.addColorStop(0, theme.skyTop);
      forestBgGrad.addColorStop(1, theme.skyBottom);
      ctx.fillStyle = forestBgGrad;
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      // Warm Volumetric ambient light glow in the center-left mirroring the photo
      const volGlow = ctx.createRadialGradient(CANVAS_WIDTH * 0.45, CANVAS_HEIGHT * 0.4, 80, CANVAS_WIDTH * 0.45, CANVAS_HEIGHT * 0.4, 400);
      volGlow.addColorStop(0, theme.mistColor);
      volGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = volGlow;
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      // Dynamic lightning flash glow overlay
      if (flashIntensity > 0) {
        ctx.fillStyle = `rgba(210, 240, 255, ${flashIntensity * 0.18})`;
        ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      }

      // DRAW ATMOSPHERIC FOREST PARALLAX LAYERS (Directly inspired by the photo!)
      
      // LAYER 1: Extremely Far Pine trees & thin pillars (Speed: 0.08)
      ctx.fillStyle = theme.tree1;
      for (let i = 0; i < 14; i++) {
        const mx = (i * 130 - camXVal * 0.08) % (CANVAS_WIDTH + 200) - 100;
        
        // Draw far trees
        ctx.fillRect(mx + 20, 0, 10, GROUND_Y);
        
        // Draw simplified leaf cluster on top
        ctx.beginPath();
        ctx.arc(mx + 25, 120, 25, 0, Math.PI * 2);
        ctx.fill();
      }
      // Draw far structural columns
      ctx.fillStyle = theme.pillarColor;
      for (let i = 0; i < 6; i++) {
        const px = (i * 260 - camXVal * 0.08) % (CANVAS_WIDTH + 300) - 150;
        ctx.fillRect(px, 0, 14, GROUND_Y);
      }

      // Volumetric Mist Layer 1
      const mistGrad1 = ctx.createLinearGradient(0, 200, 0, GROUND_Y);
      mistGrad1.addColorStop(0, 'rgba(0, 0, 0, 0)');
      mistGrad1.addColorStop(1, theme.mistColor);
      ctx.fillStyle = mistGrad1;
      ctx.fillRect(0, 200, CANVAS_WIDTH, GROUND_Y - 200);

      // LAYER 2: Mid-distance gorgeous tall trunks, tree branches, and gothic pillars (Speed: 0.22)
      for (let i = 0; i < 11; i++) {
        const tx = (i * 180 - camXVal * 0.22) % (CANVAS_WIDTH + 240) - 120;
        
        // Draw tree trunks in mid-ground
        ctx.fillStyle = theme.tree2;
        ctx.fillRect(tx + 40, 0, 18, GROUND_Y);

        // Draw branching structures
        ctx.beginPath();
        ctx.moveTo(tx + 49, 180);
        ctx.quadraticCurveTo(tx + 20, 130, tx - 10, 110);
        ctx.quadraticCurveTo(tx + 20, 145, tx + 49, 210);
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(tx + 49, 150);
        ctx.quadraticCurveTo(tx + 80, 110, tx + 110, 90);
        ctx.quadraticCurveTo(tx + 75, 125, tx + 49, 175);
        ctx.fill();

        // Leaf clusters near branch ends
        ctx.fillStyle = theme.leafColor;
        ctx.beginPath();
        ctx.arc(tx - 10, 110, 35, 0, Math.PI * 2);
        ctx.arc(tx + 110, 90, 40, 0, Math.PI * 2);
        ctx.arc(tx + 49, 70, 45, 0, Math.PI * 2);
        ctx.fill();
      }

      // Mid structural gothic ruins columns & arches
      ctx.fillStyle = theme.pillarColor;
      for (let i = 0; i < 5; i++) {
        const cx = (i * 340 - camXVal * 0.22) % (CANVAS_WIDTH + 400) - 200;
        
        // Vertical pillars
        ctx.fillRect(cx, 0, 20, GROUND_Y);
        ctx.fillRect(cx + 80, 0, 20, GROUND_Y);
        
        // Gothic arch connecting them at the top
        ctx.beginPath();
        ctx.arc(cx + 50, 60, 40, Math.PI, 0);
        ctx.strokeStyle = theme.pillarColor;
        ctx.lineWidth = 14;
        ctx.stroke();
      }

      // Volumetric Mist Layer 2 (adds glorious deep foggy layers from the photograph)
      const mistGrad2 = ctx.createLinearGradient(0, 150, 0, GROUND_Y);
      mistGrad2.addColorStop(0, 'rgba(0, 0, 0, 0)');
      mistGrad2.addColorStop(0.5, theme.mistColor);
      mistGrad2.addColorStop(1, 'rgba(0, 0, 0, 0.4)');
      ctx.fillStyle = mistGrad2;
      ctx.fillRect(0, 150, CANVAS_WIDTH, GROUND_Y - 150);

      // LAYER 3: Interactive Near-foreground tree columns, sprawling branches, creepers & hanging lantern cages (Speed: 0.42)
      for (let i = 0; i < 7; i++) {
        const hx = (i * 260 - camXVal * 0.42) % (CANVAS_WIDTH + 300) - 150;
        
        ctx.fillStyle = theme.tree3;
        // Colossal vertical trunks
        ctx.fillRect(hx, 0, 42, GROUND_Y);
        
        // Huge horizontal canopy sweeps at the top
        ctx.beginPath();
        ctx.ellipse(hx + 21, 40, 140, 50, 0, 0, Math.PI * 2);
        ctx.fill();

        // Hanging moss ropes / creepers swaying in the ambient air!
        const swayAmt = Math.sin(globalTimerRef.current * 0.03 + i) * 6;
        ctx.strokeStyle = theme.leafColor;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(hx + 10, 40);
        ctx.quadraticCurveTo(hx + 10 + swayAmt * 0.5, 140, hx + 10 + swayAmt, 220);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(hx + 32, 35);
        ctx.quadraticCurveTo(hx + 32 - swayAmt * 0.6, 120, hx + 32 - swayAmt, 180);
        ctx.stroke();

        // Little dangling foliage leaves on moss ropes
        ctx.fillStyle = theme.leafColor;
        ctx.beginPath();
        ctx.arc(hx + 10 + swayAmt, 220, 4, 0, Math.PI * 2);
        ctx.arc(hx + 32 - swayAmt, 180, 3.5, 0, Math.PI * 2);
        ctx.fill();

        // Hanging caged lamps (inspired by the cage light on the left of the photo!)
        if (i % 3 === 1) {
          const cageX = hx + 100 + swayAmt * 0.3;
          const cageY = 120 + Math.abs(swayAmt) * 0.4;

          // Long support chain
          ctx.strokeStyle = '#050a09';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(cageX, 0);
          ctx.lineTo(cageX, cageY);
          ctx.stroke();

          // Iron cage structure
          ctx.fillStyle = '#020304';
          ctx.fillRect(cageX - 10, cageY, 20, 30);
          
          ctx.fillStyle = '#ff7b00'; // burning lamp fuel
          ctx.fillRect(cageX - 6, cageY + 6, 12, 18);

          // Grid lines for the cage bars
          ctx.strokeStyle = '#010203';
          ctx.lineWidth = 2.0;
          ctx.strokeRect(cageX - 10, cageY, 20, 30);
          ctx.beginPath();
          ctx.moveTo(cageX - 3, cageY);
          ctx.lineTo(cageX - 3, cageY + 30);
          ctx.moveTo(cageX + 3, cageY);
          ctx.lineTo(cageX + 3, cageY + 30);
          ctx.stroke();

          // Tender orange flame halo around cage
          const cageGlow = ctx.createRadialGradient(cageX, cageY + 15, 2, cageX, cageY + 15, 60);
          cageGlow.addColorStop(0, 'rgba(255, 120, 0, 0.45)');
          cageGlow.addColorStop(0.5, 'rgba(255, 60, 0, 0.12)');
          cageGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = cageGlow;
          ctx.beginPath();
          ctx.arc(cageX, cageY + 15, 60, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }

    // --- OVERCAST STORM CLOUD SYSTEM ("CÉU NUBLADO") ---
    // Background heavy drifting thunderheads
    ctx.save();
    const stormProg = globalT * 0.085;
    ctx.fillStyle = activeRegIdx === 0 ? 'rgba(7, 13, 17, 0.84)' : activeRegIdx === 1 ? 'rgba(14, 11, 22, 0.86)' : activeRegIdx === 2 ? 'rgba(5, 14, 5, 0.82)' : activeRegIdx === 3 ? 'rgba(4, 4, 9, 0.88)' : 'rgba(24, 4, 9, 0.84)';
    for (let i = 0; i < 8; i++) {
      const cx = (i * 180 + stormProg * 0.4 - camXVal * 0.05) % (CANVAS_WIDTH + 240) - 120;
      const cy = -35 + Math.sin(i * 1.4) * 8;
      ctx.beginPath();
      ctx.arc(cx, cy, 100, 0, Math.PI * 2);
      ctx.fill();
    }
    
    // Foreground turbulent storm masses
    ctx.fillStyle = activeRegIdx === 0 ? 'rgba(16, 26, 30, 0.88)' : activeRegIdx === 1 ? 'rgba(26, 18, 40, 0.90)' : activeRegIdx === 2 ? 'rgba(10, 24, 10, 0.88)' : activeRegIdx === 3 ? 'rgba(12, 11, 20, 0.93)' : 'rgba(40, 11, 19, 0.90)';
    for (let i = 0; i < 6; i++) {
      const cx = (i * 240 - stormProg * 0.65 - camXVal * 0.09) % (CANVAS_WIDTH + 300) - 150;
      const cy = -20 + Math.cos(i * 2.1) * 11;
      ctx.beginPath();
      ctx.arc(cx, cy, 120, 0, Math.PI * 2);
      ctx.fill();
      
      // Cloudy highlights loaded with spatial energy during electric discharge window
      if (flashIntensity > 0) {
        ctx.strokeStyle = `rgba(0, 235, 255, ${0.12 + flashIntensity * 0.38})`;
        ctx.lineWidth = 2.5;
        ctx.stroke();
      }
    }
    ctx.restore();

    // --- PROCEDURAL LIGHTNING BOLT RENDERING ---
    if (isLightningActive && flashIntensity > 0.45) {
      const targetImpactY = GROUND_Y - 20;
      const impactDisplacement = Math.sin(strikeSeed * 4.3) * 140;
      drawSeededLightning(strikeX, 40, strikeX + impactDisplacement, targetImpactY, strikeSeed);
    }

    // Ambient landscape illumination overlays on high-voltage flash frames
    if (flashIntensity > 0) {
      ctx.fillStyle = `rgba(215, 242, 255, ${flashIntensity * 0.36})`;
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    }


    // --- BAMBOO FOREST DEEP DETAILED PARALLAX (from reference image) ---
    ctx.save();
    // Segmented parallax layers of vertical bamboo stems rising from base
    const numBamboos = 32;
    for (let b = 0; b < numBamboos; b++) {
      const bSeed = b * 543 + 321;
      const layer = (b % 3) + 1; // 3 deep parallax layers
      let scrollSpeed = 0.12; 
      let bColor = 'rgba(10, 20, 15, 0.16)';
      let bThickness = 4;
      if (layer === 2) {
        scrollSpeed = 0.28;
        bThickness = 9;
        bColor = activeRegIdx === 2 ? 'rgba(8, 22, 12, 0.45)' : 'rgba(15, 18, 25, 0.48)';
      } else if (layer === 3) {
        scrollSpeed = 0.45;
        bThickness = 16;
        bColor = activeRegIdx === 2 ? '#020d04' : '#05070a'; // Foreground solid black silhouette stalks!
      }
      
      const bX = (b * 125 - camXVal * scrollSpeed) % (CANVAS_WIDTH + 240) - 120;
      
      // Draw vertical bamboo trunk
      ctx.fillStyle = bColor;
      ctx.fillRect(bX, 0, bThickness, GROUND_Y);
      
      // Draw node rings periodically
      ctx.fillStyle = activeRegIdx === 2 ? 'rgba(20, 48, 30, 0.55)' : 'rgba(30, 35, 45, 0.55)';
      if (layer === 3) ctx.fillStyle = '#102213';
      const nodeDistance = 80 + (bSeed % 40);
      for (let ny = 30; ny < GROUND_Y; ny += nodeDistance) {
        ctx.fillRect(bX - 2.5, ny, bThickness + 5, 4);
        
        // Minor bamboo leaves bursting from nodes
        if (bSeed % 2 === 0) {
          ctx.beginPath();
          ctx.ellipse(bX + bThickness/2 + 8, ny - 6, 8, 3, Math.PI / 6, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.beginPath();
          ctx.ellipse(bX + bThickness/2 - 8, ny - 6, 8, 3, -Math.PI / 6, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }
    ctx.restore();

    // --- HANGING LEAFY VINES (dripping from upper screen canvas border) ---
    ctx.save();
    const numVines = 14;
    for (let v = 0; v < numVines; v++) {
      const vSeed = v * 832 + 109;
      const vX = (v * 190 - camXVal * 0.5) % (CANVAS_WIDTH + 100) - 50;
      const vLength = 110 + (vSeed % 140);
      
      // Vine line stem
      ctx.strokeStyle = '#010502';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      let cx = vX;
      let cy = 0;
      ctx.moveTo(cx, cy);
      const steps = 10;
      for (let step = 1; step <= steps; step++) {
        const nextY = (vLength / steps) * step;
        const nextX = vX + Math.sin(globalTimerRef.current * 0.015 + step + v) * 5;
        ctx.lineTo(nextX, nextY);
        cx = nextX;
        cy = nextY;
      }
      ctx.stroke();

      // Leaflets
      ctx.fillStyle = activeRegIdx === 2 ? '#020b05' : '#010503';
      for (let step = 1; step < steps; step++) {
        const leafY = (vLength / steps) * step;
        const leafX = vX + Math.sin(globalTimerRef.current * 0.015 + step + v) * 5;
        
        ctx.beginPath();
        ctx.ellipse(leafX - 6, leafY, 6, 3.5, -Math.PI / 4, 0, Math.PI*2);
        ctx.fill();
        ctx.beginPath();
        ctx.ellipse(leafX + 6, leafY + 1, 6, 3.5, Math.PI / 4, 0, Math.PI*2);
        ctx.fill();
      }
    }
    ctx.restore();

    // --- EASTERN DOJO ARCHITECTURE SILHOUETTE (traditional curved slate pagoda roofs) ---
    ctx.save();
    ctx.fillStyle = activeRegIdx === 2 ? '#010803' : '#020305';
    for (let pIdx = 0; pIdx < 3; pIdx++) {
      const pX = (pIdx * 650 - camXVal * 0.08) % (CANVAS_WIDTH + 500) - 250;
      const pY = GROUND_Y - 320;
      
      // Pillars
      ctx.fillRect(pX + 30, pY + 80, 160, 240);
      
      // Roof deck 1
      ctx.beginPath();
      ctx.moveTo(pX, pY + 140);
      ctx.quadraticCurveTo(pX + 110, pY + 115, pX + 220, pY + 140);
      ctx.lineTo(pX + 200, pY + 105);
      ctx.quadraticCurveTo(pX + 110, pY + 95, pX + 20, pY + 105);
      ctx.closePath();
      ctx.fill();
      
      // Hanging red lanterns detail
      ctx.fillStyle = '#ff5500';
      ctx.beginPath();
      ctx.arc(pX + 15, pY + 145, 5, 0, Math.PI * 2);
      ctx.arc(pX + 205, pY + 145, 5, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.fillStyle = activeRegIdx === 2 ? '#010803' : '#020305';
      
      // Roof deck 2 (top pagoda spire)
      ctx.fillRect(pX + 60, pY + 10, 100, 90);
      ctx.beginPath();
      ctx.moveTo(pX + 30, pY + 15);
      ctx.quadraticCurveTo(pX + 110, pY - 5, pX + 190, pY + 15);
      ctx.lineTo(pX + 175, pY - 15);
      ctx.quadraticCurveTo(pX + 110, pY - 25, pX + 45, pY - 15);
      ctx.closePath();
      ctx.fill();
      
      ctx.fillRect(pX + 107, pY - 45, 6, 30);
      ctx.beginPath();
      ctx.arc(pX + 110, pY - 50, 6, 0, Math.PI*2);
      ctx.fill();
    }
    ctx.restore();


    // Platforms drawing
    platformsRef.current.forEach(pl => {
      const plX = pl.x - camXVal;
      if (plX > CANVAS_WIDTH + 60 || plX + pl.w < -60) return;

      if (pl.type === 'ground') {
        // Ground body: Deep shadowy silhouette
        ctx.fillStyle = '#020305';
        ctx.fillRect(plX, pl.y, pl.w, pl.h);
        
        // Mossy grass cover at the top
        ctx.fillStyle = theme.platformTop;
        ctx.fillRect(plX, pl.y, pl.w, 9);

        // Grass tufts / blades
        ctx.fillStyle = theme.groundGrass;
        for (let gx = 0; gx < pl.w; gx += 16) {
          const h = 5 + ((gx + pl.x) % 7);
          ctx.beginPath();
          ctx.moveTo(plX + gx, pl.y);
          ctx.lineTo(plX + gx + 4, pl.y - h);
          ctx.lineTo(plX + gx + 8, pl.y);
          ctx.closePath();
          ctx.fill();
        }

        // Roots extending down from the ground top edge
        ctx.strokeStyle = '#020304';
        ctx.lineWidth = 2.0;
        for (let rx = 10; rx < pl.w; rx += 45) {
          const rLen = 15 + ((rx + pl.x) % 15);
          ctx.beginPath();
          ctx.moveTo(plX + rx, pl.y + 9);
          ctx.quadraticCurveTo(plX + rx + 5, pl.y + 9 + rLen * 0.5, plX + rx, pl.y + 9 + rLen);
          ctx.stroke();
        }
      } else {
        // 2. Platform body (pitch-black silhouette style like the photo's foreground)
        let blockColor = '#010203';
        let lightRim = theme.platformTop;
        
        if (pl.type === 'ice') lightRim = '#7bc6e3';
        else if (pl.type === 'bounce_pad') lightRim = '#3fbc3f';
        else if (pl.type === 'light_trap') lightRim = `rgba(255, 220, 100, ${0.7 + Math.sin(globalTimerRef.current * 0.1) * 0.2})`;
        else if (pl.type === 'shadow_zone') lightRim = '#6f2db8';
        else if (pl.type === 'vanish_platform' && pl.van) blockColor = 'rgba(10, 15, 30, 0.15)';
        else if (pl.type === 'crumble_platform' && pl.cr) blockColor = `rgba(10, 6, 4, ${1 - (pl.ct || 0) / 30})`;
        
        ctx.fillStyle = blockColor;
        ctx.fillRect(plX, pl.y, pl.w, pl.h);

        // Radiant mossy top line
        ctx.fillStyle = lightRim;
        ctx.fillRect(plX, pl.y, pl.w, 4.5);

        // Solid bottom border
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(plX, pl.y, pl.w, pl.h);

        // No sprawling roots or dangling foliage vines under floating decks to keep platforms perfectly elevated and clean
      }
    });

    // Draw some dynamic Dojo Torches & Lanterns and Silhouette Crates/Ladders on platforms!
    platformsRef.current.forEach((pl, idx) => {
      const plX = pl.x - camXVal;
      if (plX > CANVAS_WIDTH + 150 || plX + pl.w < -150) return;

      const platSeed = Math.floor(pl.x * 2.3) + idx;
      
      // 1. Animated fire torches
      if (platSeed % 4 === 0 && pl.w > 80 && pl.type !== 'ground') {
        const torchX = plX + 25;
        const torchY = pl.y;

        ctx.fillStyle = '#0a0a0f';
        ctx.fillRect(torchX - 2.5, torchY - 22, 5, 22);
        ctx.fillRect(torchX - 5, torchY - 26, 10, 4);

        const flameBob = Math.sin(globalTimerRef.current * 0.15 + platSeed) * 2;
        const flameGlow = ctx.createRadialGradient(torchX, torchY - 30, 2, torchX, torchY - 30, 24);
        flameGlow.addColorStop(0, 'rgba(255, 120, 0, 0.45)');
        flameGlow.addColorStop(0.6, 'rgba(255, 60, 0, 0.14)');
        flameGlow.addColorStop(1, 'rgba(255, 0, 0, 0)');
        ctx.fillStyle = flameGlow;
        ctx.fillRect(torchX - 24, torchY - 54, 48, 48);

        ctx.fillStyle = '#ff6b00';
        ctx.beginPath();
        ctx.moveTo(torchX - 4, torchY - 26);
        ctx.quadraticCurveTo(torchX - 7, torchY - 36, torchX + flameBob, torchY - 44);
        ctx.quadraticCurveTo(torchX + 7, torchY - 36, torchX + 4, torchY - 26);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#ffdd00';
        ctx.beginPath();
        ctx.moveTo(torchX - 2, torchY - 26);
        ctx.quadraticCurveTo(torchX - 4, torchY - 32, torchX + flameBob * 0.6, torchY - 38);
        ctx.quadraticCurveTo(torchX + 4, torchY - 32, torchX + 2, torchY - 26);
        ctx.closePath();
        ctx.fill();

        if (globalTimerRef.current % 18 === 0) {
          particlesRef.current.push({
            x: pl.x + 25,
            y: pl.y - 32,
            vx: (Math.random() - 0.5) * 0.5,
            vy: -0.6 - Math.random() * 0.8,
            life: 20 + Math.random() * 15,
            mxL: 35,
            col: '#ff7a00',
            sz: 1.5 + Math.random() * 2
          });
        }
      }

      // 2. Silhouetted wooden Crates with X wood frames
      if (platSeed % 5 === 1 && pl.type !== 'ground') {
        const crateX = plX + pl.w - 40;
        const crateY = pl.y - 25;
        const crateSize = 25;

        ctx.fillStyle = '#020406';
        ctx.fillRect(crateX, crateY, crateSize, crateSize);
        ctx.strokeStyle = activeRegIdx === 2 ? 'rgba(74, 232, 137, 0.22)' : 'rgba(255, 255, 255, 0.12)';
        ctx.lineWidth = 1.2;
        ctx.strokeRect(crateX, crateY, crateSize, crateSize);
        
        ctx.beginPath();
        ctx.moveTo(crateX + 3, crateY + 3);
        ctx.lineTo(crateX + crateSize - 3, crateY + crateSize - 3);
        ctx.moveTo(crateX + crateSize - 3, crateY + 3);
        ctx.lineTo(crateX + 3, crateY + crateSize - 3);
        ctx.stroke();
      }

      // 3. Hanging Rope ladders connecting floating decks
      if (platSeed % 6 === 2 && pl.type !== 'ground' && pl.y > 280) {
        const ladderX = plX + pl.w / 2 - 10;
        const ladderYStart = pl.y;
        const ladderYEnd = GROUND_Y;

        ctx.strokeStyle = 'rgba(7, 10, 15, 0.72)';
        ctx.lineWidth = 3.0;
        ctx.beginPath();
        ctx.moveTo(ladderX, ladderYStart);
        ctx.lineTo(ladderX, ladderYEnd);
        ctx.moveTo(ladderX + 20, ladderYStart);
        ctx.lineTo(ladderX + 20, ladderYEnd);
        ctx.stroke();

        ctx.lineWidth = 1.8;
        ctx.beginPath();
        for (let ry = ladderYStart + 12; ry < ladderYEnd; ry += 16) {
          ctx.moveTo(ladderX - 2, ry);
          ctx.lineTo(ladderX + 22, ry);
        }
        ctx.stroke();
      }
    });

    // Render Story Scrolls (Códices / Pergaminhos de Lore)
    storyScrollsRef.current.forEach(scroll => {
      if (scroll.col) return;
      const sX = scroll.x - camXVal;
      if (sX > CANVAS_WIDTH + 30 || sX < -30) return;

      const bobY = Math.sin(globalTimerRef.current * 0.04 + scroll.x) * 1.5;
      const finalY = scroll.y + bobY;

      // Magical glowing aura
      const scrollGlow = ctx.createRadialGradient(sX, finalY, 1, sX, finalY, 32);
      scrollGlow.addColorStop(0, 'rgba(74, 232, 137, 0.48)');
      scrollGlow.addColorStop(0.7, 'rgba(74, 232, 137, 0.14)');
      scrollGlow.addColorStop(1, 'rgba(74, 232, 137, 0)');
      ctx.fillStyle = scrollGlow;
      ctx.fillRect(sX - 32, finalY - 32, 64, 64);

      // golden borders with ancient rolled parchment style
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = '#fbbf24';

      ctx.fillStyle = '#b45309';
      ctx.fillRect(sX - 16, finalY - 11, 4, 22);

      ctx.fillStyle = '#fef3c7';
      ctx.fillRect(sX - 12, finalY - 9, 24, 18);

      ctx.fillStyle = '#b45309';
      ctx.fillRect(sX + 12, finalY - 11, 4, 22);

      ctx.fillStyle = '#78350f';
      ctx.fillRect(sX - 8, finalY - 4, 16, 1.8);
      ctx.fillRect(sX - 8, finalY, 16, 1.8);
      ctx.fillRect(sX - 8, finalY + 4, 10, 1.8);

      if (globalTimerRef.current % 30 === 0) {
        particlesRef.current.push({
          x: scroll.x + (Math.random() - 0.5) * 20,
          y: scroll.y + (Math.random() - 0.5) * 20,
          vx: (Math.random() - 0.5) * 0.8,
          vy: -0.4 - Math.random() * 0.6,
          life: 25 + Math.random() * 15,
          mxL: 40,
          col: '#4ae889',
          sz: 1.5 + Math.random() * 1.5
        });
      }
    });

    // Crystals collectibles
    crystalsRef.current.forEach(cr => {
      if (cr.col) return;
      const cX = cr.x - camXVal;
      if (cX > CANVAS_WIDTH + 30 || cX < -30) return;

      const crystalBobY = Math.sin(globalTimerRef.current * 0.06 + cr.x) * 6;
      const lightRipple = ctx.createRadialGradient(cX, cr.y + crystalBobY, 1, cX, cr.y + crystalBobY, 32);
      lightRipple.addColorStop(0, 'rgba(255, 220, 100, 0.45)');
      lightRipple.addColorStop(0.7, 'rgba(255, 200, 50, 0.12)');
      lightRipple.addColorStop(1, 'rgba(255, 200, 50, 0)');
      
      ctx.fillStyle = lightRipple;
      ctx.fillRect(cX - 32, cr.y + crystalBobY - 32, 64, 64);

      ctx.fillStyle = '#ffcc00';
      ctx.beginPath();
      ctx.moveTo(cX, cr.y + crystalBobY - 14);
      ctx.lineTo(cX + 11, cr.y + crystalBobY);
      ctx.lineTo(cX, cr.y + crystalBobY + 14);
      ctx.lineTo(cX - 11, cr.y + crystalBobY);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = '#ffeedd';
      ctx.beginPath();
      ctx.moveTo(cX, cr.y + crystalBobY - 8);
      ctx.lineTo(cX + 6, cr.y + crystalBobY);
      ctx.lineTo(cX, cr.y + crystalBobY + 8);
      ctx.lineTo(cX - 6, cr.y + crystalBobY);
      ctx.closePath();
      ctx.fill();
    });

    // Heal Orbs
    lightOrbsRef.current.forEach(orb => {
      if (!orb.active) return;
      const oX = orb.x - camXVal;
      if (oX > CANVAS_WIDTH + 20 || oX < -20) return;

      const pulseRadius = 7 + Math.sin(globalTimerRef.current * 0.08 + orb.x) * 2;
      ctx.fillStyle = 'rgba(78, 200, 255, 0.6)';
      ctx.beginPath();
      ctx.arc(oX, orb.y, pulseRadius, 0, Math.PI * 2);
      ctx.fill();
    });

    // Obstacles/Spikes hazards
    hazardsRef.current.forEach(h => {
      const hX = h.x - camXVal;
      if (hX > CANVAS_WIDTH + 40 || hX + h.w < -40) return;

      if (h.type === 'spike') {
        const bY = h.baseY || GROUND_Y;
        const drawH = bY - h.y;
        if (drawH > 1) {
          const numSpikes = 3;
          const individualW = h.w / numSpikes;
          
          for (let s = 0; s < numSpikes; s++) {
            const startX = hX + s * individualW;
            const midX = startX + individualW / 2;
            const endX = startX + individualW;
            const baseYCoord = bY;
            const topYCoord = h.y;
            
            // Outer glow aura
            ctx.beginPath();
            ctx.moveTo(startX - 2, baseYCoord);
            ctx.lineTo(midX, topYCoord - 3);
            ctx.lineTo(endX + 2, baseYCoord);
            ctx.closePath();
            ctx.fillStyle = 'rgba(230, 57, 70, 0.22)';
            ctx.fill();

            // Base triangle
            ctx.beginPath();
            ctx.moveTo(startX, baseYCoord);
            ctx.lineTo(midX, topYCoord);
            ctx.lineTo(endX, baseYCoord);
            ctx.closePath();
            
            // Beautiful fire/obsidian gradient
            const grad = ctx.createLinearGradient(midX, topYCoord, midX, baseYCoord);
            grad.addColorStop(0, '#ff4757');
            grad.addColorStop(0.35, '#e63946');
            grad.addColorStop(1, '#1e272e');
            
            ctx.fillStyle = grad;
            ctx.fill();

            // Dynamic sharp red-orange outline
            ctx.strokeStyle = '#ff6b81';
            ctx.lineWidth = 1.8;
            ctx.stroke();

            // Right-side structural shadow for 3D metallic volume
            ctx.beginPath();
            ctx.moveTo(midX, topYCoord);
            ctx.lineTo(endX, baseYCoord);
            ctx.lineTo(midX, baseYCoord);
            ctx.closePath();
            ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
            ctx.fill();
          }

          // Ground fracture crack slot representing where the spikes arise from
          ctx.fillStyle = '#ff4757';
          ctx.fillRect(hX - 4, bY - 2, h.w + 8, 3);
        }
      } else if (h.type === 'saw') {
        ctx.save();
        ctx.translate(hX + h.w / 2, h.y + h.h / 2);
        ctx.rotate(h.rot || 0);
        ctx.fillStyle = '#ff6b3b';
        ctx.beginPath();
        ctx.arc(0, 0, 13, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#dddddd';
        // draw raw teeth
        for (let teeth = 0; teeth < 8; teeth++) {
          ctx.rotate(Math.PI / 4);
          ctx.fillRect(8, -2, 5, 4);
        }
        ctx.restore();
      } else if (h.type === 'root') {
        ctx.fillStyle = '#2b7a3e';
        ctx.fillRect(hX, h.y, 6, 20);
      }
    });

    // Regular enemies
    enemiesRef.current.forEach(en => {
      if (!en.alive) return;
      const ex = en.x - camXVal;
      const ey = en.flying ? (en.fy || 0) : en.y;
      if (ex > CANVAS_WIDTH + 60 || ex + en.w < -60) return;

      // Drop shadow ellipse
      ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
      ctx.beginPath();
      ctx.ellipse(ex + en.w / 2, ey + en.h, en.w / 2 + 1, 4.5, 0, 0, Math.PI * 2);
      ctx.fill();

      // Core custom graphics draw
      const isStunned = en.stun > 0;
      const frameState = isStunned ? 'attack' : Math.abs(en.vx) > 0.3 ? 'walk' : 'idle';
      const drawScale = (en.flying ? 1.9 : 2.2) * 1.6;
      const renderBob = Math.sin(globalTimerRef.current * 0.08 + en.x) * 2;

      drawPixelSprite(
        ctx,
        ENEMY_SPRITE_TEMPLATES,
        en.spriteType,
        frameState,
        ex, ey + renderBob,
        drawScale,
        en.dir < 0,
        isStunned ? 0 : en.animFrame
      );

      // Aggressive red gaze under high light triggers ("Mariposa e Chama")
      if (lightPower > 50) {
        ctx.globalAlpha = 0.35 + Math.sin(globalTimerRef.current * 0.1) * 0.15;
        ctx.fillStyle = '#ff3333';
        ctx.beginPath();
        // Place glowing eyes approximately on high level frames
        ctx.arc(ex + en.w / 2 + (en.dir > 0 ? 6 : -6), ey + 8 + renderBob, 4.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1.0;
      }

      // Stun overlay sparklet indicator
      if (isStunned) {
        ctx.globalAlpha = 0.5 + Math.sin(globalTimerRef.current * 0.2) * 0.3;
        ctx.fillStyle = '#ffdd55';
        ctx.beginPath();
        ctx.arc(ex + en.w / 2, ey + renderBob - 8, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1.0;
      }

      // Life indicator bar
      if (en.hp < en.mxHp) {
        ctx.fillStyle = '#1e1a1a';
        ctx.fillRect(ex, ey - 10 + renderBob, en.w, 4.5);
        ctx.fillStyle = '#e63946';
        ctx.fillRect(ex, ey - 10 + renderBob, en.w * (en.hp / en.mxHp), 4.5);
      }
    });

    // Boss drawing
    const boss = bossRef.current;
    if (boss && boss.alive) {
      const bx = boss.x - camXVal;
      const by = boss.y;

      // Glowing aura
      const bossGlow = ctx.createRadialGradient(bx + boss.w / 2, by + boss.h / 2, 8, bx + boss.w / 2, by + boss.h / 2, 70);
      bossGlow.addColorStop(0, 'rgba(142, 68, 173, 0.25)');
      bossGlow.addColorStop(1, 'rgba(142, 68, 173, 0)');
      ctx.fillStyle = bossGlow;
      ctx.fillRect(bx - 40, by - 40, boss.w + 80, boss.h + 80);

      // Sprited frames
      const isBossStun = boss.ft > 0;
      const bossScale = (boss.isMajor ? 3.6 : 3.0) * 1.5;
      const bossFrameState = isBossStun ? 'attack' : 'idle';
      
      drawPixelSprite(
        ctx,
        ENEMY_SPRITE_TEMPLATES,
        boss.isMajor ? 'guardiao' : 'sombraElitista',
        bossFrameState,
        bx, by,
        bossScale,
        boss.dir < 0,
        isBossStun ? 0 : boss.animFrame
      );

      // boss HP tags
      ctx.fillStyle = '#1a1a1a';
      ctx.fillRect(bx - 12, by - 16, boss.w + 24, 8);
      ctx.fillStyle = boss.col;
      ctx.fillRect(bx - 12, by - 16, (boss.w + 24) * (boss.hp / boss.mxHp), 8);
      ctx.strokeStyle = '#444';
      ctx.strokeRect(bx - 12, by - 16, boss.w + 24, 8);

      // Headline title
      ctx.font = 'bold 11px font-mono, Segoe UI, sans-serif';
      ctx.fillStyle = '#ff77aa';
      ctx.textAlign = 'center';
      ctx.fillText(boss.name, bx + boss.w / 2, by - 24);
      ctx.fillText(`FASE ${boss.pIdx + 1}/3`, bx + boss.w / 2, by - 36);
      ctx.textAlign = 'left';
    }

    // Draw Player
    const p = playerRef.current;
    const px = p.x - camXVal;
    const py = p.y;
    const isPlayerDamagedFlicker = !((p as any).hurtT && (p as any).hurtT > 0 && Math.floor(globalTimerRef.current / 4) % 2 === 0);

    if (p.hp > 0 && isPlayerDamagedFlicker) {
      // Background drop shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
      ctx.beginPath();
      ctx.ellipse(px + p.w / 2, py + p.h, 18, 5, 0, 0, Math.PI * 2);
      ctx.fill();

      // Ascension aura multiplier
      const ascPhaseColors = [
        'rgba(100, 100, 160, ',
        'rgba(110, 130, 200, ',
        'rgba(140, 170, 220, ',
        'rgba(170, 200, 245, ',
        'rgba(210, 235, 255, '
      ];
      const ascColorVal = ascPhaseColors[p.ascPhase];
      const radialGlow = ctx.createRadialGradient(px + p.w / 2, py + p.h / 2, 2, px + p.w / 2, py + p.h / 2, 50 + lightPower * 0.95);
      radialGlow.addColorStop(0, `${ascColorVal}${0.35 + (lightPower / 200.0)})`);
      radialGlow.addColorStop(1, 'rgba(100, 120, 255, 0)');
      ctx.fillStyle = radialGlow;
      ctx.fillRect(px - 50, py - 50, p.w + 100, p.h + 100);

      // Render actual player rectangular layers (Forest Ranger Clothing)
      const rangerGreenTorso = ['#2e7d32', '#1b5e20', '#388e3c', '#4caf50', '#81c784'][p.ascPhase];
      ctx.fillStyle = rangerGreenTorso;
      ctx.fillRect(px + 8, py + 16, 24, 24); // Ranger jacket
      
      // Gold ranger star badge on chest
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(px + 21, py + 18, 4, 4);

      // Ranger utility belt (Dark brown leather with gold shiny buckle)
      ctx.fillStyle = '#4e342e';
      ctx.fillRect(px + 8, py + 33, 24, 3);
      ctx.fillStyle = '#fbbf24';
      ctx.fillRect(px + 18, py + 32, 4, 5);
      
      // Face
      ctx.fillStyle = '#fadbd8'; // Skin tone
      ctx.fillRect(px + 10, py, 20, 18);

      // Dark brown hair under the hat (Behind neck)
      ctx.fillStyle = '#3e2723';
      ctx.fillRect(px + 10, py, 20, 4);

      // Draw Professional 3D Ranger Hat (Chapéu de Guarda Florestal)
      // Hat Crown
      ctx.fillStyle = '#8d6e63'; // Campaign hat khaki/brown
      ctx.fillRect(px + 9, py - 5, 22, 8);
      // Hat Strap (Dark leather strap)
      ctx.fillStyle = '#2d1a12';
      ctx.fillRect(px + 9, py + 1, 22, 2);
      // Wide Hat Brim
      ctx.fillStyle = '#8d6e63';
      ctx.fillRect(px + 4, py + 2, 32, 3);

      // Ranger Field Backpack on back (Mochila de Guarda Campo)
      const isFacingRight = p.fac === 1;
      const bpX = isFacingRight ? px + 1 : px + 23;
      // Main pocket
      ctx.fillStyle = '#4e342e'; // dark leather brown
      ctx.fillRect(bpX, py + 18, 8, 15);
      // Extra utility latch pocket
      ctx.fillStyle = '#5d4037';
      ctx.fillRect(isFacingRight ? bpX - 2 : bpX + 6, py + 22, 4, 9);
      // Golden reflective backpack buckles
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(bpX + 2, py + 20, 4, 2);
      ctx.fillRect(bpX + 2, py + 28, 4, 2);

      // Legs (Ranger Dark Cargo Pants & Explorer Boots)
      const legBob = Math.abs(p.vx) > 0.2 ? Math.sin(globalTimerRef.current * 0.2) * 5 : 0;
      // Khaki cargo trousers
      ctx.fillStyle = '#3e4a3c'; // Dark forest cargo pants
      ctx.fillRect(px + 9, py + 40, 8, 10 + legBob);
      ctx.fillRect(px + 23, py + 40, 8, 10 - legBob);
      
      // Hunter leather boots
      ctx.fillStyle = '#4e342e'; // Boot brown
      ctx.fillRect(px + 9, py + 50 + legBob, 8, 6);
      ctx.fillRect(px + 23, py + 50 - legBob, 8, 6);
      // Boots directional toes
      ctx.fillStyle = '#3e2723';
      if (isFacingRight) {
        ctx.fillRect(px + 12, py + 52 + legBob, 5, 4);
        ctx.fillRect(px + 26, py + 52 - legBob, 5, 4);
      } else {
        ctx.fillRect(px + 4, py + 52 + legBob, 5, 4);
        ctx.fillRect(px + 18, py + 52 - legBob, 5, 4);
      }

      // Eyes (Now with both eyes rendered!)
      const eyeOffset1 = px + 12 + (p.fac === 1 ? 4 : 0);
      const eyeOffset2 = px + 18 + (p.fac === 1 ? 4 : 0);

      ctx.fillStyle = '#ffffff';
      ctx.fillRect(eyeOffset1, py + 6, 4, 4);
      ctx.fillRect(eyeOffset2, py + 6, 4, 4);

      ctx.fillStyle = '#222244';
      ctx.fillRect(eyeOffset1 + 1, py + 7, 2, 2);
      ctx.fillRect(eyeOffset2 + 1, py + 7, 2, 2);

      // Draw 5-second Active Shield Bubble (Escudo Absoluto) if currently active
      if ((p as any).tempShieldT && (p as any).tempShieldT > 0) {
        ctx.save();
        const centerX = px + p.w / 2;
        const centerY = py + p.h / 2;
        const shieldPulse = Math.sin(globalTimerRef.current * 0.12) * 5;
        const shieldRadius = 34 + shieldPulse;

        // Radiant dynamic transparent energy bubble
        const shieldGrad = ctx.createRadialGradient(centerX, centerY, 5, centerX, centerY, shieldRadius);
        shieldGrad.addColorStop(0, 'rgba(129, 140, 248, 0.05)'); 
        shieldGrad.addColorStop(0.8, 'rgba(56, 189, 248, 0.22)'); 
        shieldGrad.addColorStop(1, 'rgba(99, 102, 241, 0.55)'); // Glowing outer border
        
        ctx.fillStyle = shieldGrad;
        ctx.beginPath();
        ctx.arc(centerX, centerY, shieldRadius, 0, Math.PI * 2);
        ctx.fill();

        // Thick border energy ring
        ctx.strokeStyle = 'rgba(129, 140, 248, 0.65)';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(centerX, centerY, shieldRadius, 0, Math.PI * 2);
        ctx.stroke();

        // Inner rotational celestial ring
        ctx.strokeStyle = 'rgba(165, 180, 252, 0.3)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(centerX, centerY, shieldRadius - 7, globalTimerRef.current * 0.05, globalTimerRef.current * 0.05 + Math.PI * 1.5);
        ctx.stroke();
        
        ctx.restore();
      }

      // Blinding halo at highest level
      if (p.ascPhase >= 4) {
        ctx.fillStyle = 'rgba(255, 235, 100, 0.28)';
        ctx.beginPath();
        ctx.arc(px + p.w / 2, py + p.h / 2, 36 + Math.sin(globalTimerRef.current * 0.08) * 4, 0, Math.PI * 2);
        ctx.fill();
      }

      // Custom High-Quality Tactical Ranger Baton (Cacetete Tático) Drawer
      const drawSupremeSword = (ctx: CanvasRenderingContext2D, baseHandX: number, baseHandY: number, angle: number, auraColor: string) => {
        ctx.save();
        ctx.translate(baseHandX, baseHandY);
        ctx.rotate(angle);

        // 1. Draw Stun/Electric Aura (Reflecting ranger progression eco-charging)
        ctx.save();
        ctx.shadowColor = auraColor;
        ctx.shadowBlur = 10;
        ctx.fillStyle = auraColor;
        // Glowing electric sleeve around major part of the baton rod
        ctx.fillRect(-2, -5, 42, 10);
        ctx.restore();

        // 2. Draw Main Baton Rod (High-durability Carbon Fiber, sleek charcoal black)
        ctx.fillStyle = '#1e293b'; // Charcoal slate
        ctx.fillRect(-10, -3.5, 45, 7); // Core length
        
        ctx.fillStyle = '#0f172a'; // Deepest navy-black for rod shadows
        ctx.fillRect(-10, 0, 45, 3.5);

        // 3. Round rubber cap tip (Extreme safety pointer)
        ctx.fillStyle = '#475569';
        ctx.beginPath();
        ctx.arc(35, 0, 3.5, -Math.PI/2, Math.PI/2);
        ctx.fill();

        // 4. Textured rubber handle grip (Riddled with horizontal stripes)
        ctx.fillStyle = '#020617'; // Absolute black
        ctx.fillRect(-10, -4, 12, 8);
        
        // Grip lines in silver/slate
        ctx.fillStyle = '#64748b';
        ctx.fillRect(-8, -4, 1, 8);
        ctx.fillRect(-5, -4, 1, 8);
        ctx.fillRect(-2, -4, 1, 8);

        // 5. Gold Safety Pommel End Ring
        ctx.fillStyle = '#eab308';
        ctx.fillRect(-12, -4.5, 2, 9);

        // 6. Tonfa Side-Handle Prong (PR-24 specific side grip)
        ctx.fillStyle = '#020617';
        ctx.fillRect(4, -14, 6, 11); // Prong body upward
        // Cap/Knob on prong
        ctx.fillStyle = '#475569';
        ctx.fillRect(2, -16, 10, 3);

        // 7. Reflective neon safety stripes (Real-life woodland ranger detail!)
        ctx.fillStyle = '#22c55e'; // Bright fluorescent green
        ctx.fillRect(14, -2.5, 4, 1);
        ctx.fillRect(24, -2.5, 4, 1);

        ctx.restore();
      };

      const handX = px + (p.fac === 1 ? 22 : 18);
      const handY = py + 26 + (Math.abs(p.vx) > 0.2 ? Math.sin(globalTimerRef.current * 0.2) * 2 : 0);
      const swordGlowCol = p.curAtk === 'heavy_slash' ? '#fbbf24' : ['#38bdf8', '#14b8a6', '#f59e0b', '#ec4899', '#ffffff'][p.ascPhase];

      // Attack and weapons visuals
      if (p.atk) {
        ctx.save();
        if (p.curAtk === 'down_slash') {
          // Points straight down
          drawSupremeSword(ctx, px + p.w / 2, py + p.h - 10, Math.PI / 2, swordGlowCol);
          ctx.fillStyle = 'rgba(56, 189, 248, 0.4)';
          ctx.fillRect(px + p.w / 2 - 3, py + p.h - 10, 6, 25);
        } else if (p.curAtk === 'flash') {
          // Blinding glow aura around player
          ctx.translate(px + p.w / 2, py + p.h / 2);
          ctx.fillStyle = 'rgba(254, 250, 190, 0.6)';
          ctx.beginPath();
          ctx.arc(0, 0, 48, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
          
          ctx.save();
          // Revolving weapon spinner frames
          const rotAngle = globalTimerRef.current * 0.35;
          drawSupremeSword(ctx, handX, handY, rotAngle, swordGlowCol);
        } else if (p.curAtk === 'special') {
          // Super AoE nova
          const rotAngle = globalTimerRef.current * 0.25;
          ctx.translate(px + p.w / 2, py + p.h / 2);
          ctx.rotate(rotAngle);
          ctx.fillStyle = 'rgba(255, 235, 150, 0.75)';
          ctx.beginPath();
          ctx.arc(0, 0, 56 + Math.sin(globalTimerRef.current * 0.1) * 8, 0, Math.PI * 2);
          ctx.fill();
        } else if (p.curAtk === 'thrust') {
          // Horizontal thrust pointer forward
          const thrustAngle = p.fac === 1 ? 0 : Math.PI;
          drawSupremeSword(ctx, handX + p.fac * 6, handY, thrustAngle, swordGlowCol);
          
          // Speed trail gradient
          const grad = ctx.createLinearGradient(handX, handY, handX + p.fac * 55, handY);
          grad.addColorStop(0, 'rgba(56, 189, 248, 0)');
          grad.addColorStop(0.5, 'rgba(56, 189, 248, 0.38)');
          grad.addColorStop(1, 'rgba(224, 242, 254, 0.7)');
          ctx.fillStyle = grad;
          ctx.fillRect(p.fac === 1 ? handX : handX - 55, handY - 3, 55, 6);
        } else if (p.curAtk === 'heavy_slash') {
          // Heavy overhead smash downwards
          const progress = 1 - (p.atkT / 30);
          const baseSlashAngle = -Math.PI * 0.8 + progress * Math.PI * 1.35;
          const strikeAngle = p.fac * baseSlashAngle;
          drawSupremeSword(ctx, handX, handY, strikeAngle, '#fbbf24');
          
          // Thick glowing arc trail
          ctx.beginPath();
          ctx.strokeStyle = 'rgba(245, 158, 11, 0.55)';
          ctx.lineWidth = 14;
          ctx.arc(handX, handY, 62, p.fac === 1 ? -Math.PI * 0.8 : Math.PI + Math.PI * 0.8, strikeAngle, p.fac < 0);
          ctx.stroke();
          
          ctx.beginPath();
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 4;
          ctx.arc(handX, handY, 62, p.fac === 1 ? -Math.PI * 0.8 : Math.PI + Math.PI * 0.8, strikeAngle, p.fac < 0);
          ctx.stroke();
        } else {
          // Normal attacks Z - top-to-bottom swing
          const maxComboFrames = p.curAtk === 'trp_slash' ? 20 : p.curAtk === 'dbl_slash' ? 15 : 12;
          const progress = 1 - (p.atkT / maxComboFrames);
          const baseSlashAngle = -Math.PI * 0.55 + progress * Math.PI * 0.95;
          const strikeAngle = p.fac * baseSlashAngle;
          drawSupremeSword(ctx, handX, handY, strikeAngle, swordGlowCol);

          // Swooping crescent shape trail
          ctx.beginPath();
          ctx.strokeStyle = p.curAtk === 'trp_slash' ? 'rgba(244, 63, 94, 0.45)' : 'rgba(56, 189, 248, 0.45)';
          ctx.lineWidth = 8;
          ctx.arc(handX, handY, 48, p.fac === 1 ? -Math.PI * 0.55 : Math.PI + Math.PI * 0.55, strikeAngle, p.fac < 0);
          ctx.stroke();

          ctx.beginPath();
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 2;
          ctx.arc(handX, handY, 48, p.fac === 1 ? -Math.PI * 0.55 : Math.PI + Math.PI * 0.55, strikeAngle, p.fac < 0);
          ctx.stroke();
        }
        ctx.restore();
      } else {
        // Sword rests in hand diagonally pointing upward-front when not attacking
        const baseIdleAngle = -Math.PI * 0.28;
        const idleAngle = p.fac === 1 ? baseIdleAngle : Math.PI - baseIdleAngle;
        drawSupremeSword(ctx, handX, handY, idleAngle, swordGlowCol);
      }

      // Forest Sprite / Auxiliary floating seed companion
      const followerBob = Math.sin(globalTimerRef.current * 0.15) * 3;
      ctx.fillStyle = 'rgba(74, 222, 128, 0.85)'; // Forest green glowing leaf sprite
      ctx.beginPath();
      ctx.arc(px + p.w / 2 + p.fac * 24, py + 22 + followerBob, 5, 0, Math.PI * 2);
      ctx.fill();
      
      // Internal gold spark nucleus of the sprite
      ctx.fillStyle = '#fef08a';
      ctx.beginPath();
      ctx.arc(px + p.w / 2 + p.fac * 24, py + 22 + followerBob, 2, 0, Math.PI * 2);
      ctx.fill();
    }

    // Projects elements
    projectilesRef.current.forEach(pp => {
      const projX = pp.x - camXVal;
      if (pp.type === 'fireball') {
        // SPINNING CAPTURE NET (REDE DE CAPTURA)
        ctx.save();
        ctx.translate(projX, pp.y);
        ctx.rotate(globalTimerRef.current * 0.14); // spins through the air!

        // Draw outer ring boundary
        ctx.strokeStyle = 'rgba(241, 245, 249, 0.55)'; // Light steel grey net border
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(0, 0, 16, 0, Math.PI * 2);
        ctx.stroke();

        // Draw radial gridlines (mesh straps)
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.75)'; // White high-durability capturing cords
        ctx.lineWidth = 1.0;
        ctx.beginPath();
        for (let angleOff = 0; angleOff < Math.PI; angleOff += Math.PI / 4) {
          const cos = Math.cos(angleOff) * 16;
          const sin = Math.sin(angleOff) * 16;
          ctx.moveTo(-cos, -sin);
          ctx.lineTo(cos, sin);
        }
        ctx.stroke();

        // Concentric circular threads of the net webbing
        ctx.beginPath();
        ctx.arc(0, 0, 11, 0, Math.PI * 2);
        ctx.arc(0, 0, 5, 0, Math.PI * 2);
        ctx.stroke();

        // Draw metallic lead-sinkers (pesos de chumbo) on net perimeter nodes
        ctx.fillStyle = '#475569'; // zinc metallic weights
        ctx.strokeStyle = '#1e293b';
        ctx.lineWidth = 0.5;
        for (let i = 0; i < 8; i++) {
          const a = (i * Math.PI) / 4;
          const wx = Math.cos(a) * 16;
          const wy = Math.sin(a) * 16;
          ctx.beginPath();
          ctx.arc(wx, wy, 2.5, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
        }

        // Ecological emerald/gold stunning emission glow inside net
        const stunGrad = ctx.createRadialGradient(0, 0, 2, 0, 0, 18);
        stunGrad.addColorStop(0, 'rgba(34, 197, 94, 0.3)'); 
        stunGrad.addColorStop(0.6, 'rgba(56, 189, 248, 0.15)');
        stunGrad.addColorStop(1, 'rgba(56, 189, 248, 0)');
        ctx.fillStyle = stunGrad;
        ctx.beginPath();
        ctx.arc(0, 0, 18, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();
      } else if (pp.type === 'explosion') {
        // CONTAINMENT GRID BURST (Rede de Contenção Ecológica)
        const radius = pp.w / 2;
        
        // Expanding green soft pulse
        const grad = ctx.createRadialGradient(projX, pp.y, 2, projX, pp.y, radius);
        grad.addColorStop(0, 'rgba(34, 197, 94, 0.45)'); // Emerald stun core
        grad.addColorStop(0.7, 'rgba(56, 189, 248, 0.18)'); // Seafoam outer ring
        grad.addColorStop(1, 'rgba(56, 189, 248, 0)');
        
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(projX, pp.y, radius, 0, Math.PI * 2);
        ctx.fill();

        // Glowing white grid lines (Entanglement web)
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.45)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (let angle = 0; angle < Math.PI * 2; angle += Math.PI / 6) {
          const xMax = projX + Math.cos(angle) * radius * 0.95;
          const yMax = pp.y + Math.sin(angle) * radius * 0.95;
          ctx.moveTo(projX, pp.y);
          ctx.lineTo(xMax, yMax);
        }
        ctx.stroke();

        // Concentric expanding web rings
        ctx.strokeStyle = 'rgba(74, 222, 128, 0.6)';
        ctx.beginPath();
        ctx.arc(projX, pp.y, radius * 0.6, 0, Math.PI * 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(projX, pp.y, radius * 0.3, 0, Math.PI * 2);
        ctx.stroke();
      } else if (pp.type === 'barrier') {
        ctx.strokeStyle = 'rgba(72, 202, 228, 0.65)';
        ctx.lineWidth = 3.5;
        ctx.beginPath();
        ctx.arc(projX, pp.y, pp.w / 2, 0, Math.PI * 2);
        ctx.stroke();
      } else if (['e_proj', 'laser'].includes(pp.type)) {
        ctx.fillStyle = pp.col || '#e63946';
        ctx.beginPath();
        ctx.arc(projX, pp.y, 6.5, 0, Math.PI * 2);
        ctx.fill();
      } else if (pp.type === 'poison') {
        ctx.fillStyle = '#2a9d8f';
        ctx.beginPath();
        ctx.arc(projX, pp.y, 5.5, 0, Math.PI * 2);
        ctx.fill();
      } else if (pp.type === 'void_orb') {
        ctx.fillStyle = '#9b5de5';
        ctx.beginPath();
        ctx.arc(projX, pp.y, 8, 0, Math.PI * 2);
        ctx.fill();
      } else if (pp.type === 'meteor') {
        ctx.fillStyle = '#aa33cc';
        ctx.beginPath();
        ctx.arc(projX, pp.y, 16, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ff5b5b';
        ctx.beginPath();
        ctx.arc(projX, pp.y, 9, 0, Math.PI * 2);
        ctx.fill();
      } else if (pp.type === 'b_beam') {
        ctx.fillStyle = pp.col || '#ff5599';
        ctx.fillRect(projX - pp.w / 2, pp.y - pp.h / 2, pp.w, pp.h);
      } else if (pp.type === 'orbital_blade') {
        ctx.save();
        ctx.translate(projX, pp.y);
        ctx.rotate(globalTimerRef.current * 0.18 + ((pp as any).orbitIndex || 0) * 1.5);
        ctx.fillStyle = pp.col || '#ffd166';
        
        ctx.beginPath();
        for (let i = 0; i < 4; i++) {
          ctx.rotate(Math.PI / 2);
          ctx.lineTo(12, 0);
          ctx.lineTo(3, 3);
        }
        ctx.closePath();
        ctx.fill();
        
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(0, 0, 4, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.restore();
      }
    });

    // Drawing stars/floating elements/ambient sparks
    drawAmbientFloatingParticles(ctx);

    // Particles trace drawing
    particlesRef.current.forEach(pElement => {
      ctx.globalAlpha = pElement.life / pElement.mxL;
      ctx.fillStyle = pElement.col;
      ctx.fillRect(pElement.x - camXVal - pElement.sz / 2, pElement.y - pElement.sz / 2, pElement.sz, pElement.sz);
    });
    ctx.globalAlpha = 1.0;

    // Draw Exit portal when all crystals are picked up
    drawExitPortalGate(ctx, camXVal);

    ctx.restore();
  };

  const drawAmbientFloatingParticles = (ctx: CanvasRenderingContext2D) => {
    const regionIdx = Math.floor(currentLevelIdx / 20);
    const pulseT = globalTimerRef.current;
    
    // Custom colors matching region themes
    const themes = ['#f4a261', '#457b9d', '#2a9d8f', '#9b5de5', '#ffb5a7'];
    const pCol = themes[regionIdx % themes.length];

    for (let i = 0; i < 15; i++) {
      const ax = (pulseT * 0.45 + i * 75) % CANVAS_WIDTH;
      const ay = 120 + Math.sin(pulseT * 0.015 + i) * 80 + regionIdx * 40;
      const opacity = 0.2 + Math.sin(pulseT * 0.06 + i * 2) * 0.15;
      
      ctx.fillStyle = `${pCol}15`;
      ctx.beginPath();
      ctx.arc(ax, ay, 4 + Math.sin(pulseT * 0.1 + i) * 2, 0, Math.PI * 2);
      ctx.fill();
    }
  };

  const drawExitPortalGate = (ctx: CanvasRenderingContext2D, camXVal: number) => {
    const allCollected = crystalsRef.current.every(c => c.col);
    if (!allCollected) return;

    const gateX = levelWidthRef.current - 120 - camXVal;
    const pulseScale = 0.65 + Math.sin(globalTimerRef.current * 0.08) * 0.25;

    const portalG = ctx.createRadialGradient(gateX + 20, GROUND_Y - 60, 2, gateX + 20, GROUND_Y - 60, 48);
    portalG.addColorStop(0, 'rgba(46, 204, 113, 0.55)');
    portalG.addColorStop(1, 'rgba(46, 204, 113, 0)');
    ctx.fillStyle = portalG;
    ctx.fillRect(gateX - 30, GROUND_Y - 110, 100, 100);

    ctx.fillStyle = `rgba(46, 204, 113, ${pulseScale})`;
    ctx.beginPath();
    ctx.arc(gateX + 20, GROUND_Y - 60, 24, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 9px font-sans, Segoe UI, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('PORTAL', gateX + 20, GROUND_Y - 62);
    ctx.fillText('ATIVO', gateX + 20, GROUND_Y - 50);
    ctx.textAlign = 'left';
  };

  const drawEquilibriumMinibar = (ctx: CanvasRenderingContext2D) => {
    const bWidth = 140;
    const bHeight = 8;
    const bx = CANVAS_WIDTH / 2 - bWidth / 2;
    const by = CANVAS_HEIGHT - 30;

    // outline
    ctx.fillStyle = 'rgba(5, 5, 10, 0.7)';
    ctx.fillRect(bx, by, bWidth, bHeight);

    const mid = bx + bWidth / 2;
    // draw left bar (Shadow) and right bar (Light)
    if (lightPower > 0) {
      ctx.fillStyle = '#f4a261'; // Light Power
      ctx.fillRect(mid, by, (bWidth / 2) * (lightPower / 100), bHeight);
    }
    if (shadowPower > 0) {
      ctx.fillStyle = '#9b5de5'; // Shadow Power
      ctx.fillRect(mid - (bWidth / 2) * (shadowPower / 100), by, (bWidth / 2) * (shadowPower / 100), bHeight);
    }

    ctx.strokeStyle = '#2c3e50';
    ctx.lineWidth = 1;
    ctx.strokeRect(bx, by, bWidth, bHeight);

    ctx.font = 'bold 8px font-mono, sans-serif';
    ctx.fillStyle = '#7f8c8d';
    ctx.textAlign = 'center';
    ctx.fillText('NÁDÍS SINTONIA (Sombra : Luz)', bx + bWidth / 2, by - 4);
    ctx.textAlign = 'left';
  };

  const bindControls = (key: string) => {
    return {
      onTouchStart: (e: React.TouchEvent) => {
        e.preventDefault();
        keysRef.current[key] = true;
      },
      onTouchEnd: (e: React.TouchEvent) => {
        e.preventDefault();
        keysRef.current[key] = false;
      },
      onTouchCancel: (e: React.TouchEvent) => {
        e.preventDefault();
        keysRef.current[key] = false;
      },
      onMouseDown: (e: React.MouseEvent) => {
        keysRef.current[key] = true;
      },
      onMouseUp: (e: React.MouseEvent) => {
        keysRef.current[key] = false;
      },
      onMouseLeave: (e: React.MouseEvent) => {
        keysRef.current[key] = false;
      }
    };
  };

  const renderBtnIcon = (icon: string) => {
    switch (icon) {
      case 'left': return <ChevronLeft className="w-9 h-9 pointer-events-none" />;
      case 'right': return <ChevronRight className="w-9 h-9 pointer-events-none" />;
      case 'up': return <ChevronUp className="w-7 h-7 pointer-events-none" />;
      case 'normal':
      case 'sword': return <Sword className="w-7 h-7 pointer-events-none" />;
      case 'thrust':
      case 'zap': return <Zap className="w-7 h-7 pointer-events-none rotate-90" />;
      case 'heavy':
      case 'hammer': return <Hammer className="w-7 h-7 pointer-events-none" />;
      case 'net': return <Grid className="w-7 h-7 pointer-events-none" />;
      default: return null;
    }
  };

  return (
    <div className="relative w-full h-full flex justify-center items-center select-none">
      <canvas
        ref={canvasRef}
        width={CANVAS_WIDTH}
        height={CANVAS_HEIGHT}
        id="gameCanvas"
        style={{
          filter: isEditingHud ? 'grayscale(100%) brightness(35%)' : 'none',
          transition: 'filter 0.3s ease-in-out'
        }}
        className="w-full h-full block bg-slate-950 border border-slate-900 rounded-2xl shadow-2xl"
      />

      {/* On-Screen Touch Controllers HUD for mobile playability (Running mode) */}
      {!isEditingHud && !isPaused && (
        <div 
          className="absolute inset-0 pointer-events-none select-none z-30"
          ref={containerRef}
        >
          {hudButtons.map((btn) => {
            if (btn.id === 'swordBar') return null; // Rendered by main system's HUD.tsx
            
            return (
              <div
                key={btn.id}
                className="absolute flex flex-col items-center pointer-events-auto select-none"
                style={{
                  left: `${btn.x}%`,
                  top: `${btn.y}%`,
                  transform: 'translate(-50%, -50%)',
                  opacity: btn.opacity !== undefined ? btn.opacity : 1.0,
                }}
              >
                <div 
                  style={{ transform: `scale(${btn.scale})` }}
                  className="flex flex-col items-center"
                >
                  <button
                    {...bindControls(btn.key)}
                    className={
                      btn.id === 'left' || btn.id === 'right' ? 
                      "w-16 h-16 rounded-full bg-slate-900/65 border-2 border-slate-700/60 flex items-center justify-center text-slate-100 active:bg-slate-850 active:border-emerald-500 shadow-xl cursor-pointer transform active:scale-95 transition" :
                      btn.id === 'thrust' ?
                      "w-16 h-16 rounded-full bg-slate-950/80 border-2 border-[#1faefc]/40 flex items-center justify-center text-[#1faefc] active:bg-[#1faefc]/25 active:border-[#1faefc] shadow-lg cursor-pointer transform active:scale-95 transition" :
                      btn.id === 'heavy' ?
                      "w-16 h-16 rounded-full bg-slate-950/80 border-2 border-amber-500/40 flex items-center justify-center text-amber-400 active:bg-amber-500/25 active:border-amber-500 shadow-lg cursor-pointer transform active:scale-95 transition" :
                      btn.id === 'normal' ?
                      "w-16 h-16 rounded-full bg-slate-950/80 border-2 border-emerald-500/40 flex items-center justify-center text-emerald-400 active:bg-emerald-500/25 active:border-emerald-500 shadow-lg cursor-pointer transform active:scale-95 transition" :
                      btn.id === 'net' ?
                      "w-16 h-16 rounded-full bg-slate-950/80 border-2 border-indigo-500/40 flex items-center justify-center text-indigo-400 active:bg-indigo-500/25 active:border-indigo-500 shadow-lg cursor-pointer transform active:scale-95 transition" :
                      "w-16 h-16 rounded-full bg-slate-950/80 border-2 border-slate-400/40 flex items-center justify-center text-slate-100 active:bg-slate-700/40 active:border-slate-200 shadow-lg cursor-pointer transform active:scale-95 transition"
                    }
                  >
                    {renderBtnIcon(btn.icon)}
                  </button>
                  <span className={`text-[9px] font-sans font-black tracking-wider uppercase text-center w-20 leading-none mt-1.5 ${
                    btn.id === 'thrust' ? 'text-[#1faefc]' :
                    btn.id === 'heavy' ? 'text-amber-500' :
                    btn.id === 'normal' ? 'text-emerald-400' :
                    btn.id === 'net' ? 'text-indigo-400' :
                    btn.id === 'left' || btn.id === 'right' ? 'text-slate-400' : 'text-slate-300'
                  }`}>
                    {btn.id === 'left' ? 'ESQUERDA' : btn.id === 'right' ? 'DIREITA' : btn.label}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Interactive Drag-and-Drop HUD Editing Mode */}
      {isEditingHud && (
        <div 
          className="absolute inset-0 z-40 bg-transparent flex flex-col justify-between pointer-events-none select-none"
          ref={containerRef}
        >
          {/* Editor Header Bar at the top */}
          <div className="w-full bg-slate-950/95 border-b border-slate-900 px-6 py-3.5 flex items-center justify-between text-white pointer-events-auto shadow-2xl select-none">
            <div className="flex flex-col">
              <h2 className="text-xs font-black text-amber-500 uppercase tracking-widest font-sans flex items-center gap-1.5 leading-none">
                <Sliders className="w-4 h-4 text-amber-400 animate-pulse" />
                Ajustar HUD de Controles
              </h2>
              <p className="text-[10px] text-slate-400 font-mono mt-1">
                Arraste os botões para mover • Use as teclas + e - para alterar o tamanho
              </p>
            </div>
            
            <div className="flex items-center gap-2.5">
              <button
                onClick={handleRestoreHud}
                className="flex items-center gap-1 px-4 py-1.5 bg-slate-900 border border-slate-800 hover:border-slate-750 hover:bg-slate-800 rounded-xl text-slate-300 hover:text-white text-[10px] font-black uppercase tracking-wider cursor-pointer duration-150 transform active:scale-95 shadow-lg"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Restaurar
              </button>
              <button
                onClick={handleCancelHud}
                className="flex items-center justify-center w-8 h-8 bg-slate-900 border border-slate-800 hover:border-rose-500/30 hover:text-rose-400 text-slate-400 hover:bg-rose-950/20 rounded-xl cursor-pointer duration-150 transform active:scale-95 shadow-lg"
                title="Sair sem salvar"
              >
                <X className="w-4 h-4" />
              </button>
              <button
                onClick={handleSaveHud}
                className="flex items-center gap-1.5 px-4 py-1.5 bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-black hover:from-emerald-450 hover:to-teal-450 rounded-xl text-[10px] uppercase tracking-wider cursor-pointer shadow-lg shadow-emerald-500/15 duration-150 transform active:scale-95"
              >
                <Save className="w-3.5 h-3.5" />
                Salvar Layout
              </button>
            </div>
          </div>

          {/* Draggable HUD Buttons layer */}
          <div className="w-full flex-1 relative pointer-events-none select-none">
            {hudButtons.map((btn) => {
              const isDragging = activeDragId === btn.id;
              
              return (
                <div
                  key={btn.id}
                  className="absolute flex flex-col items-center select-none"
                  style={{
                    left: `${btn.x}%`,
                    top: `${btn.y}%`,
                    transform: 'translate(-50%, -50%)',
                    zIndex: isDragging ? 55 : 35
                  }}
                >
                  {/* Outer Drag bounding frame */}
                  <div
                    onPointerDown={(e) => handlePointerDown(btn.id, e)}
                    onPointerMove={(e) => handlePointerMove(btn.id, e)}
                    onPointerUp={(e) => handlePointerUp(btn.id, e)}
                    className={`cursor-move select-none p-3.5 rounded-3xl border-2 border-dashed ${
                      isDragging 
                        ? 'border-emerald-400 bg-emerald-950/40 shadow-[0_0_15px_rgba(52,211,153,0.3)] scale-105' 
                        : 'border-sky-450/70 bg-sky-950/20 hover:border-sky-400 hover:bg-sky-900/10'
                    } transition-all duration-100 flex flex-col items-center pointer-events-auto touch-none shadow-2xl`}
                    style={{
                      transform: `scale(${btn.scale})`,
                      opacity: btn.opacity !== undefined ? btn.opacity : 1.0,
                    }}
                  >
                    {btn.id === 'swordBar' ? (
                      <div className="bg-slate-950/95 border border-slate-900/80 px-4 py-2.5 rounded-xl w-48 flex flex-col gap-1.5 shadow-xl select-none pointer-events-none">
                        <div className="flex justify-between items-center text-[8.5px] uppercase font-black tracking-widest text-amber-500">
                          <span className="flex items-center gap-0.5 font-bold">
                            <Flame className="w-3 h-3 text-amber-400 fill-amber-500" />
                            Cargas de Espada
                          </span>
                          <span className="font-mono text-amber-400">3/5</span>
                        </div>
                        <div className="w-full bg-slate-950 border border-slate-900 rounded-md overflow-hidden h-2.5 flex gap-[2px] p-[1.5px]">
                          {[1, 2, 3].map((s) => (
                            <div key={s} className="flex-1 bg-gradient-to-t from-amber-600 to-yellow-400 rounded-xs" />
                          ))}
                          {[4, 5].map((s) => (
                            <div key={s} className="flex-1 bg-slate-900 rounded-xs" />
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center select-none pointer-events-none">
                        <div className={
                          btn.id === 'left' || btn.id === 'right' ? 
                          "w-14 h-14 rounded-full bg-slate-900 border-2 border-slate-750 flex items-center justify-center text-slate-100" :
                          btn.id === 'thrust' ?
                          "w-14 h-14 rounded-full bg-slate-950 border-2 border-[#1faefc]/40 flex items-center justify-center text-[#1faefc]" :
                          btn.id === 'heavy' ?
                          "w-14 h-14 rounded-full bg-slate-950 border-2 border-amber-500/40 flex items-center justify-center text-amber-400" :
                          btn.id === 'normal' ?
                          "w-14 h-14 rounded-full bg-slate-950 border-2 border-emerald-500/40 flex items-center justify-center text-emerald-400" :
                          btn.id === 'net' ?
                          "w-14 h-14 rounded-full bg-slate-950 border-2 border-indigo-500/40 flex items-center justify-center text-indigo-400" :
                          "w-14 h-14 rounded-full bg-slate-950 border-2 border-slate-400/40 flex items-center justify-center text-slate-100"
                        }>
                          {renderBtnIcon(btn.icon)}
                        </div>
                        <span className={`text-[8.5px] font-black tracking-wider uppercase text-center w-20 leading-none mt-1.5 ${
                          btn.id === 'thrust' ? 'text-[#1faefc]' :
                          btn.id === 'heavy' ? 'text-amber-500' :
                          btn.id === 'normal' ? 'text-emerald-400' :
                          btn.id === 'net' ? 'text-indigo-400' :
                          btn.id === 'left' || btn.id === 'right' ? 'text-slate-400' : 'text-slate-300'
                        }`}>
                          {btn.id === 'left' ? 'ESQUERDA' : btn.id === 'right' ? 'DIREITA' : btn.label}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Size & Opacity Controls panel */}
                  <div className="mt-2 flex flex-col gap-1.5 bg-slate-950 border border-slate-850 rounded-xl p-2 shadow-2xl pointer-events-auto min-w-[124px]">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[7.5px] font-black font-sans uppercase tracking-wider text-slate-400">TAM.</span>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => adjustScale(btn.id, -0.1)}
                          className="w-4.5 h-4.5 flex items-center justify-center bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 rounded-md text-[10px] font-black text-slate-300 hover:text-white cursor-pointer active:scale-90 transition"
                        >
                          -
                        </button>
                        <span className="text-[9px] font-mono font-extrabold text-sky-400 w-9 text-center leading-none">{Math.round(btn.scale * 100)}%</span>
                        <button
                          onClick={() => adjustScale(btn.id, 0.1)}
                          className="w-4.5 h-4.5 flex items-center justify-center bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 rounded-md text-[10px] font-black text-slate-300 hover:text-white cursor-pointer active:scale-90 transition"
                        >
                          +
                        </button>
                      </div>
                    </div>
                    <div className="flex items-center justify-between gap-2 border-t border-slate-900/60 pt-1.5">
                      <span className="text-[7.5px] font-black font-sans uppercase tracking-wider text-slate-400">OPAC.</span>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => adjustOpacity(btn.id, -0.1)}
                          className="w-4.5 h-4.5 flex items-center justify-center bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 rounded-md text-[10px] font-black text-slate-300 hover:text-white cursor-pointer active:scale-90 transition"
                        >
                          -
                        </button>
                        <span className="text-[9px] font-mono font-extrabold text-emerald-400 w-9 text-center leading-none">{Math.round((btn.opacity !== undefined ? btn.opacity : 1.0) * 100)}%</span>
                        <button
                          onClick={() => adjustOpacity(btn.id, 0.1)}
                          className="w-4.5 h-4.5 flex items-center justify-center bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 rounded-md text-[10px] font-black text-slate-300 hover:text-white cursor-pointer active:scale-90 transition"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
