/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { Play, Compass, Trophy, HelpCircle, Save, FolderOpen, Trash2, Shield, Settings, Volume2, VolumeX, X, User, Lock, BookOpen } from 'lucide-react';
import { audio } from '../audio';

interface TitleScreenProps {
  difficulty: 'easy' | 'normal' | 'hard' | 'impossible';
  onSetDifficulty: (diff: 'easy' | 'normal' | 'hard' | 'impossible') => void;
  onStartGame: () => void;
  onOpenLevels: () => void;
  onOpenTrophies: () => void;
  onOpenControls: () => void;
  onOpenProfile: () => void;
  onSave: () => void;
  onLoad: () => boolean;
  onDeleteSave: () => void;
  saveStatus: string;
  isGameCompleted: boolean;
  onOpenManual?: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  difficulty,
  onSetDifficulty,
  onStartGame,
  onOpenLevels,
  onOpenTrophies,
  onOpenControls,
  onOpenProfile,
  onSave,
  onLoad,
  onDeleteSave,
  saveStatus,
  isGameCompleted,
  onOpenManual
}) => {
  const [muted, setMuted] = useState<boolean>(false);
  const [showControlsModal, setShowControlsModal] = useState<boolean>(false);
  const [lockedClickedMsg, setLockedClickedMsg] = useState<string>('');

  useEffect(() => {
    // Sync with initial audio state
    setMuted(audio.getMuted());
  }, []);

  const handleMuteBtn = () => {
    const nextState = audio.toggleMute();
    setMuted(nextState);
  };

  return (
    <div className="absolute inset-0 z-30 flex flex-col justify-center items-center bg-radial-gradient(ellipse at 30% 50%, #17153b 0%, #0a0a1a 60%, #030308 100%) p-6 text-center select-none" id="titleScreen">
      {/* Animated Floating Starfield in CSS background */}
      <div className="absolute inset-0 pointer-events-none opacity-40 overflow-hidden" id="titleStars">
        {Array.from({ length: 40 }).map((_, i) => (
          <div
            key={i}
            className="absolute bg-white rounded-full animate-pulse"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              width: `${Math.random() * 2 + 1}px`,
              height: `${Math.random() * 2 + 1}px`,
              animationDuration: `${Math.random() * 3 + 2}s`,
              animationDelay: `${Math.random() * 2}s`,
              opacity: Math.random() * 0.7 + 0.3
            }}
          />
        ))}
      </div>

      {/* Brand logo */}
      <div className="relative z-10 mb-2">
        <h1 className="text-5xl md:text-6xl font-black font-sans tracking-widest text-[#a2e9c1] transition-all filter drop-shadow-[0_0_20px_rgba(100,240,150,0.45)] hover:scale-101 duration-300">
          GUARDIÃO DE LUMEN
        </h1>
        <div className="text-[10px] md:text-sm tracking-[0.4em] font-sans text-emerald-400 font-bold mt-2 uppercase">
          Ação & Furtividade em Defesa da Floresta
        </div>
      </div>

      {/* Difficulty Selection */}
      <div className="relative z-10 mt-6 flex flex-col items-center">
        <span className="text-[10px] tracking-widest font-mono text-slate-500 font-extrabold uppercase mb-2 mr-1">
          Patrulha de Fiscalização:
        </span>
        <div className="flex flex-wrap gap-2 justify-center mb-4" id="diffContainer">
          {[
            { id: 'easy', label: 'Voluntário', col: 'border-emerald-500/30 text-emerald-400 bg-emerald-500/5 hover:bg-emerald-500/10' },
            { id: 'normal', label: 'Agente', col: 'border-sky-500/30 text-sky-400 bg-sky-500/5 hover:bg-sky-500/10' },
            { id: 'hard', label: 'Fiscal Líder', col: 'border-amber-500/30 text-amber-400 bg-amber-500/5 hover:bg-amber-500/10' },
            { id: 'impossible', label: 'Sobrenatural', col: 'border-rose-500/30 text-rose-400 bg-rose-500/5 hover:bg-rose-500/10', locked: !isGameCompleted }
          ].map(d => {
            const isSel = d.id === difficulty;
            const isLocked = d.locked;
            return (
              <button
                key={d.id}
                onClick={() => {
                  if (isLocked) {
                    audio.playSFX('hit');
                    setLockedClickedMsg('Dificuldade Sobrenatural bloqueada! Conclua o jogo para liberar.');
                    setTimeout(() => setLockedClickedMsg(''), 4000);
                    return;
                  }
                  onSetDifficulty(d.id as any);
                }}
                className={`px-4 py-2 text-xs font-bold font-mono border rounded-lg cursor-pointer transition flex items-center justify-center gap-1 ${
                  isLocked 
                    ? 'border-slate-800 text-slate-500 bg-slate-950/40 cursor-not-allowed opacity-60 hover:bg-rose-950/5 hover:border-rose-950/20' 
                    : d.col
                } ${
                  isSel && !isLocked ? 'ring-2 ring-opacity-80 ring-emerald-400 border-emerald-400 scale-103 shadow-md bg-opacity-15' : 'opacity-80'
                }`}
                title={isLocked ? "Bloqueado: Termine os 100 níveis do jogo para liberar" : undefined}
              >
                {isLocked && <Lock className="w-3.5 h-3.5 text-rose-500/80 mr-0.5 inline-block" />}
                {d.label}
              </button>
            );
          })}
        </div>
        {lockedClickedMsg && (
          <div className="text-[10px] text-rose-400 font-mono tracking-wide mb-4 animate-bounce" id="lockMessage">
            {lockedClickedMsg}
          </div>
        )}
      </div>



      {/* Main launch triggers */}
      <div className="relative z-10 flex flex-col gap-2 w-full max-w-xs mb-8">
        <button
          onClick={onStartGame}
          className="flex items-center justify-center gap-3 py-3 rounded-xl bg-sky-500 text-slate-950 font-black text-sm tracking-widest shadow-lg shadow-sky-500/15 cursor-pointer hover:scale-103 duration-150 active:scale-98 animate-pulse"
          id="btnStart"
        >
          <Play className="w-4 h-4 fill-slate-950" />
          INICIAR JORNADA
        </button>

        <button
          onClick={onOpenProfile}
          className="flex items-center justify-center gap-3 py-2.5 rounded-xl bg-gradient-to-r from-emerald-950/50 to-indigo-950/50 hover:from-emerald-900/60 hover:to-indigo-900/60 border border-emerald-500/30 hover:border-emerald-400 text-emerald-400 hover:text-white font-bold text-xs tracking-wider transition cursor-pointer hover:scale-102 duration-150"
          id="btnProfile"
        >
          <User className="w-4 h-4 text-emerald-400" />
          EQUIPAMENTO & FISCAL DO PARQUE
        </button>

        <button
          onClick={onOpenLevels}
          className="flex items-center justify-center gap-3 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-850 hover:border-slate-750 text-slate-300 hover:text-white font-bold text-xs tracking-wider transition cursor-pointer hover:scale-102 duration-150"
          id="btnLevels"
        >
          <Compass className="w-4 h-4" />
          PATRULHAR SETOR (FASES)
        </button>

        <div className="flex gap-2">
          <button
            onClick={onOpenTrophies}
            className="flex-1 flex items-center justify-center gap-2 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-850 hover:border-slate-750 text-slate-300 hover:text-white font-bold text-[11px] tracking-wider transition cursor-pointer"
            id="btnTrophy"
          >
            <Trophy className="w-3.5 h-3.5 text-emerald-400" />
            CONQUISTAS
          </button>

          <button
            onClick={() => setShowControlsModal(true)}
            className="flex-1 flex items-center justify-center gap-2 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-850 hover:border-slate-750 text-slate-300 hover:text-white font-bold text-[11px] tracking-wider transition cursor-pointer"
            id="btnCtrl"
          >
            <HelpCircle className="w-3.5 h-3.5 text-emerald-400" />
            EQUIPAMENTOS
          </button>
        </div>
      </div>

      {/* Volume mute controller */}
      <button
        onClick={handleMuteBtn}
        className="absolute bottom-6 left-6 p-3 bg-slate-900/60 border border-slate-850 rounded-xl text-slate-400 hover:text-white hover:border-slate-755 hover:scale-105 active:scale-95 transition cursor-pointer"
      >
        {muted ? <VolumeX className="w-5 h-5 text-rose-400" /> : <Volume2 className="w-5 h-5 text-emerald-400" />}
      </button>

      {/* Basic Controls Modal overlay */}
      {showControlsModal && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl flex flex-col max-h-[90%] overflow-y-auto">
            {/* Header */}
            <div className="flex justify-between items-center mb-4 border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-emerald-400 animate-pulse" />
                <h2 className="text-base font-black font-sans text-slate-200 tracking-wider">EQUIPAMENTOS DO FISCAL</h2>
              </div>
              <button
                onClick={() => setShowControlsModal(false)}
                className="p-1 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* List of Controls split in elegant grid/rows */}
            <div className="space-y-4 text-left font-sans">
              
              {/* Category: Movimentação */}
              <div>
                <h3 className="text-[11px] font-black text-emerald-400 uppercase tracking-widest mb-2 border-l-2 border-emerald-500 pl-2">Vigilância e Trilhas</h3>
                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <div className="flex items-center gap-2 bg-slate-950/40 p-2 rounded-lg border border-slate-850">
                    <span className="bg-slate-800 text-slate-200 px-1.5 py-0.5 rounded border border-slate-700 text-[10px] uppercase">A / D</span>
                    <span className="text-slate-400 font-sans">ou</span>
                    <span className="bg-slate-800 text-slate-200 px-1.5 py-0.5 rounded border border-slate-700 text-[10px]">← / →</span>
                    <span className="text-slate-300 ml-auto font-sans">Mover-se</span>
                  </div>
                  <div className="flex items-center gap-2 bg-slate-950/40 p-2 rounded-lg border border-slate-850">
                    <span className="bg-slate-800 text-slate-200 px-1.5 py-0.5 rounded border border-slate-700 text-[10px] uppercase">W</span>
                    <span className="text-slate-400 font-sans">ou</span>
                    <span className="bg-slate-800 text-slate-200 px-1.5 py-0.5 rounded border border-slate-700 text-[10px]">↑</span>
                    <span className="text-slate-300 ml-auto font-sans">Salto Duplo</span>
                  </div>
                </div>
              </div>

              {/* Category: Combate de Espada */}
              <div>
                <h3 className="text-[11px] font-black text-amber-400 uppercase tracking-widest mb-2 border-l-2 border-amber-500 pl-2">Bastão Tático Neutralizador</h3>
                <div className="space-y-1.5 text-xs">
                  <div className="flex items-center justify-between bg-slate-950/40 p-2 rounded-lg border border-slate-850">
                    <div className="flex items-center gap-2">
                      <span className="bg-amber-950/30 text-amber-400 font-mono px-2 py-0.5 rounded border border-amber-500/35 text-[10px] font-bold uppercase">Z</span>
                      <span className="text-slate-300 font-semibold font-sans">Ataque Rápido / Bastão</span>
                    </div>
                    <span className="text-slate-500 font-mono text-[9px]">(Z-Z-Z Sequência de Imobilização)</span>
                  </div>

                  <div className="flex items-center justify-between bg-slate-950/40 p-2 rounded-lg border border-slate-850">
                    <div className="flex items-center gap-2">
                      <span className="bg-sky-950/30 text-sky-400 font-mono px-2 py-0.5 rounded border border-sky-500/35 text-[10px] font-bold uppercase">C</span>
                      <span className="text-slate-300 font-semibold font-sans">Impulso Tático das Botas</span>
                    </div>
                    <span className="text-sky-400 font-mono text-[9px]">(Corrida rápida que desestabiliza)</span>
                  </div>

                  <div className="flex items-center justify-between bg-slate-950/40 p-2 rounded-lg border border-slate-850">
                    <div className="flex items-center gap-2">
                      <span className="bg-yellow-950/30 text-yellow-400 font-mono px-2 py-0.5 rounded border border-yellow-500/35 text-[10px] font-bold uppercase">V</span>
                      <span className="text-slate-300 font-semibold font-sans">Rede de Retenção do Drone</span>
                    </div>
                    <span className="text-amber-500 font-mono text-[9px] font-bold">(Libera após prender 5 criminosos)</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 mt-1">
                    <div className="flex items-center justify-between bg-slate-950/40 p-2 rounded-lg border border-slate-850">
                      <div className="flex items-center gap-1 font-mono">
                        <span className="bg-slate-800 text-slate-200 px-1 py-0.5 rounded text-[9px]">↓</span>
                        <span className="text-slate-400 font-sans">+</span>
                        <span className="bg-slate-800 text-slate-200 px-1 py-0.5 rounded text-[9px] uppercase">Z</span>
                      </div>
                      <span className="text-slate-400 text-[10px] font-sans">Bastão Descendente</span>
                    </div>
                    <div className="flex items-center justify-between bg-slate-950/40 p-2 rounded-lg border border-slate-850">
                      <div className="flex items-center gap-1 font-mono">
                        <span className="bg-slate-800 text-slate-200 px-1 py-0.5 rounded text-[9px]">↑</span>
                        <span className="text-slate-400 font-sans">+</span>
                        <span className="bg-slate-800 text-slate-200 px-1 py-0.5 rounded text-[9px] uppercase">Z</span>
                      </div>
                      <span className="text-slate-400 text-[10px] font-sans">Lanterna Ofuscante</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Category: Magia & Sintonização */}
              <div>
                <h3 className="text-[11px] font-black text-purple-400 uppercase tracking-widest mb-2 border-l-2 border-purple-500 pl-2">Sinalizadores e Drones</h3>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="flex items-center justify-between bg-slate-950/40 p-2 rounded-lg border border-slate-850">
                    <div className="flex items-center gap-1.5 font-mono">
                      <span className="bg-slate-800 text-slate-200 px-1.5 py-0.5 rounded text-[10px] uppercase">F</span>
                      <span className="text-slate-300 font-sans">Escudo Defletor</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between bg-slate-950/40 p-2 rounded-lg border border-slate-850">
                    <div className="flex items-center gap-1.5 font-mono">
                      <span className="bg-slate-800 text-slate-200 px-1.5 py-0.5 rounded text-[10px] uppercase">X</span>
                      <span className="text-slate-300 font-sans">Dardo Tranquilizante</span>
                    </div>
                  </div>
                </div>
              </div>

            </div>

            {/* Footer close button option */}
            <div className="mt-5 pt-3 border-t border-slate-800 flex flex-col sm:flex-row gap-2 justify-center items-center">
              {onOpenManual && (
                <button
                  onClick={() => {
                    audio.playSFX('crystal');
                    setShowControlsModal(false);
                    onOpenManual();
                  }}
                  className="w-full sm:w-auto px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase tracking-widest rounded-xl transition cursor-pointer active:scale-95 duration-100 flex items-center justify-center gap-1.5"
                >
                  <BookOpen className="w-3.5 h-3.5 fill-slate-950" />
                  Abrir Manual do Jogo
                </button>
              )}
              <button
                onClick={() => setShowControlsModal(false)}
                className="w-full sm:w-auto px-6 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-black text-xs uppercase tracking-widest rounded-xl transition cursor-pointer active:scale-95 duration-100"
              >
                Voltar ao Menu
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
