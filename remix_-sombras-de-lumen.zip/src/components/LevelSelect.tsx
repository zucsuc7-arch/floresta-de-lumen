/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Compass, Sparkles, CheckCircle2, Lock, ArrowLeft } from 'lucide-react';
import { Region } from '../types';

interface LevelSelectProps {
  unlockedLevels: boolean[];
  completedLevels: boolean[];
  onSelectLevel: (levelIdx: number) => void;
  onBack: () => void;
  regions: Region[];
  levelNames: string[];
}

export const LevelSelect: React.FC<LevelSelectProps> = ({
  unlockedLevels,
  completedLevels,
  onSelectLevel,
  onBack,
  regions,
  levelNames
}) => {
  const [activeReg, setActiveReg] = useState<number>(0);

  const region = regions[activeReg];
  const startLvl = region.range[0];
  const endLvl = region.range[1];

  // Helper to count progress in each region
  const getRegionProgress = (reg: Region) => {
    let completed = 0;
    const [start, end] = reg.range;
    for (let i = start; i < end; i++) {
      if (completedLevels[i]) completed++;
    }
    const total = end - start;
    return { completed, total };
  };

  return (
    <div className="absolute inset-0 z-40 flex flex-col bg-slate-950/98 backdrop-blur-lg p-6 overflow-y-auto font-sans select-none" id="levelSelectScreen">
      
      {/* Inline styles for beautiful presentation and clean scrollbars */}
      <style>{`
        #levelSelectScreen::-webkit-scrollbar {
          width: 6px;
        }
        #levelSelectScreen::-webkit-scrollbar-track {
          background: rgba(15, 23, 42, 0.3);
        }
        #levelSelectScreen::-webkit-scrollbar-thumb {
          background: rgba(148, 163, 184, 0.15);
          border-radius: 9999px;
        }
        #levelSelectScreen::-webkit-scrollbar-thumb:hover {
          background: rgba(148, 163, 184, 0.3);
        }

        .lgrid::-webkit-scrollbar {
          width: 5px;
        }
        .lgrid::-webkit-scrollbar-track {
          background: rgba(15, 23, 42, 0.4);
          border-radius: 9999px;
        }
        .lgrid::-webkit-scrollbar-thumb {
          background: rgba(56, 189, 248, 0.2);
          border-radius: 9999px;
        }
        .lgrid::-webkit-scrollbar-thumb:hover {
          background: rgba(56, 189, 248, 0.4);
        }

        /* Hide horizontal scrollbar for tabs tab */
        .rtabs::-webkit-scrollbar {
          display: none;
        }
        .rtabs {
          -ms-overflow-style: none;  /* IE and Edge */
          scrollbar-width: none;  /* Firefox */
        }
      `}</style>

      {/* Header section */}
      <div className="w-full max-w-5xl mx-auto flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-900 pb-4 mb-6 gap-4 flex-shrink-0">
        <div>
          <h2 className="text-2xl md:text-3xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-sky-450 to-indigo-400 flex items-center gap-2.5">
            <Compass className="w-7 h-7 text-sky-400 animate-spin-slow" />
            MAPA DAS CRÔNICAS
          </h2>
          <p className="text-slate-500 text-xs md:text-sm font-semibold mt-1 uppercase tracking-wider">
            Escolha um território espiritual para reconquistar o Trono de Lumen.
          </p>
        </div>
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-5 py-2.5 bg-slate-900/80 hover:bg-slate-800 border border-slate-850 hover:border-slate-700 rounded-xl text-slate-300 hover:text-white transition duration-200 cursor-pointer text-xs font-black uppercase tracking-wider shadow-lg shadow-black/20"
          id="btnBack1"
        >
          <ArrowLeft className="w-4 h-4" />
          Voltar
        </button>
      </div>

      {/* Tabs list (styled elegantly in a horizontal strip) */}
      <div className="w-full max-w-5xl mx-auto flex gap-2.5 overflow-x-auto pb-2.5 mb-6 rtabs flex-shrink-0">
        {regions.map((reg, idx) => {
          const isActive = idx === activeReg;
          const { completed, total } = getRegionProgress(reg);

          return (
            <button
              key={reg.id}
              onClick={() => setActiveReg(idx)}
              className={`flex flex-col gap-1.5 px-4.5 py-3 rounded-2xl cursor-pointer text-left transition-all duration-200 border min-w-[140px] md:min-w-[170px] ${
                isActive
                  ? 'bg-sky-500/10 text-sky-300 border-sky-500/30 shadow-lg shadow-sky-500/5'
                  : 'bg-slate-900/30 text-slate-500 border-slate-900/60 hover:border-slate-800 hover:text-slate-350'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className="text-lg">{reg.icon}</span>
                <span className="text-xs font-black tracking-wide truncate uppercase">{reg.name}</span>
              </div>
              <div className="flex justify-between items-center w-full mt-1">
                <span className="text-[10px] font-mono opacity-80 uppercase font-bold">Progresso:</span>
                <span className="text-[10px] font-mono font-black text-sky-400 bg-sky-950/30 px-1.5 py-0.5 rounded">
                  {completed} / {total}
                </span>
              </div>
              {/* Progress visual bar */}
              <div className="w-full bg-slate-950/80 h-1.5 rounded-full overflow-hidden mt-1 border border-slate-900/60 p-[1px]">
                <div 
                  className={`h-full rounded-full transition-all duration-300 ${isActive ? 'bg-sky-400' : 'bg-slate-700'}`}
                  style={{ width: `${(completed / total) * 100}%` }}
                />
              </div>
            </button>
          );
        })}
      </div>

      {/* Grid of Levels */}
      <div className="w-full max-w-5xl mx-auto flex-1 flex flex-col min-h-0">
        <div className="bg-slate-900/15 border border-slate-900/40 rounded-3xl p-5 md:p-6 flex-1 flex flex-col min-h-0 shadow-2xl backdrop-blur-sm">
          
          {/* Active region details status line */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-900 pb-4 mb-5 flex-shrink-0">
            <div className="flex items-center gap-2 text-sky-400 font-mono text-xs tracking-wider uppercase font-black">
              <Sparkles className="w-4 h-4 animate-pulse text-sky-500" />
              REGIONAL: {region.icon} {region.name} ({startLvl + 1} - {endLvl})
            </div>
            
            <div className="text-[10px] text-slate-500 uppercase font-black font-mono tracking-widest bg-slate-950/40 px-3 py-1.5 rounded-lg border border-slate-900/55">
              FASE ATIVA DE PROGRESSO
            </div>
          </div>

          {/* Scrollable grid itself */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 overflow-y-auto pr-1 lgrid flex-1">
            {Array.from({ length: endLvl - startLvl }).map((_, i) => {
              const levelIdx = startLvl + i;
              const isUnlocked = unlockedLevels[levelIdx];
              const isCompleted = completedLevels[levelIdx];
              const name = levelNames[levelIdx];
              const isBoss = (levelIdx + 1) % 10 === 0;

              return (
                <button
                  key={levelIdx}
                  disabled={!isUnlocked}
                  onClick={() => onSelectLevel(levelIdx)}
                  className={`relative flex flex-col justify-between p-4 h-28 rounded-2xl border text-left transition-all duration-300 select-none ${
                    isUnlocked
                      ? isCompleted
                        ? 'bg-emerald-950/5 border-emerald-500/20 hover:border-emerald-400/50 hover:bg-emerald-950/15 cursor-pointer hover:-translate-y-1 hover:shadow-lg hover:shadow-emerald-500/5'
                        : isBoss
                        ? 'bg-rose-950/10 border-rose-500/25 hover:border-rose-450 hover:bg-rose-950/20 cursor-pointer hover:-translate-y-1 hover:shadow-lg hover:shadow-rose-500/5'
                        : 'bg-slate-900/40 border-slate-850 hover:border-sky-500/40 hover:bg-slate-850/60 cursor-pointer hover:-translate-y-1 hover:shadow-lg hover:shadow-sky-500/5'
                      : 'bg-slate-950/30 border-slate-950/60 opacity-30 cursor-not-allowed'
                  }`}
                >
                  <div className="flex justify-between items-start w-full">
                    <span className="text-xs font-black font-mono text-slate-500">
                      FASE {levelIdx + 1}
                    </span>
                    {isCompleted ? (
                      <div className="p-1 bg-emerald-500/10 rounded-lg border border-emerald-500/20">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      </div>
                    ) : isBoss ? (
                      <span className="text-md text-amber-400 animate-bounce">👑</span>
                    ) : !isUnlocked ? (
                      <Lock className="w-3.5 h-3.5 text-slate-600" />
                    ) : null}
                  </div>

                  <div className="mt-3 flex flex-col gap-1 w-full overflow-hidden">
                    <div className={`text-[10.5px] font-extrabold tracking-wide line-clamp-2 leading-tight uppercase ${
                      isUnlocked 
                        ? isCompleted 
                          ? 'text-emerald-300' 
                          : isBoss 
                          ? 'text-rose-400' 
                          : 'text-slate-200' 
                        : 'text-slate-600'
                    }`}>
                      {isUnlocked ? name : 'Sombra Oculta'}
                    </div>
                    {isBoss && isUnlocked && (
                      <span className="text-[7.5px] bg-rose-500/15 text-rose-400 border border-rose-500/25 px-1.5 py-0.5 rounded font-black mt-1.5 uppercase tracking-widest inline-block text-center w-full">
                        BOSS DE REGIONAL
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
