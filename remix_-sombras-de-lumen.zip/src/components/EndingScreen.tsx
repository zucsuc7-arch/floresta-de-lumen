/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Home, Compass, Radio, LogOut } from 'lucide-react';

interface EndingScreenProps {
  endingType: 'light' | 'dark' | 'transcend';
  onBackToMenu: () => void;
}

export const EndingScreen: React.FC<EndingScreenProps> = ({ endingType, onBackToMenu }) => {
  const getEndingDetails = () => {
    switch (endingType) {
      case 'light':
        return {
          title: 'PRESERVAÇÃO INTEGRAL DE LUMEN',
          subtitle: 'Guardião Absoluto da Reserva',
          description:
            'Com os criminosos ambientais detidos e as mudas plantadas, você derrama toda a sua dedicação ecológica sobre a Parque Nacional de Lumen. O ecossistema volta a florescer de forma majestosa. Araras voam livres e os rios brilham cristalinos: a natureza está totalmente preservada sob a custódia do reflorestamento eterno.',
          colorClass: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
          bgStyle: 'bg-radial-gradient(ellipse at center, rgba(10,30,15,0.95) 0%, rgba(5,10,5,1) 100%)',
          emblem: '🌳'
        };
      case 'dark':
        return {
          title: 'SISTEMA DE FISCALIZAÇÃO ATIVA',
          subtitle: 'Diretor de Manejo Sustentável',
          description:
            'Reconhecendo que a floresta precisa de vigilância e manejo rigorosos, você implanta uma rede tecnológica de fronteiras. Com inteligência de monitoramento, equipe de vigilância dedicada e drones avançados, você dita as leis de sustentabilidade pragmática na floresta de Lumen, coibindo novos delitos sem hesitação.',
          colorClass: 'text-sky-400 bg-sky-500/10 border-sky-500/30',
          bgStyle: 'bg-radial-gradient(ellipse at center, rgba(10,20,30,0.95) 0%, rgba(5,5,10,1) 100%)',
          emblem: '🛸'
        };
      case 'transcend':
      default:
        return {
          title: 'SIMBIOSE COMPLETA COM LUMEN',
          subtitle: 'A Harmonia e Fusão com a Mãe Terra',
          description:
            'Ao recusar tanto o controle burocrático quanto o tecnificado, você se funde fisicamente com a biodiversidade do Parque Nacional de Lumen. Lentamente, sua consciência se derrama pelas raízes e águas limpas. Sua presença passa a habitar cada folha, pingo de orvalho e sussurro da mata. A floresta vive e respira por si só, protegendo-se eternamente como um único organismo consciente.',
          colorClass: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
          bgStyle: 'bg-radial-gradient(ellipse at center, rgba(30,25,10,0.95) 0%, rgba(5,5,10,1) 100%)',
          emblem: '🐆'
        };
    }
  };

  const details = getEndingDetails();

  return (
    <div
      className="absolute inset-0 z-50 flex flex-col justify-center items-center p-8 text-center"
      style={{ background: 'radial-gradient(circle at center, rgb(5, 5, 20) 0%, rgb(1, 1, 4) 100%)' }}
      id="endingScreen"
    >
      <div className="absolute w-full h-full inset-0 pointer-events-none bg-cover opacity-10 mix-blend-color-dodge" />
      <div className="absolute w-96 h-96 rounded-full bg-cyan-500/5 blur-3xl pointer-events-none" />

      <div className="relative w-full max-w-xl bg-slate-900/45 border border-slate-800/80 p-8 rounded-2xl shadow-2xl flex flex-col items-center">
        {/* Emblem */}
        <span className="text-5xl mb-6 block animate-pulse">{details.emblem}</span>

        {/* Ending Specific Badge */}
        <div className={`px-4 py-1.5 rounded-full border ${details.colorClass} text-[10px] font-mono tracking-widest font-extrabold uppercase mb-4`}>
          {details.subtitle}
        </div>

        {/* Narrative Headings */}
        <h2 className="text-2xl font-black font-sans tracking-widest text-slate-100 mb-6 uppercase" id="endingTitle">
          {details.title}
        </h2>

        {/* Epilogue description */}
        <p className="text-slate-300 text-sm leading-relaxed mb-8 text-justify font-sans" id="endingText">
          {details.description}
        </p>

        {/* Bottom actions */}
        <button
          onClick={onBackToMenu}
          className="flex items-center gap-2 px-8 py-3 bg-slate-900 border border-slate-800 hover:bg-slate-800 hover:border-slate-700 text-slate-350 hover:text-white rounded-xl shadow-md transition duration-200 cursor-pointer"
          id="btnBack2"
        >
          <Home className="w-4 h-4" />
          <span>Retornar ao Menu Principal</span>
        </button>
      </div>
    </div>
  );
};
