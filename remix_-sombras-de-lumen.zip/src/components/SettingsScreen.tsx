/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Settings, Volume2, VolumeX, Save, Trash2, ArrowLeft, ShieldAlert, Sparkles, HelpCircle, Sliders } from 'lucide-react';
import { audio } from '../audio';

interface SettingsScreenProps {
  onClose: () => void;
  onSave: () => void;
  onDeleteSave: () => void;
  saveStatus: string;
  onEditHud: () => void;
  prevGameState?: string;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  onClose,
  onSave,
  onDeleteSave,
  saveStatus,
  onEditHud,
  prevGameState,
}) => {
  const [volume, setVolume] = useState<number>(0.5);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  useEffect(() => {
    // Sync React state with AudioManager initial parameters
    setVolume(audio.getVolume());
    setIsMuted(audio.getMuted());
  }, []);

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    audio.setVolume(val);
    if (val > 0 && isMuted) {
      audio.setMute(false);
      setIsMuted(false);
    }
  };

  const handleToggleMute = (e?: React.MouseEvent | React.TouchEvent) => {
    if (e) {
      if (e.cancelable) e.preventDefault();
      e.stopPropagation();
    }
    const nextMute = !isMuted;
    audio.setMute(nextMute);
    setIsMuted(nextMute);
    audio.playSFX('crystal');
  };

  const executeSave = (e?: React.MouseEvent | React.TouchEvent) => {
    if (e) {
      if (e.cancelable) e.preventDefault();
      e.stopPropagation();
    }
    onSave();
  };

  const executeDelete = (e?: React.MouseEvent | React.TouchEvent) => {
    if (e) {
      if (e.cancelable) e.preventDefault();
      e.stopPropagation();
    }
    onDeleteSave();
  };

  const handleClose = (e?: React.MouseEvent | React.TouchEvent) => {
    if (e) {
      if (e.cancelable) e.preventDefault();
      e.stopPropagation();
    }
    onClose();
  };

  const handleEditHudClick = (e?: React.MouseEvent | React.TouchEvent) => {
    if (e) {
      if (e.cancelable) e.preventDefault();
      e.stopPropagation();
    }
    onEditHud();
  };

  return (
    <div className="absolute inset-0 z-40 flex flex-col items-center justify-center bg-slate-950/98 backdrop-blur-md p-3 select-none pointer-events-auto" id="settingsScreen">
      {/* Background Starfield details */}
      <div className="absolute inset-0 pointer-events-none opacity-20 overflow-hidden">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute bg-sky-200 rounded-full animate-pulse"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              width: `${Math.random() * 1.5 + 1}px`,
              height: `${Math.random() * 1.5 + 1}px`,
              animationDuration: `${Math.random() * 4 + 2}s`
            }}
          />
        ))}
      </div>

      <div className="w-full max-w-md bg-slate-900/60 border border-slate-800 rounded-2xl p-4 shadow-2xl flex flex-col relative z-10 gap-3 max-h-[96vh] overflow-y-auto backdrop-blur-md pointer-events-auto">
        
        {/* Header Title Grid */}
        <div className="flex items-center gap-2.5 border-b border-slate-800/60 pb-2.5">
          <div className="p-1.5 bg-sky-500/10 rounded-lg border border-sky-500/20">
            <Settings className="w-4.5 h-4.5 text-sky-400 animate-spin-slow" />
          </div>
          <div>
            <h2 className="text-base font-black tracking-wider text-slate-100 uppercase font-sans">
              Configurações da Jornada
            </h2>
            <p className="text-[10px] text-slate-400 font-mono tracking-wide">
              Ajustes de Som e Progresso
            </p>
          </div>
        </div>

        {/* Category Panel: Sound Controls */}
        <div className="space-y-1.5 font-sans">
          <div className="flex justify-between items-center">
            <h3 className="text-[11px] font-black text-sky-400 uppercase tracking-widest border-l-2 border-sky-500 pl-2">
              Sintonia Auditiva (Volume)
            </h3>
            <span className="text-[10px] font-mono font-bold text-slate-400 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
              {isMuted ? 'MUTADO' : `${Math.round(volume * 100)}%`}
            </span>
          </div>

          <div className="flex items-center gap-3 bg-slate-950/50 p-2.5 rounded-xl border border-slate-850">
            <button
              onClick={handleToggleMute}
              onTouchEnd={handleToggleMute}
              className="p-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 rounded-lg text-slate-300 hover:text-white transition cursor-pointer"
              title={isMuted ? "Desmutar" : "Mutar"}
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-rose-400 animate-bounce" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
            </button>

            <div className="flex-1 flex flex-col gap-1">
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={isMuted ? 0 : volume}
                onChange={handleVolumeChange}
                className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-400 hover:accent-sky-300 transition"
              />
              <div className="flex justify-between text-[8px] font-mono text-slate-500">
                <span>SILÊNCIO</span>
                <span>MÉDIO</span>
                <span>MÁXIMO</span>
              </div>
            </div>
          </div>
        </div>

        {/* Category Panel: Progress Saves */}
        <div className="space-y-1.5 font-sans">
          <h3 className="text-[11px] font-black text-amber-400 uppercase tracking-widest border-l-2 border-amber-500 pl-2">
            Salvar e Gerenciar Progresso
          </h3>

          <div className="grid grid-cols-2 gap-2.5">
            
            {/* Save Card info */}
            <button
              onClick={executeSave}
              onTouchEnd={executeSave}
              className="group flex flex-col items-center justify-center p-2.5 bg-slate-950/40 border border-emerald-500/20 hover:border-emerald-500/60 rounded-xl transition hover:bg-emerald-950/10 cursor-pointer text-center relative overflow-hidden"
            >
              <div className="p-1.5 bg-emerald-950/30 border border-emerald-500/30 rounded-lg mb-1 text-emerald-400 group-hover:scale-105 duration-200">
                <Save className="w-4 h-4" />
              </div>
              <span className="text-[11px] font-black text-slate-200 uppercase tracking-wider block">
                Salvar Progresso
              </span>
              <span className="text-[8px] text-slate-400 font-mono opacity-80 leading-tight">
                Salva fases e estatísticas
              </span>
            </button>

            {/* Delete Save Card warning */}
            <button
              onClick={executeDelete}
              onTouchEnd={executeDelete}
              className="group flex flex-col items-center justify-center p-2.5 bg-slate-950/40 border border-rose-500/20 hover:border-rose-500/60 rounded-xl transition hover:bg-rose-950/10 cursor-pointer text-center relative overflow-hidden"
            >
              <div className="p-1.5 bg-rose-950/30 border border-rose-500/30 rounded-lg mb-1 text-rose-400 group-hover:scale-105 duration-200">
                <Trash2 className="w-4 h-4" />
              </div>
              <span className="text-[11px] font-black text-slate-200 uppercase tracking-wider block">
                Excluir Save
              </span>
              <span className="text-[8px] text-slate-400 font-mono opacity-80 leading-tight">
                Zera as fases e o herói
              </span>
            </button>

          </div>

          {/* Toast / save status alert */}
          {saveStatus && (
            <div className="bg-slate-950 px-3 py-1.5 border border-slate-800 rounded-lg text-center text-[10px] font-bold text-sky-400 font-mono animate-pulse">
              {saveStatus}
            </div>
          )}
        </div>

        {/* Category Panel: HUD Editor */}
        <div className="space-y-1.5 font-sans border-t border-slate-800/50 pt-2.5">
          <h3 className="text-[11px] font-black text-rose-500 uppercase tracking-widest border-l-2 border-rose-500 pl-2">
            Controles Mobile (HUD)
          </h3>
          <div className="bg-slate-950/50 p-2.5 rounded-xl border border-slate-850 space-y-2">
            <p className="text-[9px] uppercase tracking-widest text-slate-400 font-mono leading-tight">
              Personalize o layout de jogo movendo e regulando o size dos botões.
            </p>
            <button
              onClick={handleEditHudClick}
              onTouchEnd={handleEditHudClick}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-gradient-to-r from-sky-500 to-blue-500 hover:from-sky-450 hover:to-blue-450 text-slate-950 font-extrabold text-xs tracking-wider rounded-xl transition cursor-pointer hover:scale-102 active:scale-98 shadow-md shadow-sky-500/10 uppercase"
            >
              <Sliders className="w-4 h-4 text-slate-950 fill-slate-950" />
              Editar Posições do HUD
            </button>
          </div>
        </div>

        {/* Category Panel: Developers */}
        <div className="space-y-1.5 font-sans border-t border-slate-800/50 pt-2.5">
          <h3 className="text-[11px] font-black text-emerald-400 uppercase tracking-widest border-l-2 border-emerald-500 pl-2">
            Desenvolvedores
          </h3>
          <div className="bg-slate-950/50 p-2.5 rounded-xl border border-slate-850 space-y-1.5">
            <p className="text-[9px] uppercase tracking-widest font-black text-slate-400 font-mono">
              Alunos do 2º e 3º Ano Tec:
            </p>
            <div className="grid grid-cols-2 gap-y-2 gap-x-3">
              <div className="flex flex-col">
                <span className="text-xs font-bold text-slate-100">Pedro Lucas</span>
                <span className="text-[9px] text-emerald-400/90 font-mono font-semibold">@pedr0_o777</span>
                <span className="text-[8px] text-slate-400">Desenvolvedor</span>
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold text-slate-100">Adão Lima</span>
                <span className="text-[9px] text-emerald-400/90 font-mono font-semibold">@adao.777</span>
                <span className="text-[8px] text-slate-400">Design Gráfico</span>
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold text-slate-100">Stheferson Matheus</span>
                <span className="text-[9px] text-emerald-400/90 font-mono font-semibold">@stheferson_m</span>
                <span className="text-[8px] text-slate-400">Artista Gráfico</span>
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold text-slate-100">Luís Felipe</span>
                <span className="text-[9px] text-emerald-400/90 font-mono font-semibold">@luis27_f</span>
                <span className="text-[8px] text-slate-400">Design Gráfico</span>
              </div>
            </div>
          </div>
        </div>

        {/* Category Panel: Orientadores */}
        <div className="space-y-1.5 font-sans border-t border-slate-800/50 pt-2.5">
          <h3 className="text-[11px] font-black text-emerald-400 uppercase tracking-widest border-l-2 border-emerald-500 pl-2">
            Orientadores
          </h3>
          <div className="bg-slate-950/50 p-2.5 rounded-xl border border-slate-850 space-y-1.5">
            <div className="grid grid-cols-2 gap-y-2 gap-x-3">
              <div className="flex flex-col">
                <span className="text-xs font-bold text-slate-100">Augusto Severo</span>
                <span className="text-[9px] text-emerald-400/90 font-mono font-semibold">@guteco</span>
                <span className="text-[8px] text-slate-400">Professor</span>
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold text-slate-100">Julio Cesar</span>
                <span className="text-[8px] text-slate-400 mt-3.5">Professor</span>
              </div>
            </div>
          </div>
        </div>

        {/* Back and Confirm Controls */}
        <div className="pt-2 border-t border-slate-800 flex justify-center">
          <button
            onClick={handleClose}
            onTouchEnd={handleClose}
            className="flex items-center gap-1.5 px-6 py-2 bg-slate-900 border border-slate-800 hover:border-slate-700 hover:bg-slate-800 text-slate-300 hover:text-white font-extrabold text-xs uppercase tracking-widest rounded-xl transition duration-200 cursor-pointer active:scale-95 shadow-md flex-row"
            id="btnCloseSettings"
          >
            <ArrowLeft className="w-3.5 h-3.5 text-sky-400" />
            {prevGameState === 'title' ? 'Voltar ao Menu Principal' : 'Voltar ao Jogo'}
          </button>
        </div>

      </div>
    </div>
  );
};
