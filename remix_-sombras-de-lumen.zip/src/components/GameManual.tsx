/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  X, BookOpen, Shield, HelpCircle, Key, Sparkles, Check, 
  ChevronRight, Compass, Zap, Heart, Award, ArrowRight
} from 'lucide-react';
import { audio } from '../audio';

interface GameManualProps {
  onClose: () => void;
}

export const GameManual: React.FC<GameManualProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'intro' | 'controls' | 'tips'>('intro');
  const [dontShowAgain, setDontShowAgain] = useState<boolean>(false);

  const handleFinish = () => {
    audio.playSFX('heal');
    if (dontShowAgain) {
      localStorage.setItem('lumen_hide_manual_v1', 'true');
    }
    onClose();
  };

  const toggleDontShowAgain = () => {
    audio.playSFX('crystal');
    setDontShowAgain(!dontShowAgain);
  };

  return (
    <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-slate-950/98 backdrop-blur-md p-4 select-none animate-[fadeIn_0.2s_ease-out]" id="gameManualScreen">
      {/* Background Starfield details */}
      <div className="absolute inset-0 pointer-events-none opacity-20 overflow-hidden">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute bg-white rounded-full animate-ping"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              width: `${Math.random() * 3 + 1.5}px`,
              height: `${Math.random() * 3 + 1.5}px`,
              animationDuration: `${Math.random() * 6 + 4}s`,
              animationDelay: `${Math.random() * 3}s`
            }}
          />
        ))}
      </div>

      <div className="w-full max-w-lg bg-slate-900/70 border border-slate-800 rounded-2xl p-4 shadow-2xl flex flex-col relative z-10 gap-3 max-h-[96vh] overflow-y-auto backdrop-blur-md text-slate-100">
        
        {/* Header Title */}
        <div className="flex items-center gap-2.5 border-b border-slate-800/80 pb-3">
          <div className="p-1.5 bg-emerald-500/10 rounded-lg border border-emerald-500/20">
            <BookOpen className="w-5 h-5 text-emerald-400 animate-pulse" />
          </div>
          <div className="flex-1">
            <h2 className="text-base font-black tracking-wider text-[#a2e9c1] uppercase font-sans">
              Manual do Guardião
            </h2>
            <p className="text-[10px] text-slate-400 font-mono tracking-wide">
              Instruções Táticas de Fiscalização e Preservação
            </p>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="flex bg-slate-950/60 p-1 rounded-xl border border-slate-850 gap-1 font-sans text-xs">
          <button
            onClick={() => { audio.playSFX('crystal'); setActiveTab('intro'); }}
            className={`flex-1 py-1.5 px-2 rounded-lg font-bold uppercase tracking-wider transition ${
              activeTab === 'intro'
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            Como Jogar
          </button>
          <button
            onClick={() => { audio.playSFX('crystal'); setActiveTab('controls'); }}
            className={`flex-1 py-1.5 px-2 rounded-lg font-bold uppercase tracking-wider transition ${
              activeTab === 'controls'
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            Equipamentos
          </button>
          <button
            onClick={() => { audio.playSFX('crystal'); setActiveTab('tips'); }}
            className={`flex-1 py-1.5 px-2 rounded-lg font-bold uppercase tracking-wider transition ${
              activeTab === 'tips'
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            Recursos & Dicas
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 min-h-[220px] overflow-y-auto pr-1">
          {activeTab === 'intro' && (
            <div className="space-y-3 font-sans text-xs animate-[fadeIn_0.15s_ease-out]">
              <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-850 space-y-2">
                <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider flex items-center gap-1.5">
                  <Compass className="w-3.5 h-3.5 text-emerald-400" />
                  Sua Missão como Guardião
                </span>
                <p className="text-slate-300 leading-relaxed text-[11.5px]">
                  O <strong>Parque Nacional de Lumen</strong> está sendo devastado por criminosos ambientais. Como Agente de Fiscalização, você deve patrulhar a floresta, neutralizar os invasores e restaurar a biodiversidade selvagem.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="bg-slate-950/40 p-2.5 rounded-xl border border-slate-850 space-y-1">
                  <span className="text-[10px] uppercase font-bold text-amber-400 flex items-center gap-1">
                    🌱 REFLORESTAR
                  </span>
                  <p className="text-[10.5px] text-slate-400 leading-tight">
                    Recolha pacotes de sementes e plante-os nas clareiras férteis do mapa para regenerar o bioma local.
                  </p>
                </div>
                <div className="bg-slate-950/40 p-2.5 rounded-xl border border-slate-850 space-y-1">
                  <span className="text-[10px] uppercase font-bold text-sky-400 flex items-center gap-1">
                    ⛓️ NEUTRALIZAR
                  </span>
                  <p className="text-[10.5px] text-slate-400 leading-tight">
                    Detenha desmatadores e caçadores usando seu bastão tático. Cada prisão aumenta seu Progresso de Preservação.
                  </p>
                </div>
              </div>

              <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-850 space-y-2">
                <span className="text-[10px] uppercase font-bold text-[#b494fc] tracking-wider flex items-center gap-1.5">
                  <Award className="w-3.5 h-3.5 text-purple-400" />
                  Evolução do Agente
                </span>
                <p className="text-slate-400 leading-relaxed text-[10.5px]">
                  Ao patrulhar e deter as infrações, você acumula <strong className="text-white">XP</strong> e sobe de nível. Distribua seus <strong className="text-white">Pontos de Atributo</strong> no perfil (Vigilância, Destreza, Força, Resistência e Força da Rede) para otimizar suas habilidades.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'controls' && (
            <div className="space-y-3 font-sans text-xs animate-[fadeIn_0.15s_ease-out]">
              <div className="space-y-2">
                <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-400 block border-l-2 border-emerald-500 pl-1.5">
                  Movimentação Tática
                </span>
                <div className="grid grid-cols-2 gap-2 font-mono">
                  <div className="flex items-center gap-2 bg-slate-950/40 p-2 rounded-lg border border-slate-850">
                    <span className="bg-slate-800 text-slate-200 px-1.5 py-0.5 rounded border border-slate-700 text-[10px] uppercase">A / D</span>
                    <span className="text-slate-300 ml-auto font-sans">Mover</span>
                  </div>
                  <div className="flex items-center gap-2 bg-slate-950/40 p-2 rounded-lg border border-slate-850">
                    <span className="bg-slate-800 text-slate-200 px-1.5 py-0.5 rounded border border-slate-700 text-[10px]">W</span>
                    <span className="text-slate-300 ml-auto font-sans">Salto Duplo</span>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-[10px] uppercase font-bold tracking-widest text-amber-400 block border-l-2 border-amber-500 pl-1.5">
                  Bastão & Ferramentas do Drone
                </span>
                
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between bg-slate-950/40 p-2 rounded-lg border border-slate-850">
                    <div className="flex items-center gap-2">
                      <span className="bg-amber-950/30 text-amber-400 font-mono px-1.5 py-0.5 rounded border border-amber-500/35 text-[10px] font-bold">Z</span>
                      <span className="text-slate-200 font-bold">Bastão Tático</span>
                    </div>
                    <span className="text-slate-400 text-[10px]">(Golpe rápido imobilizador)</span>
                  </div>

                  <div className="flex items-center justify-between bg-slate-950/40 p-2 rounded-lg border border-slate-850">
                    <div className="flex items-center gap-2">
                      <span className="bg-sky-950/30 text-sky-450 font-mono px-1.5 py-0.5 rounded border border-sky-500/35 text-[10px] font-bold">C</span>
                      <span className="text-slate-200 font-bold">Impulso de Botas</span>
                    </div>
                    <span className="text-slate-400 text-[10px]">(Avanço rápido que desestabiliza)</span>
                  </div>

                  <div className="flex items-center justify-between bg-slate-950/40 p-2 rounded-lg border border-slate-850">
                    <div className="flex items-center gap-2">
                      <span className="bg-purple-950/30 text-[#b494fc] font-mono px-1.5 py-0.5 rounded border-purple-500/35 text-[10px] font-bold">V</span>
                      <span className="text-slate-200 font-bold">Rede de Retenção</span>
                    </div>
                    <span className="text-slate-400 text-[10px]">(Derruba vários rivais ao mesmo tempo)</span>
                  </div>

                  <div className="flex items-center justify-between bg-slate-950/40 p-2 rounded-lg border border-slate-850">
                    <div className="flex items-center gap-2">
                      <span className="bg-indigo-950/30 text-indigo-400 font-mono px-1.5 py-0.5 rounded border border-indigo-500/35 text-[10px] font-bold">F</span>
                      <span className="text-slate-200 font-bold">Barreira Tática</span>
                    </div>
                    <span className="text-slate-450 text-[10px]">(Invencível por 5s - Requer Energia)</span>
                  </div>

                  <div className="flex items-center justify-between bg-slate-950/40 p-2 rounded-lg border border-slate-850">
                    <div className="flex items-center gap-2">
                      <span className="bg-emerald-950/30 text-emerald-400 font-mono px-1.5 py-0.5 rounded border border-emerald-500/35 text-[10px] font-bold">X</span>
                      <span className="text-slate-200 font-bold">Dardo Tranquilizante</span>
                    </div>
                    <span className="text-slate-400 text-[10px]">(Nocauteia inimigo à distância)</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'tips' && (
            <div className="space-y-3 font-sans text-xs animate-[fadeIn_0.15s_ease-out]">
              <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-850 space-y-2.5">
                <div className="flex items-center gap-2 border-b border-slate-800 pb-1.5">
                  <Shield className="w-4 h-4 text-emerald-400" />
                  <span className="text-[10px] uppercase font-bold tracking-wider text-slate-200">Sobrevivência na Patrulha</span>
                </div>
                
                <div className="space-y-2 text-[11px] leading-relaxed">
                  <div className="flex gap-2">
                    <Heart className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                    <p className="text-slate-300">
                      <strong className="text-slate-100">Preserve sua Vitalidade (HP):</strong> Se o HP zerar, você ficará exausto e precisará reiniciar a fase. Encontre sementes ou caixas de primeiros socorros no chão.
                    </p>
                  </div>

                  <div className="flex gap-2">
                    <Zap className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                    <p className="text-slate-300">
                      <strong className="text-slate-100">Força da Rede (Bateria):</strong> Use suas ferramentas com sabedoria! Habilidades como dardo [X] ou barreira [F] drenam este medidor. Ele recarrega lentamente ao longo do tempo.
                    </p>
                  </div>

                  <div className="flex gap-2">
                    <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <p className="text-slate-300">
                      <strong className="text-slate-100">Salvar Progresso Permanente:</strong> O progresso das fases é assegurado automaticamente nas mudanças de fase, mas lembre-se que você também pode salvar manualmente pelo menu de engrenagem no topo direito do jogo!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Action Bottom Controls */}
        <div className="pt-2 border-t border-slate-800 flex flex-col gap-2.5">
          {/* Prevent repetition toggle */}
          <button
            onClick={toggleDontShowAgain}
            className="flex items-center justify-center gap-2 py-1.5 px-3 bg-slate-950/60 hover:bg-slate-950 border border-slate-850 hover:border-slate-800 rounded-xl transition cursor-pointer select-none text-[11px] text-slate-300"
          >
            <div className={`w-4 h-4 rounded flex items-center justify-center border transition ${
              dontShowAgain 
                ? 'bg-emerald-500 border-emerald-400 text-slate-950' 
                : 'border-slate-700 bg-slate-900 text-transparent'
            }`}>
              <Check className="w-3 h-3 stroke-[3]" />
            </div>
            <span className="font-bold tracking-wide font-mono uppercase">Não mostrar este manual novamente nas próximas rodadas</span>
          </button>

          {/* Primary close/start button */}
          <button
            onClick={handleFinish}
            className="flex items-center justify-center gap-2 w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase tracking-widest rounded-xl transition duration-200 cursor-pointer active:scale-95 shadow-lg shadow-emerald-500/15"
          >
            Entendido! Iniciar Patrulha
            <ArrowRight className="w-4 h-4 stroke-[3]" />
          </button>
        </div>

      </div>
    </div>
  );
};
