/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Heart, Zap, Sparkles, AlertTriangle, Menu, BadgeCheck, Flame, X, Swords } from 'lucide-react';
import { Player, Region } from '../types';

interface HUDProps {
  player: Player;
  lightPercent: number;
  shadowPercent: number;
  unlockedCrystals: number;
  totalCrystals: number;
  currentLevelIdx: number;
  activeRegion: Region;
  levelName: string;
  onPause: () => void;
  onResume: () => void;
  isStatsOpen: boolean;
  onStatsOpenChange: (open: boolean) => void;
  aggressionPercent: number;
  difficultyLabel: string;
  difficultyColor: string;
  onAllocateStatPoint: (stat: 'vitalidade' | 'destreza' | 'forca' | 'resistencia' | 'manaStat') => void;
}

export const HUD: React.FC<HUDProps> = ({
  player,
  unlockedCrystals,
  totalCrystals,
  currentLevelIdx,
  activeRegion,
  levelName,
  onPause,
  onResume,
  isStatsOpen,
  onStatsOpenChange,
  aggressionPercent,
  difficultyLabel,
  difficultyColor,
  onAllocateStatPoint
}) => {
  const [swordBarLayout, setSwordBarLayout] = useState<{ x: number; y: number; scale: number; opacity?: number }>({ x: 50, y: 92, scale: 1.0, opacity: 1.0 });

  const handleCloseStats = (e?: React.MouseEvent | React.TouchEvent) => {
    if (e) {
      if (e.cancelable) e.preventDefault();
      e.stopPropagation();
    }
    onStatsOpenChange(false);
    onResume();
  };

  const handleOpenStats = (e?: React.MouseEvent | React.TouchEvent) => {
    if (e) {
      if (e.cancelable) e.preventDefault();
      e.stopPropagation();
    }
    onStatsOpenChange(true);
  };

  const handlePauseClick = (e?: React.MouseEvent | React.TouchEvent) => {
    if (e) {
      if (e.cancelable) e.preventDefault();
      e.stopPropagation();
    }
    onPause();
  };

  useEffect(() => {
    const loadLayout = () => {
      try {
        const saved = localStorage.getItem('mobile_hud_layout_v3');
        if (saved) {
          const parsed = JSON.parse(saved);
          const found = parsed.find((b: any) => b.id === 'swordBar');
          if (found) {
            setSwordBarLayout({ x: found.x, y: found.y, scale: found.scale, opacity: found.opacity });
          } else {
            setSwordBarLayout({ x: 50, y: 92, scale: 1.0, opacity: 1.0 });
          }
        } else {
          setSwordBarLayout({ x: 50, y: 92, scale: 1.0, opacity: 1.0 });
        }
      } catch (e) {
        setSwordBarLayout({ x: 50, y: 92, scale: 1.0, opacity: 1.0 });
      }
    };

    loadLayout();
    window.addEventListener('hud_layout_updated', loadLayout);
    return () => {
      window.removeEventListener('hud_layout_updated', loadLayout);
    };
  }, []);
  return (
    <div className="absolute inset-0 p-4 z-20 pointer-events-none select-none font-sans" id="hud">
      <div className="flex justify-between items-start w-full">
        
        {/* Left Section: Compact Progress Circle and Resource Bars (HP, Mana, Stamina) */}
        <div className="flex flex-col gap-2.5 bg-slate-950/85 border border-slate-900 backdrop-blur-md p-3 rounded-2xl w-56 pointer-events-auto shadow-xl" id="leftHUDSection">
          {/* Level Circle button representing XP ratio (opens Character Status overlay without pausing via standard game state paused screen) */}
          <button
            onClick={handleOpenStats}
            onTouchEnd={handleOpenStats}
            className="flex items-center gap-3 w-full hover:bg-slate-900/50 hover:border-slate-800 transition active:scale-98 duration-100 p-1.5 rounded-xl cursor-pointer text-left border border-transparent pointer-events-auto"
            id="btnOpenStats"
            title="Ver Status do Personagem (Atributos e Espada)"
          >
            {/* Level Circle with dynamic circular XP border */}
            <div className="relative w-11 h-11 flex-shrink-0">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                {/* Track Circle */}
                <circle
                  className="text-slate-800"
                  strokeWidth="3.2"
                  stroke="currentColor"
                  fill="transparent"
                  r="15.8"
                  cx="18"
                  cy="18"
                />
                {/* Progress Circle representing XP ratio */}
                <circle
                  className="text-sky-400 transition-all duration-300"
                  strokeWidth="3.2"
                  strokeDasharray="100, 100"
                  strokeDashoffset={Math.max(0, 100 - Math.min(100, ((player.xp || 0) / (player.maxXp || 100)) * 100))}
                  strokeLinecap="round"
                  stroke="url(#xpGradHUD)"
                  fill="transparent"
                  r="15.8"
                  cx="18"
                  cy="18"
                />
                {/* Gradient for XP circular border */}
                <defs>
                  <linearGradient id="xpGradHUD" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#38bdf8" />
                    <stop offset="100%" stopColor="#fbbf24" />
                  </linearGradient>
                </defs>
              </svg>
              {/* Level number in direct center of the circle */}
              <div className="absolute inset-0 flex items-center justify-center font-black text-white text-[12px] font-mono">
                {player.level ?? 0}
              </div>
            </div>
            <div className="flex flex-col">
              <div className="text-[9px] uppercase font-black tracking-widest text-slate-400 leading-none">PROGRESSO</div>
              <div className="text-[11px] font-bold text-slate-200 font-mono mt-1 leading-none">
                {player.xp ?? 0}/{player.maxXp ?? 100} XP
              </div>
            </div>
          </button>

          {/* Sutil Divider line */}
          <div className="border-t border-slate-900" />

          {/* HUD Resource Bars: HP, MANA, ESTAMINA */}
          <div className="flex flex-col gap-2 p-0.5">
            {/* Health Bar (HP) */}
            <div className="space-y-0.5">
              <div className="flex justify-between items-center text-[9px] uppercase font-extrabold tracking-wider text-rose-400">
                <span className="flex items-center gap-1">
                  <Heart className="w-2.5 h-2.5 text-rose-500 fill-rose-500 animate-pulse" />
                  Vida (HP)
                </span>
                <span className="font-mono text-[10px] text-slate-300">{Math.ceil(player.hp)} / {player.mxHp}</span>
              </div>
              <div className="w-full bg-slate-950 border border-slate-900 rounded-md overflow-hidden h-2.5 p-[1px]">
                <div
                  className="h-full bg-gradient-to-r from-rose-600 to-rose-400 rounded-sm"
                  style={{ width: `${Math.max(0, Math.min(100, (player.hp / player.mxHp) * 100))}%` }}
                />
              </div>
            </div>

            {/* Mana Bar */}
            <div className="space-y-0.5">
              <div className="flex justify-between items-center text-[9px] uppercase font-extrabold tracking-wider text-sky-450">
                <span className="flex items-center gap-1">
                  <Zap className="w-2.5 h-2.5 text-sky-400 fill-sky-400" />
                  Força da Rede
                </span>
                <span className="font-mono text-[10px] text-slate-300">{Math.ceil(player.mana)} / {player.mxMana}</span>
              </div>
              <div className="w-full bg-slate-950 border border-slate-900 rounded-md overflow-hidden h-2.5 p-[1px]">
                <div
                  className="h-full bg-gradient-to-r from-sky-600 to-indigo-500 rounded-sm"
                  style={{ width: `${Math.max(0, Math.min(100, (player.mana / player.mxMana) * 100))}%` }}
                />
              </div>
            </div>

            {/* Stamina Bar */}
            <div className="space-y-0.5">
              <div className="flex justify-between items-center text-[9px] uppercase font-extrabold tracking-wider text-emerald-450">
                <span className="flex items-center gap-1">
                  <Flame className="w-2.5 h-2.5 text-emerald-500 fill-emerald-500" />
                  Estamina
                </span>
                <span className="font-mono text-[10px] text-slate-300">{Math.ceil(player.stamina || 0)} / {player.mxStamina || 40}</span>
              </div>
              <div className="w-full bg-slate-950 border border-slate-900 rounded-md overflow-hidden h-2.5 p-[1px]">
                <div
                  className="h-full bg-gradient-to-r from-emerald-600 to-teal-400 rounded-sm"
                  style={{ width: `${Math.max(0, Math.min(100, ((player.stamina || 0) / (player.mxStamina || 40)) * 100))}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Center: Dynamic AI "Mariposa e Chama" Aggressor Scale */}
        <div className="flex flex-col items-center gap-1">
          {/* Difficulty Badge */}
          <div
            className="px-3 py-0.5 mt-1 border rounded-lg text-[9px] font-mono tracking-widest font-black uppercase"
            id="diffBadge"
            style={{
              backgroundColor: `${difficultyColor}15`,
              color: difficultyColor,
              borderColor: `${difficultyColor}50`
            }}
          >
            {difficultyLabel}
          </div>
        </div>

        {/* Right Section: Level Metadata, Collectibles, and Pause trigger */}
        <div className="flex flex-col items-end gap-2 mr-12">
          {/* Map info */}
          <div className="bg-slate-950/80 border border-slate-900 backdrop-blur-md px-4 py-3 rounded-2xl text-right pointer-events-auto shadow-xl flex flex-col gap-0.5">
            <span className="text-sky-400 font-bold text-xs tracking-wider" id="levelDisplay">
              {activeRegion.icon} {activeRegion.name}
            </span>
            <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider font-mono">
              Fase {currentLevelIdx + 1}: {levelName}
            </span>
            
            {/* Fragments Progress */}
            <div className="flex items-center gap-2 justify-end mt-1 text-[11px] font-bold text-amber-300 font-mono" id="fragDisplay">
              <span>FRAGMENTOS:</span>
              <span className="bg-amber-950/40 border border-amber-500/20 px-2 py-0.5 rounded-lg text-amber-400">
                {unlockedCrystals} / {totalCrystals}
              </span>
            </div>
          </div>

          {/* Blinding / Ascension level */}
          <div className="bg-slate-950/70 border border-slate-900 px-3 py-1.5 rounded-xl flex items-center gap-1.5 text-[10px] text-slate-400 font-mono" id="ascLabel">
            <BadgeCheck className="w-4 h-4 text-sky-400" />
            ASCENSÃO: {player.ascPhase + 1} / 5
          </div>

          {/* Standard menu button */}
          <button
            onClick={handlePauseClick}
            onTouchEnd={handlePauseClick}
            className="flex items-center gap-2 px-3 py-2 bg-slate-900 border border-slate-800 hover:bg-slate-800 hover:border-slate-700 rounded-xl text-slate-300 hover:text-white transition duration-200 cursor-pointer text-xs font-bold pointer-events-auto"
            id="mnb"
          >
            <Menu className="w-3.5 h-3.5" />
            Menu
          </button>
        </div>
      </div>

      {/* FULL SCREEN CHARACTER STATUS OVERLAY */}
      {isStatsOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/98 backdrop-blur-2xl flex flex-col items-center p-6 md:p-8 overflow-y-auto pointer-events-auto text-slate-100 select-text font-sans">
          
          {/* Header Block */}
          <div className="flex justify-between items-center w-full max-w-5xl border-b border-slate-900/80 pb-4 mb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-center justify-center text-amber-400">
                <Swords className="w-5 h-5 animate-pulse" />
              </div>
              <div className="flex flex-col">
                <h1 className="text-xl md:text-2xl font-black text-amber-400 tracking-wider uppercase leading-none">
                  Status do Personagem
                </h1>
                <p className="text-[10px] text-slate-500 uppercase tracking-widest font-black font-mono mt-1.5 leading-none">
                  Fase {currentLevelIdx + 1}: {levelName}
                </p>
              </div>
            </div>
            
            {/* Close trigger button */}
            <button
              onClick={handleCloseStats}
              onTouchEnd={handleCloseStats}
              className="p-2.5 bg-slate-900 hover:bg-slate-850 hover:text-rose-400 border border-slate-850 rounded-xl text-slate-400 transition cursor-pointer flex items-center justify-center shadow-lg shadow-black/40 hover:scale-105 pointer-events-auto"
              id="btnCloseStats"
              title="Voltar ao Jogo"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Core Content Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 w-full max-w-5xl mb-8">
            
            {/* COLUMN 1: VITAL RESOURCE BARS */}
            <div className="bg-slate-900/30 border border-slate-900/60 p-5 rounded-2xl flex flex-col gap-4 shadow-xl shadow-black/15">
              <h2 className="text-xs font-black text-slate-400 uppercase tracking-widest border-b border-slate-900/80 pb-2 mb-1 flex items-center gap-1.5">
                <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
                Recursos Atuais
              </h2>

              {/* Big Level Progression Block */}
              <div className="flex items-center gap-4 bg-slate-950/60 border border-slate-900/80 p-4 rounded-xl">
                <div className="relative w-16 h-16 flex-shrink-0">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                    <circle
                      className="text-slate-850"
                      strokeWidth="2.8"
                      stroke="currentColor"
                      fill="transparent"
                      r="15.8"
                      cx="18"
                      cy="18"
                    />
                    <circle
                      className="text-sky-400 transition-all duration-300"
                      strokeWidth="2.8"
                      strokeDasharray="100, 100"
                      strokeDashoffset={Math.max(0, 100 - Math.min(100, ((player.xp || 0) / (player.maxXp || 100)) * 100))}
                      strokeLinecap="round"
                      stroke="url(#xpGradModal)"
                      fill="transparent"
                      r="15.8"
                      cx="18"
                      cy="18"
                    />
                    <defs>
                      <linearGradient id="xpGradModal" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#38bdf8" />
                        <stop offset="100%" stopColor="#fbbf24" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center font-black text-white text-lg font-mono">
                    {player.level ?? 0}
                  </div>
                </div>
                <div className="flex flex-col">
                  <span className="text-[9px] uppercase tracking-wider font-extrabold text-slate-500 leading-none">Progresso de Nível</span>
                  <span className="text-base font-black text-white font-mono mt-1.5 leading-none">
                    {player.xp ?? 0} <span className="text-slate-600 font-normal">/</span> {player.maxXp ?? 100} XP
                  </span>
                  <span className="text-[10px] text-sky-400 font-medium font-mono mt-1.5 leading-none">
                    {Math.floor(((player.xp || 0) / (player.maxXp || 100)) * 100)}% Acumulado
                  </span>
                </div>
              </div>

              {/* Vida (HP) */}
              <div className="space-y-1.5 bg-slate-950/20 p-2 border border-slate-900/40 rounded-xl">
                <div className="flex justify-between items-center text-[10px] uppercase font-black tracking-widest text-rose-400">
                  <span className="flex items-center gap-1">
                    <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
                    HP Máximo
                  </span>
                  <span className="font-mono text-xs font-bold text-slate-300">{Math.ceil(player.hp)} / {player.mxHp}</span>
                </div>
                <div className="w-full bg-slate-950 border border-slate-900 rounded-lg overflow-hidden h-3.5 p-[2px]">
                  <div
                    className="h-full bg-gradient-to-r from-rose-600 to-rose-400 rounded-md shadow-[0_0_8px_rgba(239,68,68,0.3)]"
                    style={{ width: `${Math.max(0, Math.min(100, (player.hp / player.mxHp) * 100))}%` }}
                  />
                </div>
              </div>

              {/* Mana */}
              <div className="space-y-1.5 bg-slate-950/20 p-2 border border-slate-900/40 rounded-xl">
                <div className="flex justify-between items-center text-[10px] uppercase font-black tracking-widest text-sky-400">
                  <span className="flex items-center gap-1">
                     <Zap className="w-3.5 h-3.5 text-sky-400 fill-sky-400" />
                     Força da Rede
                  </span>
                  <span className="font-mono text-xs font-bold text-slate-300">{Math.ceil(player.mana)} / {player.mxMana}</span>
                </div>
                <div className="w-full bg-slate-950 border border-slate-900 rounded-lg overflow-hidden h-3.5 p-[2px]">
                  <div
                    className="h-full bg-gradient-to-r from-sky-600 to-indigo-500 rounded-md shadow-[0_0_8px_rgba(56,189,248,0.3)]"
                    style={{ width: `${Math.max(0, Math.min(100, (player.mana / player.mxMana) * 100))}%` }}
                  />
                </div>
              </div>

              {/* Estamina */}
              <div className="space-y-1.5 bg-slate-950/20 p-2 border border-slate-900/40 rounded-xl">
                <div className="flex justify-between items-center text-[10px] uppercase font-black tracking-widest text-emerald-400">
                  <span className="flex items-center gap-1">
                    <Flame className="w-3.5 h-3.5 text-emerald-500 fill-emerald-500" />
                    Estamina
                  </span>
                  <span className="font-mono text-xs font-bold text-slate-300">{Math.ceil(player.stamina ?? 0)} / {player.mxStamina ?? 40}</span>
                </div>
                <div className="w-full bg-slate-950 border border-slate-900 rounded-lg overflow-hidden h-3.5 p-[2px]">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-600 to-teal-400 rounded-md shadow-[0_0_8px_rgba(16,185,129,0.3)]"
                    style={{ width: `${Math.max(0, Math.min(100, ((player.stamina || 0) / (player.mxStamina || 40)) * 100))}%` }}
                  />
                </div>
              </div>
            </div>

            {/* COLUMN 2: ATTRIBUTE upgrades */}
            <div className="bg-slate-900/30 border border-slate-900/60 p-5 rounded-2xl flex flex-col gap-3 shadow-xl shadow-black/15">
              <div className="flex justify-between items-center border-b border-slate-900/80 pb-2 mb-1">
                <h2 className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  Evoluir Atributos
                </h2>
                {(player.statPoints || 0) > 0 ? (
                  <span className="text-[10px] font-black uppercase text-yellow-400 bg-amber-950/60 border border-amber-500/30 px-2 py-0.5 rounded-full animate-pulse flex items-center gap-0.5">
                    ★ {player.statPoints} Pt
                  </span>
                ) : (
                  <span className="text-[9px] font-mono font-bold text-slate-500 uppercase">0 pts</span>
                )}
              </div>

              {/* 1. Vitalidade */}
              <div className="p-2.5 bg-slate-950/45 border border-slate-900 rounded-xl flex flex-col gap-1.5">
                <div className="flex justify-between items-center">
                  <span className="text-rose-400 font-extrabold text-[11px] uppercase tracking-wider">Vitalidade</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-black text-white bg-slate-900 border border-slate-850 px-1.5 py-0.5 rounded text-center min-w-[20px]">
                      {player.vitalidade || 0}
                    </span>
                    {(player.statPoints || 0) > 0 && (
                      <button
                        onClick={() => onAllocateStatPoint('vitalidade')}
                        className="w-5 h-5 flex items-center justify-center bg-rose-600 hover:bg-rose-500 active:scale-90 text-white rounded font-black text-xs cursor-pointer"
                        title="Dá +15 Vida Máxima"
                      >
                        +
                      </button>
                    )}
                  </div>
                </div>
                <p className="text-[9.5px] text-slate-400 leading-normal">
                  Dá <span className="text-rose-400 font-bold">+15 HP Máximo</span> por ponto. Melhora sobrevivência a pancadas fortes.
                </p>
              </div>

              {/* 2. Destreza */}
              <div className="p-2.5 bg-slate-950/45 border border-slate-900 rounded-xl flex flex-col gap-1.5">
                <div className="flex justify-between items-center">
                  <span className="text-emerald-400 font-extrabold text-[11px] uppercase tracking-wider">Destreza</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-black text-white bg-slate-900 border border-slate-850 px-1.5 py-0.5 rounded text-center min-w-[20px]">
                      {player.destreza || 0}
                    </span>
                    {(player.statPoints || 0) > 0 && (
                      <button
                        onClick={() => onAllocateStatPoint('destreza')}
                        className="w-5 h-5 flex items-center justify-center bg-emerald-600 hover:bg-emerald-500 active:scale-90 text-white rounded font-black text-xs cursor-pointer"
                        title="Dá +15 Estamina"
                      >
                        +
                      </button>
                    )}
                  </div>
                </div>
                <p className="text-[9.5px] text-slate-400 leading-normal">
                  Dá <span className="text-emerald-400 font-bold">+15 Estamina Máxima</span>, aumenta velocidade base e carga de estamina.
                </p>
              </div>

              {/* 3. Força */}
              <div className="p-2.5 bg-slate-950/45 border border-slate-900 rounded-xl flex flex-col gap-1.5">
                <div className="flex justify-between items-center">
                  <span className="text-amber-500 font-extrabold text-[11px] uppercase tracking-wider">Força</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-black text-white bg-slate-900 border border-slate-850 px-1.5 py-0.5 rounded text-center min-w-[20px]">
                      {player.forca || 0}
                    </span>
                    {(player.statPoints || 0) > 0 && (
                      <button
                        onClick={() => onAllocateStatPoint('forca')}
                        className="w-5 h-5 flex items-center justify-center bg-amber-600 hover:bg-amber-500 active:scale-90 text-white rounded font-black text-xs cursor-pointer"
                        title="Aumenta o dano de impacto com o cacetete"
                      >
                        +
                      </button>
                    )}
                  </div>
                </div>
                <p className="text-[9.5px] text-slate-400 leading-normal">
                  Adiciona <span className="text-amber-400 font-bold">+4 de dano</span> em golpes normais e fortalece impactos carregados.
                </p>
              </div>

              {/* 4. Resistência */}
              <div className="p-2.5 bg-slate-950/45 border border-slate-900 rounded-xl flex flex-col gap-1.5">
                <div className="flex justify-between items-center">
                  <span className="text-violet-400 font-extrabold text-[11px] uppercase tracking-wider">Resistência</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-black text-white bg-slate-900 border border-slate-850 px-1.5 py-0.5 rounded text-center min-w-[20px]">
                      {player.resistencia || 0}
                    </span>
                    {(player.statPoints || 0) > 0 && (
                      <button
                        onClick={() => onAllocateStatPoint('resistencia')}
                        className="w-5 h-5 flex items-center justify-center bg-violet-600 hover:bg-violet-500 active:scale-90 text-white rounded font-black text-xs cursor-pointer"
                        title="Diminui dano recebido"
                      >
                        +
                      </button>
                    )}
                  </div>
                </div>
                <p className="text-[9.5px] text-slate-400 leading-normal">
                  Couraça física. <span className="text-violet-400 font-bold">Reduz o dano recebido em -2 absolut</span> por ponto.
                </p>
              </div>

              {/* 5. Alquimia Força da Rede */}
              <div className="p-2.5 bg-slate-950/45 border border-slate-900 rounded-xl flex flex-col gap-1.5">
                <div className="flex justify-between items-center">
                  <span className="text-sky-400 font-extrabold text-[11px] uppercase tracking-wider">Alquimia Força da Rede</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-black text-white bg-slate-900 border border-slate-850 px-1.5 py-0.5 rounded text-center min-w-[20px]">
                      {player.manaStat || 0}
                    </span>
                    {(player.statPoints || 0) > 0 && (
                      <button
                        onClick={() => onAllocateStatPoint('manaStat')}
                        className="w-5 h-5 flex items-center justify-center bg-sky-600 hover:bg-sky-500 active:scale-90 text-white rounded font-black text-xs cursor-pointer"
                        title="Dá +15 Força da Rede"
                      >
                        +
                      </button>
                    )}
                  </div>
                </div>
                <p className="text-[9.5px] text-slate-400 leading-normal">
                  Dá <span className="text-sky-400 font-bold">+15 Força de Rede Máxima</span> por ponto. Inicialmente o alcance da rede é curto, mas aumenta de 10 em 10 pontos.
                </p>
              </div>
            </div>

            {/* COLUMN 3: GUARD SKILLS & CHARGES */}
            <div className="bg-slate-900/30 border border-slate-900/60 p-5 rounded-2xl flex flex-col gap-4 shadow-xl shadow-black/15">
              <h2 className="text-xs font-black text-slate-400 uppercase tracking-widest border-b border-slate-900/80 pb-2 mb-1 flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
                Equipamentos de Patrulha
              </h2>

              {/* Heavy Attack Charges */}
              <div className="bg-slate-950/65 border border-slate-900 p-3 rounded-xl flex flex-col gap-2">
                <div className="flex justify-between items-center text-[10px] uppercase font-black tracking-widest text-amber-500">
                  <span className="flex items-center gap-1 font-bold">
                    <Flame className="w-3.5 h-3.5 text-amber-400" />
                    Cargas de Impacto [V]
                  </span>
                  <span className="font-mono text-xs">{player.swordKillsCharge || 0}/5</span>
                </div>
                <div className="w-full bg-slate-950 border border-slate-900 rounded-lg overflow-hidden h-3 flex gap-[3px] p-[2px]">
                  {[0, 1, 2, 3, 4].map((i) => {
                    const filled = (player.swordKillsCharge || 0) > i;
                    const isMax = (player.swordKillsCharge || 0) >= 5;
                    return (
                      <div
                        key={i}
                        className={`h-full flex-1 rounded-sm transition-all duration-300 ${
                          filled
                            ? isMax
                              ? 'bg-gradient-to-t from-amber-500 to-yellow-300 animate-pulse shadow-[0_0_8px_rgba(251,191,36,0.8)]'
                              : 'bg-amber-500'
                            : 'bg-slate-850'
                        }`}
                      />
                    );
                  })}
                </div>
                <p className="text-[9px] text-slate-500 mt-1 leading-normal text-left">
                  Ganhe cargas ao neutralizar ameaças com o cacetete. Com 5 cargas disponíveis, libere o poderoso impacto de dispersão sônica!
                </p>
              </div>

              {/* Skill entries list */}
              <div className="flex flex-col gap-2">
                
                {/* Basic Swing */}
                <div className="p-2 bg-slate-950/40 border border-slate-900 rounded-xl">
                  <div className="flex justify-between items-center text-[10.5px] font-black uppercase text-slate-300 leading-none">
                    <span>Impacto Simples [Z]</span>
                    <span className="text-[8px] text-slate-500 font-mono bg-slate-950 border border-slate-900 px-1.5 py-0.5 rounded leading-none">0 Estamina</span>
                  </div>
                  <p className="text-[9px] text-slate-400 mt-1.5 leading-normal">
                    Executa uma sequência de até 3 batidas rápidas com o cacetete. Fortalecido diretamente por sua <span className="text-amber-500 font-bold">Força</span>.
                  </p>
                </div>

                {/* Thrust (C) */}
                <div className="p-2 bg-slate-950/40 border border-slate-900 rounded-xl">
                  <div className="flex justify-between items-center text-[10.5px] font-black uppercase text-emerald-400 leading-none">
                    <span>Estocada Tática [C]</span>
                    <span className="text-[8px] text-rose-500 font-mono bg-slate-950 border border-slate-900 px-1.5 py-0.5 rounded leading-none">10 Estamina</span>
                  </div>
                  <p className="text-[9px] text-slate-400 mt-1.5 leading-normal">
                    Investida para frente empurrando malfeitores com o cacetete. Essencial para dispersar grupos. *Requer 10+ de Estamina.*
                  </p>
                </div>

                {/* Ground Heavy (V) */}
                <div className="p-2 bg-slate-950/40 border border-slate-900 rounded-xl">
                  <div className="flex justify-between items-center text-[10.5px] font-black uppercase text-amber-500 leading-none">
                    <span>Dispersor Sônico [V]</span>
                    <span className="text-[8px] text-rose-500 font-mono bg-slate-950 border border-slate-900 px-1.5 py-0.5 rounded leading-none">10 Estam. + 5 Cargs</span>
                  </div>
                  <p className="text-[9px] text-slate-400 mt-1.5 leading-normal">
                    Libera uma onda de choque de dissuasão circular massiva ao golpear o chão. Afasta e neutraliza poluidores em área. *Requer 5 Cargas e 10+ de Estamina.*
                  </p>
                </div>

                {/* Shield of Immunity (F) */}
                <div className="p-2 bg-slate-950/40 border border-indigo-900/60 rounded-xl">
                  <div className="flex justify-between items-center text-[10.5px] font-black uppercase text-indigo-400 leading-none">
                    <span>Barreira Tática [F]</span>
                    <span className="text-[8px] text-sky-400 font-mono bg-slate-950 border border-slate-900 px-1.5 py-0.5 rounded leading-none">30 Estamina + 15 Força de Rede</span>
                  </div>
                  <p className="text-[9px] text-slate-400 mt-1.5 leading-normal">
                    Ativa o transmissor de frequência criando uma redoma de <span className="text-indigo-400 font-bold">Resistência Absoluta</span> contra qualquer dano físico por 5 segundos. *Requer 30 Estamina (Destreza) e 15 Força de Rede.*
                  </p>
                </div>

              </div>
            </div>
            
          </div>

          {/* Dialog Action Buttons */}
          <button
            onClick={handleCloseStats}
            onTouchEnd={handleCloseStats}
            className="px-8 py-3 bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black text-sm tracking-widest rounded-xl hover:scale-103 active:scale-98 transition duration-150 cursor-pointer shadow-lg shadow-amber-500/10 pointer-events-auto flex items-center gap-2"
            id="btnCloseMainBtn"
          >
            <BadgeCheck className="w-4 h-4 text-slate-950" />
            VOLTAR AO JOGO
          </button>
        </div>
      )}

      {/* Centro Inferior: Barra de Carga de Espada */}
      <div 
        style={{
          left: `${swordBarLayout.x}%`,
          top: `${swordBarLayout.y}%`,
          transform: `translate(-50%, -50%) scale(${swordBarLayout.scale})`,
          bottom: 'auto',
          opacity: swordBarLayout.opacity !== undefined ? swordBarLayout.opacity : 1.0,
        }}
        className="absolute bg-slate-950/90 border border-slate-900 backdrop-blur-md px-4.5 py-3 rounded-2xl w-56 flex flex-col gap-1.5 pointer-events-auto shadow-2xl transition duration-300 hover:scale-102 hover:border-amber-500/30" 
        id="bottomLeftSwordBar"
      >
        <div className="flex justify-between items-center text-[10px] uppercase font-black tracking-widest text-amber-500">
          <span className="flex items-center gap-1 font-bold">
            <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-500 animate-pulse" />
            Cargas de Espada [V]
          </span>
          <span className="font-mono text-[11px] text-amber-400 font-extrabold bg-slate-950 px-2 py-0.5 rounded-lg border border-slate-900 shadow-sm leading-none flex items-center justify-center">
            {player.swordKillsCharge ?? 0}/5
          </span>
        </div>
        
        {/* Progress Bar Container with 5 segments */}
        <div className="w-full bg-slate-950 border border-slate-900 rounded-lg overflow-hidden h-3 flex gap-[3px] p-[2.5px] shadow-inner">
          {[0, 1, 2, 3, 4].map((i) => {
            const filled = (player.swordKillsCharge ?? 0) > i;
            const isMax = (player.swordKillsCharge ?? 0) >= 5;
            return (
              <div
                key={i}
                className={`h-full flex-1 rounded-sm transition-all duration-300 ${
                  filled
                    ? isMax
                      ? 'bg-gradient-to-t from-amber-500 to-yellow-300 animate-pulse shadow-[0_0_8px_rgba(251,191,36,0.8)]'
                      : 'bg-gradient-to-r from-amber-600 to-amber-400'
                    : 'bg-slate-850'
                }`}
              />
            );
          })}
        </div>

        {/* Dynamic Help Label with glowing effect if active */}
        {(player.swordKillsCharge ?? 0) >= 5 ? (
          <span className="text-[9px] font-bold text-amber-400 font-mono animate-pulse tracking-wider leading-none">
            ★ ATAQUE PESADO DISPONÍVEL! Aperte [V]
          </span>
        ) : (
          <span className="text-[8.5px] font-medium text-slate-500 font-mono uppercase tracking-wide leading-none">
            Elimine inimigos para carregar
          </span>
        )}
      </div>
    </div>
  );
};
