/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Trophy, Award, Sparkles, ShieldAlert, Zap, Globe, Flame, Crown, Swords, Dumbbell } from 'lucide-react';
import { TrophyDef } from '../types';

interface TrophiesCabinetProps {
  trophies: Record<string, boolean>;
  onClose: () => void;
}

export const TROPHY_LIST: TrophyDef[] = [
  { id: 'first_blood', icon: '👮', name: 'Primeira Apreensão', desc: 'Prenda ou neutralize seu primeiro infrator florestal' },
  { id: 'crystal_hunter', icon: '🦜', name: 'Defensor da Fauna', desc: 'Resgate todos os animais silvestres em perigo de uma fase' },
  { id: 'ascended', icon: '🌱', name: 'Recuperador Oficial', desc: 'Alcance 50% de Preservação Ambiental nos canais de Lumen' },
  { id: 'light_pure', icon: '🌳', name: 'Guardião Lendário', desc: 'Alcance 100% de Floresta Viva e restaure o ecossistema' },
  { id: 'boss_slayer', icon: '⛓️', name: 'Pacificador de Lumen', desc: 'Neutralize e prenda um dos líderes da organização criminosa' },
  { id: 'all_clear', icon: '🏆', name: 'Protetor de Reservas', desc: 'Recupere inteiramente todas as 30 fases de uma região do parque' },
  { id: 'combo_master', icon: '⚡', name: 'Tática de Imobilização', desc: 'Realize uma sequência ágil de combo com o Bastão Tático' },
  { id: 'trophy_hunter', icon: '🏅', name: 'Herói Conservacionista', desc: 'Acumule 5 ou mais medalhas de preservação distintas' },
  { id: 'final_boss', icon: '⭐', name: 'O Futuro de Lumen', desc: 'Prenda o Barão do Desmatamento e restaure o Coração de Lumen' },
  { id: 'impossible_clear', icon: '🐆', name: 'Força da Natureza', desc: 'Vença qualquer fase na dificuldade Sobrenatural' }
];

export const TrophiesCabinet: React.FC<TrophiesCabinetProps> = ({ trophies, onClose }) => {
  const earnedCount = Object.keys(trophies).filter(id => trophies[id]).length;

  const getTrophyLucide = (id: string, earned: boolean) => {
    const color = earned ? 'text-emerald-400' : 'text-slate-600';
    switch (id) {
      case 'first_blood': return <Swords className={`w-8 h-8 ${color}`} />;
      case 'crystal_hunter': return <Sparkles className={`w-8 h-8 ${color}`} />;
      case 'ascended': return <Zap className={`w-8 h-8 ${color}`} />;
      case 'light_pure': return <Globe className={`w-8 h-8 ${color}`} />;
      case 'boss_slayer': return <Crown className={`w-8 h-8 ${color}`} />;
      case 'all_clear': return <Trophy className={`w-8 h-8 ${color}`} />;
      case 'combo_master': return <Flame className={`w-8 h-8 ${color}`} />;
      case 'trophy_hunter': return <Award className={`w-8 h-8 ${color}`} />;
      case 'final_boss': return <Crown className={`w-8 h-8 ${color}`} />;
      case 'impossible_clear': return <ShieldAlert className={`w-8 h-8 text-rose-500`} />;
      default: return <Trophy className={`w-8 h-8 ${color}`} />;
    }
  };

  return (
    <div className="absolute inset-0 z-40 flex flex-col items-center bg-slate-950/98 backdrop-blur-md p-6 overflow-y-auto" id="trophyScreen">
      <div className="w-full max-w-4xl flex justify-between items-center border-b border-slate-800 pb-4 mb-6">
        <div>
          <h2 className="text-3xl font-extrabold tracking-wider text-emerald-400 font-sans flex items-center gap-3">
            <Trophy className="w-8 h-8 text-emerald-400 animate-pulse" />
            MURAL DE CONQUISTAS AMBIENTAIS
          </h2>
          <p className="text-slate-400 text-sm mt-1">
            Suas ações de preservação registradas no Parque Nacional de Lumen.
          </p>
        </div>
        <div className="bg-slate-900 px-4 py-2 rounded-xl border border-slate-700/80">
          <span className="text-xs text-slate-400 block tracking-wider font-mono">RECONHECIMENTOS</span>
          <span className="text-lg font-bold font-mono text-emerald-300">
            {earnedCount} / {TROPHY_LIST.length} ({Math.round((earnedCount / TROPHY_LIST.length) * 100)}%)
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-4xl mb-8">
        {TROPHY_LIST.map(trophy => {
          const earned = !!trophies[trophy.id];
          return (
            <div
              key={trophy.id}
              className={`flex items-center gap-4 p-4 rounded-xl border transition-all duration-300 ${
                earned
                  ? 'bg-gradient-to-r from-amber-950/20 to-slate-900/60 border-amber-500/40 shadow-lg shadow-amber-500/5'
                  : 'bg-slate-900/40 border-slate-800/80 opacity-60'
              }`}
            >
              <div className="flex-shrink-0 bg-slate-950 p-3 rounded-xl border border-slate-800 shadow-inner">
                {getTrophyLucide(trophy.id, earned)}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h3 className={`text-base font-bold tracking-tight ${earned ? 'text-amber-200' : 'text-slate-500'}`}>
                    {trophy.name}
                  </h3>
                  {earned && (
                    <span className="text-[10px] bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded-full border border-amber-500/20 font-mono">
                      ALCANÇADO
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">{trophy.desc}</p>
              </div>
              <div className="text-2xl opacity-75">{trophy.icon}</div>
            </div>
          );
        })}
      </div>

      <button
        onClick={onClose}
        className="px-8 py-3 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white font-medium border border-slate-800 hover:border-slate-700 rounded-xl transition duration-250 cursor-pointer shadow-md mb-4"
        id="btnBack6"
      >
        Voltar ao Menu Principal
      </button>
    </div>
  );
};
