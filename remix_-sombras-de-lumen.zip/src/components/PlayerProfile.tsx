/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  ArrowLeft, 
  User, 
  Swords, 
  Sparkles, 
  Award, 
  Map, 
  Heart, 
  Zap, 
  Flame, 
  ShieldAlert, 
  PlusCircle, 
  FlameKindling,
  Sun,
  Moon
} from 'lucide-react';

interface PlayerProfileProps {
  playerProgression: {
    level: number;
    xp: number;
    maxXp: number;
    statPoints: number;
    vitalidade: number;
    destreza: number;
    forca: number;
    resistencia: number;
    manaStat: number;
  };
  unlockedLevelsCount: number;
  completedLevelsCount: number;
  trophiesCount: number;
  difficultyLabel: string;
  difficultyColor: string;
  onAllocateStatPoint: (stat: 'vitalidade' | 'destreza' | 'forca' | 'resistencia' | 'manaStat') => void;
  onResetStats: () => void;
  onBack: () => void;
}

export const PlayerProfile: React.FC<PlayerProfileProps> = ({
  playerProgression,
  unlockedLevelsCount,
  completedLevelsCount,
  trophiesCount,
  difficultyLabel,
  difficultyColor,
  onAllocateStatPoint,
  onResetStats,
  onBack
}) => {
  const { level, xp, maxXp, statPoints, vitalidade, destreza, forca, resistencia, manaStat } = playerProgression;
  const xpPercent = Math.min(100, Math.floor((xp / maxXp) * 100));

  // Calculated values based on core game constants
  const maxHpValue = 100 + vitalidade * 15;
  const maxManaValue = 100 + manaStat * 12;
  const attackMultiplier = 1 + forca * 0.12;
  const extraDamageReduction = resistencia * 0.8;
  const doubleJumpsValue = 2 + Math.floor(destreza / 5);

  return (
    <div className="absolute inset-0 z-30 flex flex-col bg-slate-950 p-6 select-none overflow-hidden font-sans" id="playerProfileScreen">
      
      {/* Background Star Ambient effects */}
      <div className="absolute inset-0 pointer-events-none opacity-20 bg-radial-gradient(circle at top, rgba(99,102,241,0.15) 0%, rgba(0,0,0,0.8) 100%)" />
      <div className="absolute inset-0 pointer-events-none opacity-30">
        {Array.from({ length: 25 }).map((_, i) => (
          <div
            key={i}
            className="absolute bg-sky-500 rounded-full animate-pulse"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              width: `${Math.random() * 2 + 1.5}px`,
              height: `${Math.random() * 2 + 1.5}px`,
              animationDuration: `${Math.random() * 4 + 2}s`,
              animationDelay: `${Math.random() * 2}s`
            }}
          />
        ))}
      </div>

      {/* Header Bar */}
      <div className="relative z-10 flex items-center justify-between border-b border-slate-900 pb-3.5 mb-4">
        <button
          onClick={onBack}
          className="flex items-center gap-1 px-3 py-1.5 bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white text-xs font-bold rounded-lg cursor-pointer transition hover:scale-102 active:scale-97"
          id="btnBackProfile"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          Voltar ao Menu
        </button>

        <h1 className="text-xl font-black text-sky-400 tracking-wider flex items-center gap-2">
          <User className="w-5 h-5 text-sky-400" />
          PERFIL DO JOGADOR
        </h1>

        <div className="px-3 py-1 rounded bg-slate-900 border border-slate-800 text-[10px] font-mono text-slate-400 font-bold tracking-wide">
          Status: <span style={{ color: difficultyColor }} className="font-extrabold uppercase">{difficultyLabel}</span>
        </div>
      </div>

      {/* Grid Content Layout */}
      <div className="relative z-10 grid grid-cols-12 gap-4 flex-1 h-[450px]">
        
        {/* LEFT COLUMN: Character Concept Hero Card & Stats Allocation */}
        <div className="col-span-5 bg-slate-900/40 p-4 border border-slate-900 rounded-2xl flex flex-col justify-between h-full">
          
          {/* Hero Concept Card Info */}
          <div>
            <div className="flex items-center gap-3.5 mb-3 bg-slate-950/60 p-3 rounded-xl border border-slate-850">
              <div className="relative w-14 h-14 bg-gradient-to-tr from-emerald-600 to-teal-500 rounded-xl flex items-center justify-center border border-emerald-400 shadow-[0_0_15px_rgba(52,211,153,0.25)] animate-pulse">
                <Sparkles className="w-7 h-7 text-white" />
              </div>
              <div className="text-left flex-1">
                <h2 className="text-sm font-black text-slate-100 tracking-wide uppercase leading-tight">Agente de Lumen</h2>
                <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase tracking-widest leading-none">Função: Fiscal Ambiental</span>
                
                {/* XP State Line */}
                <div className="mt-2.5 space-y-1">
                  <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 leading-none">
                    <span>NÍVEL {level}</span>
                    <span>{xp} / {maxXp} XP</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-950/80 rounded-full overflow-hidden border border-slate-900/60 p-[1px]">
                    <div 
                      className="h-full bg-gradient-to-r from-emerald-400 to-teal-500 rounded-full transition-all duration-300"
                      style={{ width: `${xpPercent}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* General Secondary Statistics metrics */}
            <div className="grid grid-cols-3 gap-2 bg-slate-950/30 p-2 border border-slate-900 rounded-xl text-center text-xs mb-3 font-mono">
              <div className="flex flex-col p-1.5">
                <span className="text-slate-500 text-[8px] tracking-wide uppercase">Setores</span>
                <span className="text-slate-200 font-black flex items-center justify-center gap-1 mt-0.5">
                  <Map className="w-3 h-3 text-emerald-400" />
                  {completedLevelsCount}/100
                </span>
              </div>
              <div className="flex flex-col p-1.5 border-l border-r border-slate-900/60">
                <span className="text-slate-500 text-[8px] tracking-wide uppercase">Medalhas</span>
                <span className="text-slate-200 font-black flex items-center justify-center gap-1 mt-0.5">
                  <Award className="w-3 h-3 text-amber-400" />
                  {trophiesCount}
                </span>
              </div>
              <div className="flex flex-col p-1.5">
                <span className="text-slate-500 text-[8px] tracking-wide uppercase">Impacto Bastão</span>
                <span className="text-rose-400 font-black flex items-center justify-center gap-1 mt-0.5">
                  <FlameKindling className="w-3 h-3 text-rose-400" />
                  {(10 * attackMultiplier).toFixed(0)}
                </span>
              </div>
            </div>
          </div>

          {/* Core attributes Allocation system */}
          <div className="space-y-2 flex-1 mt-1">
            <div className="flex items-center justify-between border-b border-slate-900 pb-1.5 mb-1">
              <span className="text-[10px] font-mono tracking-widest font-extrabold text-slate-400 uppercase">UPGRADES DE EQUIPAMENTOS</span>
              {statPoints > 0 ? (
                <span className="px-1.5 py-0.5 bg-emerald-500/10 border border-emerald-500/40 text-emerald-400 text-[9px] font-black rounded font-mono animate-pulse">
                  +{statPoints} PONTOS
                </span>
              ) : (
                <span className="text-[9px] font-mono text-slate-600">Sem pontos livres</span>
              )}
            </div>

            <div className="space-y-1.5 text-xs">
              {[
                { key: 'vitalidade' as const, label: 'Traje de Proteção', val: vitalidade, desc: `Resiliência física do agente (${maxHpValue} HP)`, color: 'text-rose-400', icon: Heart },
                { key: 'forca' as const, label: 'Bastão Tático', val: forca, desc: `Impacto das batidas no bastão (+${(forca * 12).toFixed(0)}%)`, color: 'text-amber-400', icon: Flame },
                { key: 'destreza' as const, label: 'Botas Táticas', val: destreza, desc: `Impulsividade física de evasão (${doubleJumpsValue} Pulos)`, color: 'text-emerald-400', icon: Zap },
                { key: 'resistencia' as const, label: 'Colete Balístico', val: resistencia, desc: `Redução de impacto recebido (-${extraDamageReduction.toFixed(1)} de dano)`, color: 'text-sky-400', icon: ShieldAlert },
                { key: 'manaStat' as const, label: 'Bateria do Rádio', val: manaStat, desc: `Bateria do drone (${maxManaValue} MP). Alcance curto da rede, aumenta a cada 10 pts`, color: 'text-purple-400', icon: Sparkles }
              ].map(stat => {
                const Icon = stat.icon;
                return (
                  <div key={stat.key} className="flex items-center justify-between bg-slate-950/40 p-1.5 rounded-lg border border-slate-850/80">
                    <div className="flex items-center gap-2">
                      <div className={`p-1 rounded bg-slate-900 border border-slate-800 ${stat.color}`}>
                        <Icon className="w-3.5 h-3.5" />
                      </div>
                      <div className="text-left font-mono">
                        <div className="text-[11px] font-extrabold text-slate-200 uppercase leading-none">{stat.label}: <span className={stat.color}>{stat.val}</span></div>
                        <div className="text-[8.5px] text-slate-500 font-sans tracking-tight mt-0.5 leading-none">{stat.desc}</div>
                      </div>
                    </div>
                    {statPoints > 0 && (
                      <button
                        onClick={() => onAllocateStatPoint(stat.key)}
                        className="p-1 text-slate-400 hover:text-white hover:scale-110 active:scale-95 transition cursor-pointer"
                        title={`Investir 1 ponto em ${stat.label}`}
                      >
                        <PlusCircle className="w-4.5 h-4.5 text-sky-400" />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Control Actions */}
            <div className="flex gap-2 mt-4">
              <button
                onClick={onResetStats}
                className="w-full py-2 bg-slate-950 hover:bg-slate-900 border border-slate-850 hover:border-slate-750 text-[10px] uppercase font-mono font-bold text-slate-300 rounded-lg cursor-pointer transition active:scale-95 text-center flex items-center justify-center gap-1"
                title="Resetar todos os atributos distribuídos"
              >
                Resetar Upgrades
              </button>
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: Interactive powers description guide */}
        <div className="col-span-7 bg-slate-900/40 p-4 border border-slate-900 rounded-2xl flex flex-col justify-between h-full overflow-y-auto">
          
          <div className="space-y-4">
            
            {/* Swords mastery */}
            <div>
              <div className="flex items-center gap-1.5 border-b border-slate-900 pb-1.5 mb-2">
                <Swords className="w-4 h-4 text-emerald-400" />
                <h3 className="text-[11px] font-black text-emerald-400 uppercase tracking-widest font-mono">Arsenal do Guarda Florestal</h3>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                
                <div className="bg-slate-950/30 p-2 border border-slate-900 rounded-xl text-left font-sans">
                  <div className="flex items-center gap-1.5 font-bold mb-1">
                    <span className="bg-emerald-950/40 text-emerald-400 border border-emerald-500/25 px-1 rounded text-[9.5px] font-mono uppercase">Z</span>
                    <span className="text-slate-100 text-[11px]">Bastão Tático</span>
                  </div>
                  <p className="text-slate-400 text-[9.5px] leading-relaxed">Batidas rápidas de curto alcance. Imobiliza infratores com um combo ordenado de 3 batidas.</p>
                </div>

                <div className="bg-slate-950/30 p-2 border border-slate-900 rounded-xl text-left font-sans">
                  <div className="flex items-center gap-1.5 font-bold mb-1">
                    <span className="bg-sky-950/40 text-sky-400 border border-sky-500/25 px-1 rounded text-[9.5px] font-mono uppercase">C</span>
                    <span className="text-slate-100 text-[11px]">Avanço Rápido (Botas)</span>
                  </div>
                  <p className="text-slate-400 text-[9.5px] leading-relaxed">Usa o impulso das botas táticas para correr à frente, desequilibrando criminosos que tentar de ferir.</p>
                </div>

                <div className="bg-slate-950/30 p-2 border border-slate-900 rounded-xl text-left font-sans">
                  <div className="flex items-center gap-1.5 font-bold mb-1">
                    <span className="bg-yellow-950/40 text-yellow-400 border border-yellow-500/25 px-1 rounded text-[9.5px] font-mono uppercase">V</span>
                    <span className="text-slate-100 text-[11px]">Disparador de Rede</span>
                  </div>
                  <p className="text-slate-400 text-[9.5px] leading-relaxed">Emite uma imobilização de rede circular. Recarrega as redes após deter 5 infratores.</p>
                </div>

                <div className="bg-slate-950/30 p-2 border border-slate-905 rounded-xl text-left font-sans">
                  <div className="flex items-center gap-1.5 font-bold mb-1">
                    <span className="bg-slate-800 text-slate-300 border border-slate-700 px-1 rounded text-[9.5px] font-mono">↓ + Z</span>
                    <span className="text-slate-100 text-[11px]">Bastão Descendente</span>
                  </div>
                  <p className="text-slate-400 text-[9.5px] leading-relaxed">Dispara enquanto cai do ar. Golpeia o solo descarregando uma onda sônica que interrompe ataques.</p>
                </div>

              </div>
            </div>

            {/* Spells and Attunements mastery */}
            <div>
              <div className="flex items-center gap-1.5 border-b border-slate-900 pb-1.5 mb-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <h3 className="text-[11px] font-black text-emerald-400 uppercase tracking-widest font-mono">Sinalizadores & Drones</h3>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-start gap-2.5 bg-slate-950/35 border border-slate-900 p-2.5 rounded-xl text-left">
                  <div className="p-1.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 mt-1">
                    <Sun className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="font-bold text-slate-100 text-xs flex items-center gap-1.5">
                      Sinalizador de Monitoramento
                      <span className="bg-slate-900 text-slate-400 px-1 py-0.2 text-[8px] font-mono uppercase font-bold rounded border border-slate-800">[TECLA F]</span>
                    </h5>
                    <p className="text-slate-400 text-[9.5px] leading-relaxed mt-1">
                      Enquanto ativo, detecta a umidade do solo e estimula o crescimento de mudas locais. Adicionalmente, melhora a comunicação de rádio, recuperando a bateria de equipamentos secundários do fiscal.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 bg-slate-950/35 border border-slate-900 p-2.5 rounded-xl text-left">
                  <div className="p-1.5 rounded bg-amber-500/10 border border-amber-500/30 text-amber-400 mt-1">
                    <Moon className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="font-bold text-slate-100 text-xs flex items-center gap-1.5">
                      Detecção Térmica de Infratores
                      <span className="bg-slate-900 text-slate-400 px-1 py-0.2 text-[8px] font-mono uppercase font-bold rounded border border-slate-800">[TECLA F]</span>
                    </h5>
                    <p className="text-slate-400 text-[9.5px] leading-relaxed mt-1">
                      Ao trocar de canal no rádio para o modo de escuta ativa, o visor do guarda passa a varrer assinaturas térmicas, detectando rotas de fuga ou poças de garimpeiros com radiação sônica imobilizadora nos arredores.
                    </p>
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* Quick tip footer banner */}
          <div className="bg-slate-950 p-2 border border-slate-900 rounded-xl text-[9px] font-mono text-slate-500">
            DICA: Resgate todos os Animais Silvestres em perigo de cada setor do parque antes de cruzar a divisa do mapa.
          </div>

        </div>

      </div>

    </div>
  );
};
